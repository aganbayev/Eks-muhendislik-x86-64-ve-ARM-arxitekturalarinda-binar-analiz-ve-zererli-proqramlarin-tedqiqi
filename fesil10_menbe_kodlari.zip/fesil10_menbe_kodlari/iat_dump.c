/* iat_dump.c - proqram öz IAT cədvəlini icra zamanı oxuyur və
   hər elementi GetProcAddress nəticəsi ilə müqayisə edir */
#include "w32.h"

extern const char __ImageBase[];   /* linker bu simvolu faylın baza ünvanına bağlayır */

void start(void)
{
    const char *base = __ImageBase;
    unsigned int pe = *(const unsigned int *)(base + 0x3c);           /* e_lfanew */
    unsigned int imp = *(const unsigned int *)(base + pe + 24 + 120); /* kataloq 1: idxal */
    const unsigned int *desc = (const unsigned int *)(base + imp);
    HMODULE k32 = GetModuleHandleA("kernel32.dll");

    put_str("ImageBase:        "); put_hex((unsigned long long)base); put_str("\r\n");
    put_str("kernel32.dll:     "); put_hex((unsigned long long)k32);  put_str("\r\n");
    for (; desc[3]; desc += 5) {                       /* Name != 0 */
        const unsigned long long *ilt = (const void *)(base + desc[0]);
        const unsigned long long *iat = (const void *)(base + desc[4]);
        put_str(base + desc[3]); put_str("\r\n");
        for (; *ilt; ilt++, iat++) {
            const char *name = base + (unsigned int)*ilt + 2;   /* hint-dən sonra ad */
            put_str("  "); put_hex(*iat);
            put_str(*iat == (unsigned long long)GetProcAddress(k32, name) ? "  = " : "  != ");
            put_str(name); put_str("\r\n");
        }
    }
    ExitProcess(0);
}
