/* peb_demo.c - TEB və PEB strukturlarını API çağırmadan oxuyur */
#include "w32.h"

#if defined(__x86_64__)
#define TEB_PEB      0x60        /* TEB.ProcessEnvironmentBlock */
#define PEB_IMAGE    0x10        /* PEB.ImageBaseAddress */
#define PEB_LDR      0x18        /* PEB.Ldr */
static char *get_teb(void) { char *t; __asm__("mov %%gs:0x30, %0" : "=r"(t)); return t; }
#elif defined(__i386__)
#define TEB_PEB      0x30
#define PEB_IMAGE    0x08
#define PEB_LDR      0x0c
static char *get_teb(void) { char *t; __asm__("mov %%fs:0x18, %0" : "=r"(t)); return t; }
#elif defined(__aarch64__)
#define TEB_PEB      0x60
#define PEB_IMAGE    0x10
#define PEB_LDR      0x18
static char *get_teb(void) { char *t; __asm__("mov %0, x18" : "=r"(t)); return t; }
#endif

void start(void)
{
    char *teb = get_teb();                      /* TEB.Self: TEB-in öz ünvanı */
    char *peb = *(char **)(teb + TEB_PEB);

    put_str("TEB:              "); put_hex((unsigned long long)teb); put_str("\r\n");
    put_str("PEB:              "); put_hex((unsigned long long)peb); put_str("\r\n");
    put_str("BeingDebugged:    "); put_hex(peb[2]); put_str("\r\n");
    put_str("ImageBaseAddress: "); put_hex((unsigned long long)*(void **)(peb + PEB_IMAGE));
    put_str("\r\nGetModuleHandleA: "); put_hex((unsigned long long)GetModuleHandleA(0));
    put_str("\r\nLdr:              "); put_hex((unsigned long long)*(void **)(peb + PEB_LDR));
    put_str("\r\n");
    ExitProcess(0);
}
