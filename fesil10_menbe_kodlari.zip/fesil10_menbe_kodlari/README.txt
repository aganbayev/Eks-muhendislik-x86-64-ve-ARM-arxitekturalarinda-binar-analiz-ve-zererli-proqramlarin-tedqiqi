Chapter 10 - Windows binary internals

iat_dump.c       walks the import address table of the running process (10.2)
dyn_resolve.c    LoadLibrary/GetProcAddress and API hashing (10.3)
peb_demo.c       TEB/PEB access on x64, x86 and ARM64 (10.4)
ldr_walk.c       module list through PEB.Ldr (10.5)
w32.h            minimal Windows structure definitions (no SDK needed)
build.sh         builds with clang/lld-link on Linux and runs under Wine
