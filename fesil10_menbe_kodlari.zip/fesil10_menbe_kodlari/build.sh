#!/bin/sh
# Chapter 10 (Windows internals) examples: build with Clang/LLD on Linux, run with Wine.
set -e
L="lld-link /nodefaultlib /entry:start /subsystem:console /Brepro"
llvm-dlltool -m i386:x86-64 -d kernel32.def     -l kernel32.lib
llvm-dlltool -m i386 -k     -d kernel32_x86.def -l kernel32_x86.lib
llvm-dlltool -m arm64       -d kernel32.def     -l kernel32_arm64.lib

clang --target=x86_64-pc-windows-msvc -O2 -c iat_dump.c    -o iat_dump.obj    && $L iat_dump.obj    kernel32.lib /out:iat_dump.exe
clang --target=x86_64-pc-windows-msvc -O2 -c dyn_resolve.c -o dyn_resolve.obj && $L dyn_resolve.obj kernel32.lib /out:dyn_resolve.exe
clang --target=x86_64-pc-windows-msvc -O2 -c ldr_walk.c    -o ldr_walk.obj    && $L ldr_walk.obj    kernel32.lib /out:ldr_walk.exe
clang --target=x86_64-pc-windows-msvc -O2 -c peb_demo.c -o peb_x64.obj && $L peb_x64.obj kernel32.lib         /out:peb_demo.exe
clang --target=i686-pc-windows-msvc   -O2 -c peb_demo.c -o peb_x86.obj && $L peb_x86.obj kernel32_x86.lib     /out:peb_x86.exe
clang --target=aarch64-pc-windows-msvc -O2 -c peb_demo.c -o peb_a64.obj && $L peb_a64.obj kernel32_arm64.lib  /out:peb_a64.exe

export WINEDEBUG=-all
wine iat_dump.exe
wine dyn_resolve.exe
wine peb_demo.exe
wine ldr_walk.exe
