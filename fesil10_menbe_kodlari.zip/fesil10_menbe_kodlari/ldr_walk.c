/* ldr_walk.c - yüklənmiş modulları PEB.Ldr siyahısından sadalayır (idxalsız) */
#include "w32.h"

#if defined(__x86_64__)
static char *get_teb(void) { char *t; __asm__("mov %%gs:0x30, %0" : "=r"(t)); return t; }
#define TEB_PEB 0x60
#define PEB_LDR 0x18
#define LIST_OFF 0x10       /* Ldr.InLoadOrderModuleList */
#define DLLBASE 0x30        /* LDR_DATA_TABLE_ENTRY.DllBase */
#define FULLNAME 0x48       /* FullDllName (UNICODE_STRING) */
#endif

static void put_wstr(const unsigned short *w)
{
    char buf[128];
    int i = 0;
    while (w[i] && i < 127) {
        buf[i] = (char)w[i];
        i++;
    }
    buf[i] = 0;
    put_str(buf);
}

void start(void)
{
    char *teb = get_teb();
    char *peb = *(char **)(teb + TEB_PEB);
    char *ldr = *(char **)(peb + PEB_LDR);
    char *head = ldr + LIST_OFF;
    char *cur = *(char **)head;                 /* ilk element */

    while (cur != head) {
        char *entry = cur - 0;                  /* InLoadOrderLinks siyahının başındadır */
        void *base = *(void **)(entry + DLLBASE);
        unsigned short *name = *(unsigned short **)(entry + FULLNAME + 8);
        if (!base)
            break;
        put_hex((unsigned long long)base);
        put_str("  ");
        put_wstr(name);
        put_str("\r\n");
        cur = *(char **)cur;
    }
    ExitProcess(0);
}
