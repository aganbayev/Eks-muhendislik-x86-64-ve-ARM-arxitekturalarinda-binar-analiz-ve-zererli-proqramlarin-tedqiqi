/* dyn_resolve.c - WriteFile və GetStdHandle idxal cədvəlində görünmür:
   onlar icra zamanı GetProcAddress ilə tapılır, adları isə yığında qurulur */
typedef void *HMODULE;
typedef void *HANDLE;
__declspec(dllimport) HMODULE __stdcall LoadLibraryA(const char *name);
__declspec(dllimport) void *__stdcall GetProcAddress(HMODULE m, const char *name);
__declspec(dllimport) void __stdcall ExitProcess(unsigned int code);

typedef HANDLE (__stdcall *get_std_handle_t)(unsigned long);
typedef int (__stdcall *write_file_t)(HANDLE, const void *, unsigned long,
                                      unsigned long *, void *);

void start(void)
{
    char k32[16], wf[16], gsh[16];
    /* Yığın sətirləri: hər simvol ayrıca yazılır, faylda hazır sətir qalmır */
    k32[0] = 'k'; k32[1] = 'e'; k32[2] = 'r'; k32[3] = 'n'; k32[4] = 'e'; k32[5] = 'l';
    k32[6] = '3'; k32[7] = '2'; k32[8] = 0;
    wf[0] = 'W'; wf[1] = 'r'; wf[2] = 'i'; wf[3] = 't'; wf[4] = 'e';
    wf[5] = 'F'; wf[6] = 'i'; wf[7] = 'l'; wf[8] = 'e'; wf[9] = 0;
    gsh[0] = 'G'; gsh[1] = 'e'; gsh[2] = 't'; gsh[3] = 'S'; gsh[4] = 't'; gsh[5] = 'd';
    gsh[6] = 'H'; gsh[7] = 'a'; gsh[8] = 'n'; gsh[9] = 'd'; gsh[10] = 'l'; gsh[11] = 'e';
    gsh[12] = 0;
    HMODULE m = LoadLibraryA(k32);
    get_std_handle_t pGetStdHandle = (get_std_handle_t)GetProcAddress(m, gsh);
    write_file_t pWriteFile = (write_file_t)GetProcAddress(m, wf);
    unsigned long n;

    pWriteFile(pGetStdHandle((unsigned long)-11), "Dinamik axtaris\r\n", 17, &n, 0);
    ExitProcess(0);
}
