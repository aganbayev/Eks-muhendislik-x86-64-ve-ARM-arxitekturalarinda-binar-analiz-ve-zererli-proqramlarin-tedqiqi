/* w32.h - 10-cu fəslin nümunələri üçün minimal Win32 elanları (SDK olmadan) */
typedef void *HANDLE;
typedef void *HMODULE;
typedef void *FARPROC;

__declspec(dllimport) HANDLE  __stdcall GetStdHandle(unsigned long n);
__declspec(dllimport) int     __stdcall WriteFile(HANDLE h, const void *buf, unsigned long len,
                                                  unsigned long *written, void *ovl);
__declspec(dllimport) void    __stdcall ExitProcess(unsigned int code);
__declspec(dllimport) HMODULE __stdcall GetModuleHandleA(const char *name);
__declspec(dllimport) FARPROC __stdcall GetProcAddress(HMODULE m, const char *name);
__declspec(dllimport) HMODULE __stdcall LoadLibraryA(const char *name);

/* Konsola mətn və onaltılıq ədəd çap edən köməkçi funksiyalar */
static void put_str(const char *s)
{
    unsigned long n, len = 0;
    while (s[len])
        len++;
    WriteFile(GetStdHandle((unsigned long)-11), s, len, &n, 0);
}

static void put_hex(unsigned long long v)
{
    char buf[19];
    int i;
    buf[0] = '0';
    buf[1] = 'x';
    for (i = 0; i < 16; i++)
        buf[2 + i] = "0123456789abcdef"[(v >> (60 - 4 * i)) & 0xf];
    buf[18] = 0;
    put_str(buf);
}
