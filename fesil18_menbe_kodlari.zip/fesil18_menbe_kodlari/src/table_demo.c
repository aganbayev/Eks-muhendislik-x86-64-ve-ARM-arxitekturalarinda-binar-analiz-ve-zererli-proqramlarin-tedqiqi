/* table_demo.c - harness for chapter 18: links Mirai's own bot/table.c and bot/util.c
 * (unchanged, from the public source repository) and prints a few table entries.
 * Nothing else of the bot is compiled: no scanner, killer, attack or network code.
 * Purpose: to see what the string-table code looks like in a binary for x86-64,
 * ARM and MIPS, so that it can be recognised in real samples. */
#include <stdio.h>
#include <stdint.h>
#include "table.h"

extern uint32_t table_key;                     /* defined in bot/table.c */

static void show(int id, const char *name)
{
    int len;
    table_unlock_val(id);                       /* XOR in place: plain text */
    char *v = table_retrieve_val(id, &len);
    printf("%-18s len=%-3d ", name, len);
    for (int i = 0; i < len; i++)
        putchar(v[i] >= 0x20 && v[i] < 0x7f ? v[i] : '.');
    putchar('\n');
    table_lock_val(id);                         /* XOR again: encoded */
}

int main(void)
{
    table_init();
    printf("table_key = %#010x\n", table_key);
    show(TABLE_CNC_DOMAIN, "TABLE_CNC_DOMAIN");
    show(TABLE_CNC_PORT, "TABLE_CNC_PORT");
    show(TABLE_EXEC_SUCCESS, "TABLE_EXEC_SUCCESS");
    show(TABLE_KILLER_PROC, "TABLE_KILLER_PROC");
    return 0;
}
