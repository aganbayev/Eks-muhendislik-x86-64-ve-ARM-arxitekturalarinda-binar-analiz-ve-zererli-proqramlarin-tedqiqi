#!/bin/sh
# Chapter 18: fetches the public Mirai source at a fixed commit and builds ONLY the
# string-table harness (table_demo.c + bot/table.c + bot/util.c) for three architectures.
# x86-64: static executable; ARMv7 and MIPS: object files for disassembly.
# -fcommon: the 2016 sources rely on the old GCC default for tentative definitions.
set -e
REPO=https://github.com/jgamblin/Mirai-Source-Code.git
REV=4889a6f797237f1d4210839bcefd9f89c57c0770
O=${O:-../bin}; M=${M:-../Mirai-Source-Code}
[ -d $M ] || git clone -q $REPO $M
git -C $M checkout -q $REV
B=$M/mirai/bot
mkdir -p $O
CF="-std=c99 -fcommon -O3 -fomit-frame-pointer -fdata-sections -ffunction-sections -I$B"
gcc $CF -static -Wl,--gc-sections -o $O/table_demo_x86_64 table_demo.c $B/table.c $B/util.c
cp $O/table_demo_x86_64 $O/table_demo_x86_64_s && strip -s $O/table_demo_x86_64_s
# ARMv7 and MIPS: musl 1.2.5 headers (make ARCH=arm|mips prefix=/opt/musl-<arch> install-headers)
clang --target=armv7-linux-gnueabihf -nostdinc -isystem /opt/musl-arm/include \
    -isystem $(clang -print-resource-dir)/include $CF -c $B/table.c -o $O/table_armv7.o
clang --target=mips-linux-gnu -mno-abicalls -fno-pic -nostdinc -isystem /opt/musl-mips/include \
    -isystem $(clang -print-resource-dir)/include $CF -c $B/table.c -o $O/table_mips.o
