// Ch18RefsTo.java - prints the references to an address and decompiles every
// function that contains one of them (first N lines). Args: ADDRESS [N]
//@category Ch18
import ghidra.app.decompiler.*;
import ghidra.app.script.GhidraScript;
import ghidra.program.model.address.Address;
import ghidra.program.model.listing.Function;
import ghidra.program.model.symbol.Reference;
import java.util.*;

public class Ch18RefsTo extends GhidraScript {
    @Override
    public void run() throws Exception {
        System.out.println("@@BEGIN");
        try { body(); } finally { System.out.println("@@END"); }
    }

    private void body() throws Exception {
        String[] a = getScriptArgs();
        Address target = toAddr(a[0]);
        int n = a.length > 1 ? Integer.parseInt(a[1]) : 40;
        Set<Function> funcs = new LinkedHashSet<>();
        for (Reference r : getReferencesTo(target)) {
            Function f = getFunctionContaining(r.getFromAddress());
            System.out.printf("%s %s %s  %s\n", r.getFromAddress(), r.getReferenceType(),
                    f == null ? "-" : f.getName(), getInstructionAt(r.getFromAddress()));
            if (f != null) funcs.add(f);
        }
        DecompInterface ifc = new DecompInterface();
        ifc.openProgram(currentProgram);
        for (Function f : funcs) {
            String c = ifc.decompileFunction(f, 120, monitor).getDecompiledFunction().getC();
            String[] lines = c.split("\n");
            System.out.println("==== " + f.getName() + " @ " + f.getEntryPoint());
            for (int i = 0; i < Math.min(n, lines.length); i++) System.out.println(lines[i]);
        }
    }
}
