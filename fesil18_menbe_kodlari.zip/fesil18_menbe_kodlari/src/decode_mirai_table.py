#!/usr/bin/env python3
"""decode_mirai_table.py - static decoding of Mirai's string table from the source
(bot/table.c and bot/table.h), chapter 18, 18.4. Every add_entry() literal is XORed
with the four bytes of table_key; the result is printed with the entry name.
Usage: decode_mirai_table.py BOT_DIR [MAXLEN]"""
import re, sys

bot = sys.argv[1]
maxlen = int(sys.argv[2]) if len(sys.argv) > 2 else 60
src = open(f"{bot}/table.c").read()
key = int(re.search(r"table_key\s*=\s*(0x[0-9a-fA-F]+)", src).group(1), 16)
k = (key & 0xff) ^ (key >> 8 & 0xff) ^ (key >> 16 & 0xff) ^ (key >> 24 & 0xff)
print(f"table_key = {key:#010x}, combined XOR byte = {k:#04x}")
for name, lit, n in re.findall(r'add_entry\((\w+),\s*"([^"]*)",\s*(\d+)\)', src):
    raw = bytes(int(h, 16) for h in re.findall(r"\\x([0-9a-fA-F]{2})", lit))
    plain = bytes(b ^ k for b in raw)
    if name.endswith("_PORT"):                       # 2 bytes, network order
        text = str(int.from_bytes(plain[:2], "big"))
    else:
        text = "".join(chr(c) if 32 <= c < 127 else "." for c in plain.rstrip(b"\0"))
    if len(text) > maxlen:
        text = text[:maxlen - 3] + "..."
    print(f"{name:<30} {n:>3}  {text}")
