/* mirai_table.yar - Mirai string table and constants (chapter 18, 18.6). YARA 4.5.
   The killer's competitor names and the scanner's busybox strings are XORed with a
   one-byte key in the table; variants change the key, so every key is tried. */
rule Mirai_StringTable_Xor
{
    meta:
        description = "Mirai bot: encoded table entries (killer and scanner strings), any one-byte key"
        author = "Asif Qanbayev"
        reference = "https://github.com/jgamblin/Mirai-Source-Code (bot/table.c)"
    strings:
        $k1 = "REPORT %s:%s" xor(0x01-0xff)
        $k2 = "HTTPFLOOD" xor(0x01-0xff)
        $k3 = "LOLNOGTFO" xor(0x01-0xff)
        $k4 = "zollard" xor(0x01-0xff)
        $k5 = "GETLOCALIP" xor(0x01-0xff)
        $s1 = "/bin/busybox MIRAI" xor(0x01-0xff)
        $s2 = "MIRAI: applet not found" xor(0x01-0xff)
        $s3 = "listening tun0" xor(0x01-0xff)
    condition:
        uint32(0) == 0x464c457f and 4 of them
}

