#!/bin/sh
# Chapter 18: finds table_init in the stripped harness from the address of one encoded
# string (YARA offset 0x80096 -> .rodata VA 0x480096). Ghidra 12.2 headless, JDK 25.
set -e
P=${GHIDRA_PROJ:-$HOME/gh18}; S=$(cd "$(dirname "$0")/ghidra_scripts" && pwd)
mkdir -p "$P"
analyzeHeadless "$P" ch18 -import table_demo_x86_64_s -overwrite -scriptPath "$S" \
    -postScript Ch18RefsTo.java 0x480096 45 2>&1 |
    grep -v -E "^(INFO|WARN|ERROR) |^    /" | sed -n '/@@BEGIN/,/@@END/p' | grep -v "^@@"
