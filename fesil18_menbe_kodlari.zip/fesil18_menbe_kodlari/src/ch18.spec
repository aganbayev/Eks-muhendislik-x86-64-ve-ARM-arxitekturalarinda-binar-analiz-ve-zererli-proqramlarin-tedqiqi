# chapter 18 listings (run in /root/lab18)
== src_tree
$ git --no-pager -C Mirai-Source-Code log -1 --format="%h %cs"
$ cd Mirai-Source-Code && ls mirai/bot mirai/cnc loader/src
$ cd Mirai-Source-Code && wc -l mirai/bot/*.c | tail -1 && wc -l mirai/cnc/*.go | tail -1 && wc -l loader/src/*.c | tail -1
== consts
$ cd Mirai-Source-Code/mirai && grep -n "SINGLE_INSTANCE_PORT\|FAKE_CNC_ADDR\|FAKE_CNC_PORT" bot/includes.h
$ cd Mirai-Source-Code/mirai && grep -n "net.Listen" cnc/main.go tools/scanListen.go
$ cd Mirai-Source-Code/mirai && grep -n "htons(23)\|htons(2323)" bot/scanner.c && grep -c "add_auth_entry(" bot/scanner.c
$ cd Mirai-Source-Code/mirai && grep -n "watchdog\|0x80045704\|SIGTRAP\|unlink(args\|PR_SET_NAME" bot/main.c
$ cd Mirai-Source-Code/mirai && grep -n 'x00\\x00\\x00\\x01' bot/main.c
== decode
$ python3 decode_mirai_table.py Mirai-Source-Code/mirai/bot 50
== demo
$ ./table_demo_x86_64
== dis_x86
$ objdump -d -M intel --no-show-raw-insn --disassemble=toggle_obf table_demo_x86_64 | sed -n '/<toggle_obf>:/,/ret/p'
== dis_arm
$ llvm-objdump -d --no-show-raw-insn --disassemble-symbols=table_unlock_val table_armv7.o | tail -n +6
== dis_mips
$ llvm-objdump -d --no-show-raw-insn --disassemble-symbols=table_unlock_val table_mips.o | tail -n +6
== yara
$ for f in table_demo_x86_64 table_demo_x86_64_s table_armv7.o table_mips.o; do yara mirai_table.yar $f; done
$ yara -s -X mirai_table.yar table_demo_x86_64_s
$ yara -r mirai_table.yar /root/lab16/goodware | wc -l
$ yara -r mirai_table.yar /root/lab16/corpus | wc -l
$ readelf -SW table_demo_x86_64_s | grep -E " \.rodata "
