Chapter 18 - Case study: Mirai (source and binary analysis)

The Mirai source is NOT included. build.sh clones the public mirror
https://github.com/jgamblin/Mirai-Source-Code at commit 4889a6f and compiles ONLY the
string-table code (bot/table.c, bot/util.c) together with table_demo.c. The scanner,
killer, attack and network code of the bot is never compiled or run.

src/
  build.sh               clone + build: table_demo_x86_64 (static, GCC), its stripped copy,
                         table_armv7.o and table_mips.o (Clang 18 + musl 1.2.5 headers:
                         make ARCH=arm|mips prefix=/opt/musl-<arch> install-headers)
  table_demo.c           harness that prints four decoded table entries
  decode_mirai_table.py  static decoding of every add_entry() literal in bot/table.c
  mirai_table.yar        YARA rule: encoded table strings, any one-byte XOR key (18.6)
  run_ghidra.sh + ghidra_scripts/Ch18RefsTo.java   finds table_init in the stripped file
  ch18.spec + session.py the exact commands of the listings (run in the lab folder)
results_book/            the outputs quoted in the chapter
