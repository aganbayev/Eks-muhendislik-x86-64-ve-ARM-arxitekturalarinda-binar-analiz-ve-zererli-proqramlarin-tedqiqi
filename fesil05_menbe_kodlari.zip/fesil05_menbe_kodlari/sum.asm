; sum.asm - long sum_array(const long *a, long n)
; System V: a -> rdi, n -> rsi, nəticə -> rax

section .text
global sum_array
sum_array:
        xor     eax, eax            ; s = 0
        test    rsi, rsi
        jle     .done               ; n <= 0 olarsa
        xor     ecx, ecx            ; i = 0
.loop:
        add     rax, [rdi + rcx*8]  ; s += a[i]
        inc     rcx
        cmp     rcx, rsi
        jl      .loop
.done:
        ret

section .note.GNU-stack noalloc noexec nowrite progbits
