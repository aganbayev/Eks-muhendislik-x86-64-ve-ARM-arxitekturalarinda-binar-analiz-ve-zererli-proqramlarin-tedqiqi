Chapter 5 - x86-64 assembly (NASM syntax)

hello64.asm   system calls only:  nasm -f elf64 hello64.asm -o hello64.o && ld hello64.o -o hello64
sum.asm       long sum_array(const long *a, long n) in assembly, called from C
main_sum.c    nasm -f elf64 sum.asm -o sum.o && gcc main_sum.c sum.o -o sum && ./sum
cmp.c         signed vs unsigned comparisons (jl/jge vs jb/jae):  gcc -O0 -c cmp.c
caller.c      calling conventions, System V vs Windows x64:
              clang --target=x86_64-linux-gnu -O1 -S -masm=intel caller.c
              clang --target=x86_64-pc-windows-msvc -O1 -S -masm=intel caller.c
