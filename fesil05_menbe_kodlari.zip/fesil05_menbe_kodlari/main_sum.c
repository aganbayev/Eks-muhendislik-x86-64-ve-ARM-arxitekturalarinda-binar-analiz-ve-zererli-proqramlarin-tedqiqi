#include <stdio.h>

long sum_array(const long *a, long n);

int main(void)
{
    long data[] = {10, 20, 30, 40, 50};
    printf("Cəm: %ld\n", sum_array(data, 5));
    return 0;
}
