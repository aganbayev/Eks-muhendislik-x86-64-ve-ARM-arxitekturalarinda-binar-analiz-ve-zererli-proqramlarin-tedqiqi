; hello64.asm - Linux x86-64, yalnız sistem çağırışları ilə
; nasm -f elf64 hello64.asm -o hello64.o && ld hello64.o -o hello64

section .rodata
msg:    db "Salam, assembly!", 10
len:    equ $ - msg

section .text
global _start
_start:
        mov     eax, 1          ; write
        mov     edi, 1          ; fd = stdout
        lea     rsi, [rel msg]  ; buf
        mov     edx, len        ; count
        syscall

        mov     eax, 60         ; exit
        xor     edi, edi        ; status = 0
        syscall
