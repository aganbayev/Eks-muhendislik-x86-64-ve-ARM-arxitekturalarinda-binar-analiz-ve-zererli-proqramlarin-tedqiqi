long long many_args(long long a, long long b, long long c, long long d,
                    long long e, long long f, long long g, long long h);

long long caller(void)
{
    return many_args(1, 2, 3, 4, 5, 6, 7, 8) + 1;
}
