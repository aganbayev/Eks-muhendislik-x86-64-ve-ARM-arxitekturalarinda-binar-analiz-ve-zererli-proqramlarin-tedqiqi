/* use_dll.c - azelib.dll-dən idxal edən proqram; nəticə çıxış kodu ilə qaytarılır */
__declspec(dllimport) unsigned xor_sum(const unsigned char *p, unsigned n);
__declspec(dllimport) void exit_process(unsigned code);   /* kernel32.ExitProcess-ə yönəldilib */

void start(void)
{
    static const unsigned char data[] = {0x41, 0x7a, 0x65};   /* "Aze" */
    exit_process(xor_sum(data, 3));   /* 0x41 ^ 0x7a ^ 0x65 = 0x5e (94) */
}
