/* tls_demo.c - TLS callback funksiyası giriş nöqtəsindən əvvəl icra olunur */
typedef void *HANDLE;
__declspec(dllimport) HANDLE __stdcall GetStdHandle(unsigned long n);
__declspec(dllimport) int __stdcall WriteFile(HANDLE h, const void *buf, unsigned long len,
                                              unsigned long *written, void *ovl);
__declspec(dllimport) void __stdcall ExitProcess(unsigned int code);

static void say(const char *s, unsigned long len)
{
    unsigned long n;
    WriteFile(GetStdHandle((unsigned long)-11), s, len, &n, 0);
}

static void __stdcall tls_callback(void *module, unsigned long reason, void *reserved)
{
    if (reason == 1)                          /* DLL_PROCESS_ATTACH */
        say("1. TLS callback\r\n", 17);
}

typedef void (__stdcall *tls_cb_t)(void *, unsigned long, void *);
static tls_cb_t callbacks[] = { tls_callback, 0 };
unsigned long _tls_index;

/* IMAGE_TLS_DIRECTORY64: linker bu simvolu tapıb TLS kataloquna yazır */
const struct {
    unsigned long long start, end, index, callbacks;
    unsigned int zero_fill, characteristics;
} _tls_used = { 0, 0, (unsigned long long)&_tls_index,
                (unsigned long long)callbacks, 0, 0 };

void start(void)
{
    say("2. Giris noqtesi\r\n", 18);
    ExitProcess(0);
}
