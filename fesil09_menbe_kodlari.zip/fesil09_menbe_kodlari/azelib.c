/* azelib.c - ixrac cədvəlini öyrənmək üçün kiçik DLL */
__declspec(dllexport) unsigned xor_sum(const unsigned char *p, unsigned n)
{
    unsigned s = 0;
    while (n--)
        s ^= *p++;
    return s;
}

__declspec(dllexport) const char *azelib_version(void)
{
    return "azelib 1.0";
}
