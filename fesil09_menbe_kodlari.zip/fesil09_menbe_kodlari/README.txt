Chapter 9 - The PE format

hello_pe.c        minimal PE program (9.3, 9.6)
crackme01_win.c   chapter 1 crackme for Windows (9.1, 9.6)
azelib.c, azelib.def, use_dll.c   a DLL with exports and a program that imports it (9.7)
tls_demo.c        TLS callback example (9.9)
peinfo.py         lab 9: PE parser written with the standard struct module
*.def             import definitions used to build without the Windows SDK
build.sh          builds everything with clang/lld-link on Linux and runs it under Wine
Requires: clang/lld 18 (lld-link), llvm-dlltool, llvm-readobj, wine.
