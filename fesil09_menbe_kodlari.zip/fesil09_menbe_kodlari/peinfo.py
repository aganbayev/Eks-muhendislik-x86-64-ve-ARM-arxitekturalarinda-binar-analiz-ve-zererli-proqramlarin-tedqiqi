#!/usr/bin/env python3
"""peinfo.py - PE faylının başlığını, seksiyalarını, idxalını və overlay-ni göstərir."""
import struct
import sys

MACHINES = {0x14C: "x86", 0x8664: "x86-64", 0x1C4: "ARM (Thumb-2)", 0xAA64: "ARM64"}
SUBSYSTEMS = {1: "NATIVE", 2: "WINDOWS_GUI", 3: "WINDOWS_CUI"}
DLLCHARS = {0x20: "HIGH_ENTROPY_VA", 0x40: "DYNAMIC_BASE", 0x100: "NX_COMPAT",
            0x400: "NO_SEH", 0x4000: "GUARD_CF"}


class PeError(Exception):
    pass


def cstr(data, off):
    return data[off:data.index(b"\0", off)].decode(errors="replace")


def parse(data):
    if data[:2] != b"MZ":
        raise PeError("MZ imzası tapılmadı")
    pe = struct.unpack_from("<I", data, 0x3C)[0]          # e_lfanew
    if data[pe:pe + 4] != b"PE\0\0":
        raise PeError("PE imzası tapılmadı")
    machine, nsect, stamp, _, _, opt_size, chars = struct.unpack_from("<HHIIIHH", data, pe + 4)
    opt = pe + 24
    magic = struct.unpack_from("<H", data, opt)[0]
    if magic == 0x20B:                                     # PE32+
        entry = struct.unpack_from("<I", data, opt + 16)[0]
        base = struct.unpack_from("<Q", data, opt + 24)[0]
        subsys, dllchars = struct.unpack_from("<HH", data, opt + 68)
        ndirs = struct.unpack_from("<I", data, opt + 108)[0]
        dirs_off = opt + 112
    elif magic == 0x10B:                                   # PE32
        entry = struct.unpack_from("<I", data, opt + 16)[0]
        base = struct.unpack_from("<I", data, opt + 28)[0]
        subsys, dllchars = struct.unpack_from("<HH", data, opt + 68)
        ndirs = struct.unpack_from("<I", data, opt + 92)[0]
        dirs_off = opt + 96
    else:
        raise PeError(f"naməlum Magic: {magic:#x}")
    dirs = [struct.unpack_from("<II", data, dirs_off + 8 * i) for i in range(ndirs)]
    sections = []
    for i in range(nsect):
        name, vsize, va, rsize, roff = struct.unpack_from("<8sIIII", data, opt + opt_size + 40 * i)
        flags = struct.unpack_from("<I", data, opt + opt_size + 40 * i + 36)[0]
        sections.append((name.rstrip(b"\0").decode(errors="replace"), vsize, va, rsize, roff, flags))
    return dict(machine=machine, nsect=nsect, stamp=stamp, chars=chars, magic=magic,
                entry=entry, base=base, subsys=subsys, dllchars=dllchars,
                dirs=dirs, sections=sections)


def rva2off(pe, rva):
    for _, vsize, va, rsize, roff, _ in pe["sections"]:
        if va <= rva < va + max(vsize, rsize):
            return rva - va + roff
    raise PeError(f"RVA {rva:#x} heç bir seksiyaya düşmür")


def imports(data, pe):
    rva = pe["dirs"][1][0]                                 # 1 = idxal kataloqu
    result = []
    while rva:
        ilt, _, _, name, iat = struct.unpack_from("<IIIII", data, rva2off(pe, rva))
        if name == 0:
            break
        funcs = []
        size, flag = (8, 1 << 63) if pe["magic"] == 0x20B else (4, 1 << 31)
        t = rva2off(pe, ilt or iat)
        while True:
            v = struct.unpack_from("<Q" if size == 8 else "<I", data, t)[0]
            if v == 0:
                break
            funcs.append(f"#{v & 0xFFFF}" if v & flag else cstr(data, rva2off(pe, v) + 2))
            t += size
        result.append((cstr(data, rva2off(pe, name)), funcs))
        rva += 20
    return result


def main(path):
    with open(path, "rb") as f:
        data = f.read()
    pe = parse(data)
    print(f"Fayl:        {path}")
    print(f"Arxitektura: {MACHINES.get(pe['machine'], hex(pe['machine']))}, "
          f"{'PE32+' if pe['magic'] == 0x20B else 'PE32'}, "
          f"{'DLL' if pe['chars'] & 0x2000 else 'EXE'}")
    print(f"ImageBase:   {pe['base']:#x}   Giriş (RVA): {pe['entry']:#x}")
    print(f"Altsistem:   {SUBSYSTEMS.get(pe['subsys'], pe['subsys'])}")
    print(f"Qoruma:      {' '.join(v for k, v in DLLCHARS.items() if pe['dllchars'] & k) or '-'}")
    print("\nSeksiyalar:")
    end = 0
    for name, vsize, va, rsize, roff, flags in pe["sections"]:
        perm = ("R" if flags & 0x40000000 else "-") + ("W" if flags & 0x80000000 else "-") \
            + ("X" if flags & 0x20000000 else "-")
        print(f"  {name:<8} rva={va:#07x} vsize={vsize:#07x} off={roff:#07x} "
              f"rsize={rsize:#07x} {perm}")
        end = max(end, roff + rsize)
    for dll, funcs in imports(data, pe):
        print(f"\nİdxal: {dll}: {', '.join(funcs)}")
    if len(data) > end:
        print(f"\nOverlay: {end:#x} ofsetindən {len(data) - end} bayt")


if __name__ == "__main__":
    if len(sys.argv) != 2:
        sys.exit("İstifadə: peinfo.py <fayl>")
    try:
        main(sys.argv[1])
    except (PeError, struct.error, ValueError) as e:
        sys.exit(f"Xəta: {e}")
