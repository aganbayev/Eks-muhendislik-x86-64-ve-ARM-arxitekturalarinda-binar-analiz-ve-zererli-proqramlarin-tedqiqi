typedef void *HANDLE;
__declspec(dllimport) HANDLE __stdcall GetStdHandle(unsigned long n);
__declspec(dllimport) int __stdcall WriteFile(HANDLE h, const void *buf, unsigned long len,
                                              unsigned long *written, void *ovl);
__declspec(dllimport) void __stdcall ExitProcess(unsigned int code);

void start(void)
{
    static const char msg[] = "Salam, Windows!\r\n";
    unsigned long n;
    WriteFile(GetStdHandle((unsigned long)-11), msg, sizeof(msg) - 1, &n, 0);
    ExitProcess(0);
}
