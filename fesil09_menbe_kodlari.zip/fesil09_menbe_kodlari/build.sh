#!/bin/sh
# Chapter 9 (PE format) examples: build with Clang/LLD on Linux, run with Wine.
# Requires: clang/lld 18 (lld-link), llvm-dlltool, llvm-readobj, wine (64-bit, WoW64).
set -e
LINK="lld-link /nodefaultlib /subsystem:console /Brepro"

# Import libraries generated from small .def files (no Windows SDK needed)
llvm-dlltool -m i386:x86-64 -d msvcrt.def   -l msvcrt.lib
llvm-dlltool -m i386:x86-64 -d kernel32.def -l kernel32.lib
llvm-dlltool -m arm64       -d kernel32.def -l kernel32_arm64.lib
llvm-dlltool -m i386 -k     -d kernel32_x86.def -l kernel32_x86.lib

# 9.1: crackme01 (Windows variant, imports from msvcrt.dll)
clang --target=x86_64-pc-windows-msvc -O0 -c crackme01_win.c -o crackme01_win.obj
$LINK /entry:start crackme01_win.obj msvcrt.lib /out:crackme01.exe

# 9.3 / 9.6: hello_pe for x86-64, x86 (32-bit) and ARM64
clang --target=x86_64-pc-windows-msvc  -O2 -c hello_pe.c -o hello_pe.obj
$LINK /entry:start hello_pe.obj kernel32.lib /out:hello_pe.exe
clang --target=i686-pc-windows-msvc    -O2 -c hello_pe.c -o hello_x86.obj
$LINK /entry:start hello_x86.obj kernel32_x86.lib /out:hello_x86.exe
clang --target=aarch64-pc-windows-msvc -O2 -c hello_pe.c -o hello_a64.obj
$LINK /entry:start hello_a64.obj kernel32_arm64.lib /out:hello_a64.exe

# 9.7: DLL with named, ordinal-only and forwarded exports, and a client
clang --target=x86_64-pc-windows-msvc -O2 -c azelib.c -o azelib.obj
lld-link /dll /noentry /nodefaultlib /Brepro /def:azelib.def azelib.obj \
    /out:azelib.dll /implib:azelib.lib
clang --target=x86_64-pc-windows-msvc -O2 -c use_dll.c -o use_dll.obj
$LINK /entry:start use_dll.obj azelib.lib /out:use_dll.exe

# 9.9: TLS callback
clang --target=x86_64-pc-windows-msvc -O2 -c tls_demo.c -o tls_demo.obj
$LINK /entry:start tls_demo.obj kernel32.lib /out:tls_demo.exe

# Run (ARM64 file is analysed statically only)
export WINEDEBUG=-all
wine crackme01.exe AzeRev2026 || true
wine hello_pe.exe
wine hello_x86.exe
wine use_dll.exe || echo "use_dll.exe exit code: $?"
wine tls_demo.exe
