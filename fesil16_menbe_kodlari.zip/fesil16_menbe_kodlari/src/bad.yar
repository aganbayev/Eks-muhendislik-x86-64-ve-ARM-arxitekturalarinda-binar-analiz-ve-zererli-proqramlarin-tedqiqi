rule Bad_ShortStrings
{
    strings:
        $id   = "id="
        $zero = { 00 00 00 00 }
        $any  = /HELLO.*\n/
    condition:
        any of them
}
