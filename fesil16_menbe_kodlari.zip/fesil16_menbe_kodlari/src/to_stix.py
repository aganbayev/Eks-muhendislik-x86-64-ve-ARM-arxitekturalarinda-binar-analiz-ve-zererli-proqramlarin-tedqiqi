#!/usr/bin/env python3
"""to_stix.py - turns the confirmed indicators of the bot_table family into a
STIX 2.1 bundle (chapter 16, 16.6). Only indicators confirmed by static and
dynamic analysis are listed here; ioc_extract.py output is a list of candidates.
Uses only the standard library; object ids are UUIDv5, so they are stable.
Usage: to_stix.py OUT.json SAMPLE..."""
import datetime, hashlib, json, sys, uuid

NS = uuid.UUID("6ba7b811-9dad-11d1-80b4-00c04fd430c8")      # RFC 4122 URL namespace
NOW = datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.000Z")

def sid(kind, text):
    return f"{kind}--{uuid.uuid5(NS, 'azelab:' + text)}"

def indicator(name, pattern):
    return {"type": "indicator", "spec_version": "2.1", "id": sid("indicator", pattern),
            "created": NOW, "modified": NOW, "name": name,
            "indicator_types": ["malicious-activity"],
            "pattern": pattern, "pattern_type": "stix", "valid_from": NOW}

objs = [
    indicator("bot_table C2 name (XOR table entry 0)", "[domain-name:value = 'c2.example.lab']"),
    indicator("watchdog access", "[file:name = 'watchdog' AND file:parent_directory_ref.path = '/dev']"),
]
for path in sys.argv[2:]:
    h = hashlib.sha256(open(path, "rb").read()).hexdigest()
    objs.append(indicator("sample " + path.rsplit("/", 1)[-1], f"[file:hashes.'SHA-256' = '{h}']"))
bundle = {"type": "bundle", "id": sid("bundle", ",".join(o["id"] for o in objs)), "objects": objs}
json.dump(bundle, open(sys.argv[1], "w"), indent=1)
for o in objs:
    print(o["id"][:22] + "...", o["pattern"][:54])
