#!/usr/bin/env python3
"""check_stix.py - checks a STIX 2.1 bundle written by to_stix.py (chapter 16, 16.6):
required indicator properties and the pattern syntax (OASIS stix2-patterns validator,
pip install stix2-patterns). Usage: check_stix.py BUNDLE.json"""
import json, sys
from stix2patterns.validator import run_validator

REQUIRED = ["type", "spec_version", "id", "created", "modified",
            "pattern", "pattern_type", "valid_from"]
bundle = json.load(open(sys.argv[1]))
bad = 0
for o in bundle["objects"]:
    missing = [k for k in REQUIRED if k not in o]
    errors = run_validator(o["pattern"], stix_version="2.1")
    bad += bool(missing or errors)
    print(f"{o['id'][:22]}... {'OK' if not (missing or errors) else missing + errors}")
print(f"{len(bundle['objects'])} indicators, {bad} with errors")
