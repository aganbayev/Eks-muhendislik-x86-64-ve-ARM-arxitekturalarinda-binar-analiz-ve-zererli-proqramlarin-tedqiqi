# chapter 16 listings (run in /root/lab16)
== triage
$ python3 triage.py corpus/*
== ioc_extract
$ python3 ioc_extract.py ioc.json corpus/*
== ioc_json
$ python3 -m json.tool ioc.json | sed -n '1,12p'
== yara_corpus
$ for f in corpus/*; do yara azelab.yar $f; done
== yara_xor
$ yara -s -X -i AzeLab_Bot_XorTable azelab.yar corpus/bot_x86_64
$ yara -X -i AzeLab_Bot_XorTable azelab.yar corpus/bot_v2_mips
$ yara -s -X azelab.yar corpus/bot_x86_64_upx
== yara_strings
$ yara -s -i AzeLab_IoT_Beacon azelab.yar corpus/iot_beacon_mips
$ yara -s azelab.yar corpus/win_beacon.exe
$ yara -s azelab.yar corpus/antidbg_win.exe
== yara_goodware
$ find goodware -type f | wc -l
$ find goodware -type f | sed 's|/[^/]*$||' | sort | uniq -c
$ time yara -r azelab.yar goodware | wc -l
== yara_bad
$ cat bad.yar
$ yara -c bad.yar corpus/iot_beacon_mips; echo "exit=$?"
$ yara --fail-on-warnings bad.yar corpus/iot_beacon_mips; echo "exit=$?"
== yara_stats
$ yara -S azelab.yar corpus/bot_mips | head -5
$ yarac azelab.yar azelab.yarc && yara -C azelab.yarc corpus/win_beacon.exe
== hashes
$ sha256sum corpus/bot_x86_64 corpus/bot_v2_x86_64
$ ssdeep -b -d corpus/bot_* 
== stix
$ python3 to_stix.py bot_family.stix.json corpus/bot_x86_64 corpus/bot_v2_x86_64
$ python3 check_stix.py bot_family.stix.json
== confirm
$ qemu-mips -strace corpus/bot_v2_mips
$ strace -f -e trace=openat,connect corpus/iot_beacon_x86_64
== peb_objdump
$ llvm-objdump -d -M intel --no-show-raw-insn --start-address=0x14000131f --stop-address=0x14000132d corpus/antidbg_win.exe | tail -2
