#!/bin/sh
# Chapter 16 (methodology, IOC, YARA, reporting): builds the second variant of the
# chapter 15 bot sample and assembles the test corpus.
# Needs: clang/lld 18, llvm-strip, python3, UPX 5; the bin/ folders of the
# chapter 12, 13 and 15 archives (paths below) and, for the goodware set,
# the qiling rootfs repository (arm_linux, arm64_linux, mips32_linux, mips32el_linux).
set -e
L12=${L12:-../../fesil12/bin}
L13=${L13:-../../fesil13/bin}
L15=${L15:-../../fesil15/bin}
ROOTFS=${ROOTFS:-../../rootfs}
LAB=${LAB:-../lab}
NOLIBC="-O2 -static -nostdlib -fno-pic -fuse-ld=lld"
C=$LAB/corpus; G=$LAB/goodware
mkdir -p $C $G/linux $G/iot $G/pe

# 16.2: variant 2 of bot_table - other key, other banner, symbols stripped
python3 gen_table.py 0x13572468 "AZELAB-BOT v2"
clang --target=x86_64-linux-gnu $NOLIBC -mstackrealign -o $C/bot_v2_x86_64 bot_table.c
clang --target=armv7-linux-gnueabihf $NOLIBC -o $C/bot_v2_armv7 bot_table.c
clang --target=mips-linux-gnu $NOLIBC -mno-abicalls -mno-gpopt -G0 -Wl,-e,_start -o $C/bot_v2_mips bot_table.c
for a in x86_64 armv7 mips; do llvm-strip $C/bot_v2_$a; done
python3 gen_table.py                      # restore table.h of variant 1

# samples of the earlier chapters
for a in x86_64 aarch64 armv7 mips; do cp $L12/iot_beacon_$a $C/; done
for a in x86_64 armv7 mips; do cp $L15/bot_$a $L15/bot_${a}_upx $C/; done
cp $L15/bot_tampered $L15/crackme_pe_upx.exe $L15/antidbg_win.exe $L13/win_beacon.exe $C/

# goodware: system programs of the analysis machine, IoT libraries, PE launchers
for f in /usr/bin/*; do
  [ -f "$f" ] && [ ! -L "$f" ] && head -c4 "$f" | grep -q ELF && cp "$f" $G/linux/
done
for d in arm_linux arm64_linux mips32_linux mips32el_linux; do
  find $ROOTFS/$d -type f -size +8k | while read f; do
    head -c4 "$f" | grep -q ELF && cp "$f" "$G/iot/${d}_$(basename "$f")"
  done
done
cp $(python3 -c "import setuptools, os; print(os.path.dirname(setuptools.__file__))")/*.exe $G/pe/
