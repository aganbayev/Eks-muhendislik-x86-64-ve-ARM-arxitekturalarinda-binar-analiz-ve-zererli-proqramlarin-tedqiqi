#!/usr/bin/env python3
"""ioc_extract.py - collects candidate indicators of compromise from samples
(chapter 16, 16.3). Looks at ASCII and UTF-16LE strings and, for strings hidden
with a single-byte XOR (the Mirai table scheme of chapter 15), at the file
XORed with every key 0x01..0xff. Only a few indicator types are recognised:
IPv4 addresses, domain names with a known top-level domain, Unix paths under
/dev /proc /tmp /etc, registry paths and file names.
Every candidate still has to be confirmed by analysis before it goes into a report.
Usage: ioc_extract.py OUT.json FILE..."""
import json, re, sys

TLD = r"(?:com|net|org|info|xyz|ru|cn|io|lab)"
PATTERNS = [
    ("ipv4",   rb"\b(?:(?:25[0-5]|2[0-4]\d|1?\d?\d)\.){3}(?:25[0-5]|2[0-4]\d|1?\d?\d)\b"),
    ("domain", rb"\b(?:[a-z0-9-]{1,63}\.)+" + TLD.encode() + rb"\b"),
    ("path",   rb"/(?:dev|proc|tmp|etc)/[A-Za-z0-9_./-]{2,}"),
    ("regkey", rb"(?i:software)\\[A-Za-z0-9_\\]{3,}"),
    ("file",   rb"\b[A-Za-z0-9_-]{3,}\.(?:txt|exe|dll|sh|bat)\b"),
]
ASCII = re.compile(rb"[\x20-\x7e]{6,}")
WIDE = re.compile(rb"(?:[\x20-\x7e]\x00){6,}")

def strings(data):
    yield from (m.group() for m in ASCII.finditer(data))
    yield from (m.group().decode("utf-16le").encode() for m in WIDE.finditer(data))

def scan(data):
    for s in strings(data):
        for kind, rx in PATTERNS:
            for m in re.finditer(rx, s):
                yield kind, m.group().decode()

found = {}                                   # (type, value) -> {"files": [...], "xor": key}
for path in sys.argv[2:]:
    data = open(path, "rb").read()
    name = path.rsplit("/", 1)[-1]
    hits = [(k, v, 0) for k, v in scan(data)]
    for key in range(1, 256):
        table = bytes(b ^ key for b in range(256))
        hits += [(k, v, key) for k, v in scan(data.translate(table))]
    for kind, value, key in hits:
        e = found.setdefault((kind, value), {"type": kind, "value": value, "files": [], "xor": []})
        if name not in e["files"]:
            e["files"].append(name)
        if key and f"{key:#04x}" not in e["xor"]:
            e["xor"].append(f"{key:#04x}")

for e in sorted(found.values(), key=lambda e: (e["type"], e["value"])):
    xor = " xor=" + ",".join(e["xor"]) if e["xor"] else ""
    print(f"{e['type']:<7} {e['value']:<22} {len(e['files']):>2} file(s){xor}")
json.dump(sorted(found.values(), key=lambda e: (e["type"], e["value"])),
          open(sys.argv[1], "w"), indent=1)
