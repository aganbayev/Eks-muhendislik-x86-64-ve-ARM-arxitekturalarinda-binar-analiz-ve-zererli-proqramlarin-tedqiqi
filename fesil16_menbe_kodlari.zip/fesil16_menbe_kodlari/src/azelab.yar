/* azelab.yar - YARA rules for the training samples of chapters 12-16 (chapter 16, 16.4).
   Tested with YARA 4.5.4: yara -s azelab.yar FILE */
import "elf"
import "pe"
import "math"

rule AzeLab_IoT_Beacon
{
    meta:
        description = "iot_beacon (ch. 12): identifier file and greeting, any architecture"
        author = "Asif Qanbayev"
        date = "2026-11-06"
    strings:
        $path  = "/tmp/.bcn_id"
        $id    = "id=7f3a"
        $hello = /HELLO (x86_64|aarch64|armv7|mips)\n/
    condition:
        uint32(0) == 0x464c457f and filesize < 100KB and 2 of them
}

rule AzeLab_Bot_XorTable
{
    meta:
        description = "bot_table (ch. 15-16): Mirai-style string table, single-byte XOR with any key"
        author = "Asif Qanbayev"
    strings:
        $cnc = "c2.example.lab" xor(0x01-0xff)
        $wd  = "/dev/watchdog" xor(0x01-0xff)
        $tcp = "/proc/net/tcp" xor(0x01-0xff)
    condition:
        uint32(0) == 0x464c457f and 2 of them
}

rule Packed_ELF_NoSections
{
    meta:
        description = "ELF without a section table, the LOAD segment with the entry point has high entropy (UPX and its tampered copies)"
    condition:
        uint32(0) == 0x464c457f and elf.number_of_sections == 0 and
        for any s in elf.segments : (s.type == elf.PT_LOAD and
            elf.entry_point >= s.offset and elf.entry_point < s.offset + s.file_size and
            math.entropy(s.offset, s.file_size) >= 6.5)
}

rule UPX_ELF_MagicMissing
{
    meta:
        description = "Packed_ELF_NoSections, but the UPX! magic has been removed (ch. 15, 15.2)"
    strings:
        $magic = "UPX!"
        $info  = "$Info: This file is packed with the UPX"
    condition:
        Packed_ELF_NoSections and $info and not $magic
}

rule PE_UPX_Sections
{
    meta:
        description = "PE packed by UPX: empty first section, entry point in the second one"
    condition:
        uint16(0) == 0x5a4d and pe.number_of_sections >= 3 and
        pe.sections[0].raw_data_size == 0 and
        pe.sections[0].virtual_size > 0 and
        pe.entry_point >= pe.sections[1].raw_data_offset and
        pe.entry_point < pe.sections[1].raw_data_offset + pe.sections[1].raw_data_size
}

rule AzeLab_Win_Beacon
{
    meta:
        description = "win_beacon (ch. 13): registry key, temp file, whoami, socket to 127.0.0.1:2323"
    strings:
        $reg  = "Software\\AzeLab" ascii wide
        $file = "bcn_id.txt" ascii wide
        $cmd  = "whoami.exe" ascii wide nocase
    condition:
        uint16(0) == 0x5a4d and
        pe.imports("advapi32.dll", "RegSetValueExA") and
        pe.imports("ws2_32.dll", "connect") and 2 of them
}

rule Win_AntiDebug_PEB
{
    meta:
        description = "reads the PEB through gs:[0x60] and imports debugger checks (ch. 15, 15.5)"
    strings:
        // mov r64, qword ptr gs:[0x60]  (65 REX 8B ModRM 25 60 00 00 00)
        $peb = { 65 4? 8B ?? 25 60 00 00 00 }
    condition:
        uint16(0) == 0x5a4d and $peb and
        (pe.imports("kernel32.dll", "IsDebuggerPresent") or
         pe.imports("ntdll.dll", "NtQueryInformationProcess"))
}
