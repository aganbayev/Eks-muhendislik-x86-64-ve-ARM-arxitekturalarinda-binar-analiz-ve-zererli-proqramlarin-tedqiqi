#!/usr/bin/env python3
"""triage.py - first look at a set of samples (chapter 16, 16.2).
For every file: SHA-256, size, format and architecture, Shannon entropy of the
whole file, and a few structural signs that later analysis steps rely on:
ELF - number of sections (sec) and the LOAD segment with the entry point (ep);
PE  - the section with the entry point (ep) and the imphash (imp).
Usage: triage.py FILE..."""
import hashlib, math, sys
from collections import Counter
from elftools.elf.elffile import ELFFile
import pefile

def entropy(data):
    n = len(data)
    return -sum(c / n * math.log2(c / n) for c in Counter(data).values()) if n else 0.0

def elf_info(path):
    elf = ELFFile(open(path, "rb"))
    arch = {"EM_X86_64": "x86-64", "EM_AARCH64": "AArch64", "EM_ARM": "ARM",
            "EM_MIPS": "MIPS"}.get(elf["e_machine"], elf["e_machine"])
    arch += "" if elf.little_endian else " BE"
    loads = [s for s in elf.iter_segments() if s["p_type"] == "PT_LOAD"]
    entry = elf["e_entry"]
    idx = next((i for i, s in enumerate(loads)
                if s["p_vaddr"] <= entry < s["p_vaddr"] + s["p_memsz"]), -1)
    return "ELF " + arch, f"sec={elf.num_sections()} ep=LOAD[{idx}]/{len(loads)}"

def pe_info(path):
    pe = pefile.PE(path, fast_load=False)
    arch = {0x8664: "x86-64", 0x14c: "x86", 0xaa64: "ARM64"}.get(pe.FILE_HEADER.Machine, "?")
    ep = pe.OPTIONAL_HEADER.AddressOfEntryPoint
    sec = next((s.Name.rstrip(b"\0").decode() for s in pe.sections
                if s.VirtualAddress <= ep < s.VirtualAddress + s.Misc_VirtualSize), "?")
    return "PE " + arch, f"ep={sec} imp={pe.get_imphash()[:8]}"

print(f"{'file':<19} {'sha256[:12]':<12} {'size':>6} {'format':<12} {'H':>4} structure")
for path in sys.argv[1:]:
    data = open(path, "rb").read()
    if data[:4] == b"\x7fELF":
        fmt, extra = elf_info(path)
    elif data[:2] == b"MZ":
        fmt, extra = pe_info(path)
    else:
        fmt, extra = "data", ""
    name = path.rsplit("/", 1)[-1]
    print(f"{name:<19} {hashlib.sha256(data).hexdigest()[:12]} {len(data):>6} "
          f"{fmt:<12} {entropy(data):4.2f} {extra}")
