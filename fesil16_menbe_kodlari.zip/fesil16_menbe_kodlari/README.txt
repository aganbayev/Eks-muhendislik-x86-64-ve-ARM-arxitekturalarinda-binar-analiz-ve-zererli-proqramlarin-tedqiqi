Chapter 16 - Analysis methodology, indicators of compromise, YARA and reporting

src/
  build.sh          builds variant 2 of bot_table (key 0x13572468, banner "AZELAB-BOT v2",
                    stripped) and assembles the test corpus (lab/corpus) and the goodware
                    set (lab/goodware). Set L12/L13/L15 to the bin/ folders of the chapter
                    12, 13 and 15 archives and ROOTFS to a clone of the qiling rootfs
                    repository (arm_linux, arm64_linux, mips32_linux, mips32el_linux).
  bot_table.c + gen_table.py + sys12.h   the chapter 15 sample; gen_table.py now takes
                    the key and the banner as arguments (16.2)
  triage.py         SHA-256, size, format/architecture, entropy, ELF/PE structure (16.2)
  ioc_extract.py    candidate indicators from ASCII/UTF-16 strings and single-byte XOR (16.3)
  azelab.yar        seven YARA rules for the corpus (16.4)
  bad.yar           a rule that makes YARA print performance warnings (16.5)
  to_stix.py        STIX 2.1 bundle of the confirmed bot_table indicators (16.6)
  check_stix.py     checks the bundle with the OASIS stix2-patterns validator
  ch16.spec + session.py   the exact commands of every listing (run in the lab folder)
results_book/       the outputs quoted in the chapter, ioc.json and the STIX bundle

Requirements: YARA 4.5 (built with OpenSSL for the hash module), ssdeep 2.14,
Python 3 with pyelftools, pefile and stix2-patterns, clang/lld 18, qemu-user, strace.

Quick start (in an empty lab folder next to src/):
  cd src && sh build.sh && cd ../lab && cp ../src/*.py ../src/*.yar .
  python3 triage.py corpus/*
  yara -s -X azelab.yar corpus/bot_v2_mips
  yara -r azelab.yar goodware | wc -l

All samples are benign and work only with 127.0.0.1. Run them in an isolated VM.
