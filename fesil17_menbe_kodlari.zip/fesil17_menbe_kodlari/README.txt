Chapter 17 - Case study: analysis of a Windows sample (agent17.exe)

src/
  agent17.c + win17.h      the benign training sample (no CRT). It hides its configuration
                           and the ws2_32 function names in an encrypted table, allows one
                           copy via a named mutex, loads ws2_32 at run time, connects ONLY
                           to 127.0.0.1:2323, answers PING/INFO/EXIT and logs to
                           %TEMP%\azelab17.log. It runs no programs and does not persist.
  gen_cfg.py               writes cfg.h (encrypted strings); build.sh builds ../bin/agent17.exe
  kernel32.def             import library definition for lld-link
  decode_cfg.py            static decryption of the string table (17.3)
  c2_sim.py                local test server for 127.0.0.1:2323 (17.4-17.5), --pause option
  agent17.yar              file and memory YARA rules (17.6)
  x64dbg_commands.txt      the x64dbg commands of 17.4
  run_ghidra.sh + ghidra_scripts/   Ghidra 12.2 headless listings (JDK 25)
  ch17.spec + session.py   the exact commands of the Linux listings (run in the lab folder)
results_book/              Linux outputs quoted in the chapter
results_book/windows/      FLARE VM recordings (x64dbg log, c2_sim output, Procmon CSV,
                           netstat/tasklist/YARA, log file, tool versions)

Build on Linux: cd src && sh build.sh   (clang 18, lld-link, llvm-dlltool, python3)
Run the Windows part in an isolated VM (host-only network, snapshot first).
