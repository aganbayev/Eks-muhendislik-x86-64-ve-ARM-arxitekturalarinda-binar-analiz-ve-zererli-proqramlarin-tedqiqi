#!/bin/sh
# Chapter 17 (Windows case study): builds agent17.exe on Linux with Clang/LLD.
# Copy ../bin/agent17.exe, c2_sim.py and decode_cfg.py to the Windows VM (C:\lab17).
set -e
O=../bin; mkdir -p $O
python3 gen_cfg.py                                   # writes cfg.h
llvm-dlltool -m i386:x86-64 -d kernel32.def -l $O/kernel32.lib
clang --target=x86_64-pc-windows-msvc -O1 -fno-builtin -c agent17.c -o $O/agent17.obj
lld-link /nodefaultlib /entry:start /subsystem:console /Brepro \
    $O/agent17.obj $O/kernel32.lib /out:$O/agent17.exe
rm -f $O/*.obj $O/*.lib
