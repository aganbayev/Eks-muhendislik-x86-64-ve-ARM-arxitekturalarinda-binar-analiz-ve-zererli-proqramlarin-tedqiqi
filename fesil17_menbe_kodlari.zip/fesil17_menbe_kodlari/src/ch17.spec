# chapter 17 listings (run in /root/lab17)
== triage
$ python3 triage.py agent17.exe
$ llvm-readobj --coff-imports agent17.exe | grep -E "Name:|Symbol:"
== strings
$ strings -n 5 agent17.exe | sed -n '/AzL17k3y/,/kernel32/p'
== rdata_keys
$ od -A x -t x1z -j 0x12a0 -N 48 agent17.exe
== key_table
$ od -A x -t x1z -j 0x1000 -N 48 agent17.exe
== decrypt_asm
$ llvm-objdump -d -M intel --no-show-raw-insn --start-address=0x1400011c0 --stop-address=0x140001215 agent17.exe | tail -24
== decode
$ python3 decode_cfg.py agent17.exe 0x140002000 0x140002010
== yara_file
$ yara -s agent17.yar agent17.exe
$ yara -r agent17.yar /root/lab16/goodware | wc -l
$ yara -r agent17.yar /root/lab16/corpus | wc -l
