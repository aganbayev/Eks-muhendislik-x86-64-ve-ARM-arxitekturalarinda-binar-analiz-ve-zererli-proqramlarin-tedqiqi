#!/bin/sh
# Chapter 17: reproduces the Ghidra listings with analyzeHeadless (Ghidra 12.2, JDK 25).
# The scripts are the chapter 11 ones (ghidra_scripts/). Run in the folder with agent17.exe.
set -e
P=${GHIDRA_PROJ:-$HOME/gh17}; S=$(cd "$(dirname "$0")/ghidra_scripts" && pwd)
mkdir -p "$P"
clean() { grep -v -E "^(INFO|WARN|ERROR) |^    /" | sed -n '/@@BEGIN/,/@@END/p' | grep -v "^@@"; }
analyzeHeadless "$P" ch17 -import agent17.exe -overwrite -scriptPath "$S" \
    -postScript Ch11ListFunctions.java \
    -postScript Ch11Decompile.java entry FUN_1400011c0 FUN_140001a70 FUN_140001220 FUN_140001310 FUN_1400013d0 2>&1 | clean
