/* agent17.c - benign training sample for the case study of chapter 17.
 * It imitates the structure of a simple Windows bot so that the analyst has
 * something realistic to take apart, but it does nothing harmful:
 *   - the configuration and the ws2_32 function names are stored encrypted (cfg.h);
 *   - a named mutex allows only one running copy;
 *   - ws2_32 is loaded at run time, so the import table shows no network functions;
 *   - it connects ONLY to the host in the configuration (127.0.0.1:2323), sends a
 *     greeting with the computer name and answers three fixed commands
 *     (PING, INFO, EXIT); it never runs programs or touches other files;
 *   - every step is written to %TEMP%\azelab17.log.
 * No CRT: build with build.sh (clang --target=x86_64-pc-windows-msvc, lld-link). */
#include "win17.h"
#include "cfg.h"

#define NOINLINE __attribute__((noinline))   /* keep the routines separate, as in a typical build */

static char cfg[80], host[16], id[16], mutex[32], logname[32];
static unsigned short port;
static HANDLE log_h = (HANDLE)-1;

NOINLINE static void decrypt(int n, char *out)                /* the decryption routine */
{
    for (int i = 0; i < enc_str[n].len; i++)
        out[i] = enc_str[n].data[i] ^ cfg_key[i & 7] ^ (unsigned char)(i * 7);
}

NOINLINE static int get_value(const char *key, char *out, int max) /* "key=value;" parser */
{
    int k = slen(key);
    for (char *p = cfg; *p; p++) {
        if ((p == cfg || p[-1] == ';') && sncmp(p, key, k) == 0 && p[k] == '=') {
            int i = 0;
            for (p += k + 1; *p && *p != ';' && i < max - 1; p++)
                out[i++] = *p;
            out[i] = 0;
            return 1;
        }
    }
    return 0;
}

NOINLINE static void log_line(const char *a, const char *b)
{
    DWORD n;
    if (log_h == (HANDLE)-1)
        return;
    WriteFile(log_h, a, slen(a), &n, 0);
    WriteFile(log_h, b, slen(b), &n, 0);
    WriteFile(log_h, "\r\n", 2, &n, 0);
}

typedef int    (__stdcall *wsastartup_t)(unsigned short, void *);
typedef SOCKET (__stdcall *socket_t)(int, int, int);
typedef int    (__stdcall *connect_t)(SOCKET, const void *, int);
typedef int    (__stdcall *send_t)(SOCKET, const char *, int, int);
typedef int    (__stdcall *recv_t)(SOCKET, char *, int, int);
typedef int    (__stdcall *closesocket_t)(SOCKET);

NOINLINE static void *resolve(HMODULE m, int n)
{
    char name[16];
    decrypt(n, name);
    return GetProcAddress(m, name);
}

NOINLINE static void session(void)
{
    char buf[128], msg[128], tmp[16], wsa[512];
    HMODULE ws2;
    DWORD sz = 32;

    decrypt(S_WS2, buf);
    ws2 = LoadLibraryA(buf);
    wsastartup_t  pWSAStartup = (wsastartup_t)resolve(ws2, S_STARTUP);
    socket_t      pSocket     = (socket_t)resolve(ws2, S_SOCKET);
    connect_t     pConnect    = (connect_t)resolve(ws2, S_CONNECT);
    send_t        pSend       = (send_t)resolve(ws2, S_SEND);
    recv_t        pRecv       = (recv_t)resolve(ws2, S_RECV);
    closesocket_t pClose      = (closesocket_t)resolve(ws2, S_CLOSE);

    struct sockaddr_in4 sa = { 2 /* AF_INET */, (unsigned short)(port << 8 | port >> 8), {0}, {0} };
    if (!parse_ip(host, sa.addr) || pWSAStartup(0x0202, wsa) != 0)
        return;
    SOCKET s = pSocket(2, 1 /* SOCK_STREAM */, 6 /* IPPROTO_TCP */);
    if (pConnect(s, &sa, sizeof(sa)) != 0) {
        log_line("connect failed: ", host);
        pClose(s);
        return;
    }
    log_line("connected: ", host);

    msg[0] = 0;                                     /* HELLO id=<id> host=<name> */
    scat(msg, "HELLO id="); scat(msg, id); scat(msg, " host=");
    GetComputerNameA(buf, &sz);
    scat(msg, buf); scat(msg, "\n");
    pSend(s, msg, slen(msg), 0);

    for (int cmd = 0; cmd < 8; cmd++) {              /* at most 8 commands */
        int n = pRecv(s, buf, sizeof(buf) - 1, 0);
        if (n <= 0)
            break;
        while (n > 0 && (buf[n - 1] == '\n' || buf[n - 1] == '\r'))
            n--;
        buf[n] = 0;
        log_line("command: ", buf);
        if (sncmp(buf, "PING", 5) == 0) {
            pSend(s, "PONG\n", 5, 0);
        } else if (sncmp(buf, "INFO", 5) == 0) {
            msg[0] = 0;
            scat(msg, "ver=17 pid="); scat(msg, utoa(GetCurrentProcessId(), tmp)); scat(msg, "\n");
            pSend(s, msg, slen(msg), 0);
        } else if (sncmp(buf, "EXIT", 5) == 0) {
            pSend(s, "BYE\n", 4, 0);
            break;
        } else {
            pSend(s, "ERR\n", 4, 0);
        }
    }
    pClose(s);
}

void start(void)
{
    char path[300], tmp[8];

    decrypt(CFG, cfg);
    get_value("host", host, sizeof(host));
    get_value("port", tmp, sizeof(tmp));
    port = (unsigned short)atou(tmp);
    get_value("id", id, sizeof(id));
    get_value("mutex", mutex, sizeof(mutex));
    get_value("log", logname, sizeof(logname));

    CreateMutexA(0, 1, mutex);
    if (GetLastError() == 183 /* ERROR_ALREADY_EXISTS */)
        ExitProcess(1);

    DWORD n = GetTempPathA(260, path);
    for (int i = 0; logname[i]; i++)
        path[n++] = logname[i];
    path[n] = 0;
    log_h = CreateFileA(path, 0x40000000 /* GENERIC_WRITE */, 1, 0,
                        2 /* CREATE_ALWAYS */, 0x80, 0);
    log_line("start id=", id);
    session();
    log_line("stop", "");
    CloseHandle(log_h);
    ExitProcess(0);
}
