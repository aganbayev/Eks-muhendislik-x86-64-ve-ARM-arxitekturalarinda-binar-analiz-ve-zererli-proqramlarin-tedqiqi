#!/usr/bin/env python3
"""decode_cfg.py - static decryption of the agent17.exe string table (chapter 17, 17.3).
Re-implements FUN_1400011c0 recovered in Ghidra:
    out[i] = table[n].data[i] ^ key[i & 7] ^ (i * 7 & 0xff)
where the table entry is 0x52 bytes: u16 length + 80 data bytes.
Usage: decode_cfg.py FILE KEY_VA TABLE_VA [COUNT]"""
import struct, sys
import pefile

path, key_va, tab_va = sys.argv[1], int(sys.argv[2], 16), int(sys.argv[3], 16)
count = int(sys.argv[4]) if len(sys.argv) > 4 else 64
pe = pefile.PE(path)
base = pe.OPTIONAL_HEADER.ImageBase

def read(va, n):
    return pe.get_data(va - base, n)

key = read(key_va, 8)
print(f"key @ {key_va:#x}: {key!r}")
for n in range(count):
    entry = read(tab_va + n * 0x52, 0x52)
    length = struct.unpack("<H", entry[:2])[0]
    if not 0 < length <= 80:                       # end of the table
        break
    plain = bytes(b ^ key[i & 7] ^ (i * 7 & 0xff) for i, b in enumerate(entry[2:2 + length]))
    print(f"[{n}] {plain.rstrip(bytes(1)).decode('latin-1')}")
