#!/usr/bin/env python3
"""session.py - records real interactive debugger sessions for the book.

Spec file: blocks "== NAME"; inside a block
  $ cmd          shell command, output captured (a trailing "&" runs it in the
                 background and prints nothing; "gdb..." commands start an
                 interactive session on a pseudo-terminal)
  (gdb) cmd      typed into the running gdb; the transcript is exactly what the
                 terminal shows (gdb echoes the command after its prompt)
Writes out/NAME.txt. Usage: session.py spec outdir cwd [NAME...]"""
import os, pty, re, select, subprocess, sys, time, fcntl, termios, struct

ANSI = re.compile(r"\x1b\[[0-9;?]*[A-Za-z]|\x1b[=>]|\x07")

def clean(s):
    s = ANSI.sub("", s).replace("\r\n", "\n").replace("\r", "")
    return s

class Gdb:
    def __init__(self, cmd, cwd):
        pid, fd = pty.fork()
        if pid == 0:
            os.chdir(cwd)
            env = dict(os.environ, TERM="dumb", COLUMNS="200", LINES="2000")
            os.execvpe("/bin/bash", ["/bin/bash", "-c", "exec " + cmd], env)
        fcntl.ioctl(fd, termios.TIOCSWINSZ, struct.pack("HHHH", 2000, 200, 0, 0))
        self.pid, self.fd = pid, fd

    def read_until_prompt(self, timeout=30):
        buf, t0 = "", time.time()
        while time.time() - t0 < timeout:
            r, _, _ = select.select([self.fd], [], [], 0.4)
            if r:
                try:
                    data = os.read(self.fd, 65536).decode("utf-8", "replace")
                except OSError:
                    break
                buf += data
                continue
            c = clean(buf)
            if c.endswith("(gdb) ") or c.endswith("(y or n) ") or c.endswith("[answered Y; input not from terminal]\n"):
                break
        return buf

    def send(self, line):
        os.write(self.fd, (line + "\n").encode())

    def close(self):
        try:
            self.send("kill")
            self.read_until_prompt(3)
            self.send("quit")
            time.sleep(0.3)
            os.kill(self.pid, 9)
        except Exception:
            pass
        try:
            os.waitpid(self.pid, 0)
        except Exception:
            pass

def run_pty(cmd, cwd):
    """runs a shell command on a pseudo-terminal: stdout and stderr appear
    interleaved, exactly as on the analyst's screen"""
    pid, fd = pty.fork()
    if pid == 0:
        os.chdir(cwd)
        env = dict(os.environ, TERM="dumb", COLUMNS="80")
        os.execvpe("/bin/bash", ["/bin/bash", "-c", cmd], env)
    fcntl.ioctl(fd, termios.TIOCSWINSZ, struct.pack("HHHH", 2000, 80, 0, 0))
    buf = b""
    while True:
        try:
            data = os.read(fd, 65536)
        except OSError:
            break
        if not data:
            break
        buf += data
    os.waitpid(pid, 0)
    return clean(buf.decode("utf-8", "replace"))

def run_block(lines, cwd):
    out, gdb, bg = "", None, []
    for line in lines:
        if line.startswith("$ "):
            cmd = line[2:]
            if gdb:
                gdb.close(); gdb = None
            if re.match(r"(gdb|gdb-multiarch)\b", cmd):
                out += line + "\n"
                gdb = Gdb(cmd, cwd)
                first = gdb.read_until_prompt()
                c = clean(first)
                out += c[:-len("(gdb) ")] if c.endswith("(gdb) ") else c
                pending_prompt = True
            elif cmd.endswith("&"):
                out += line + "\n"
                bg.append(subprocess.Popen(cmd[:-1], shell=True, cwd=cwd,
                                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                                           executable="/bin/bash"))
                time.sleep(0.8)
            else:
                out += line + "\n"
                out += run_pty(cmd, cwd)
        elif line.startswith("(gdb) "):
            gdb.send(line[6:])
            resp = clean(gdb.read_until_prompt())
            if resp.endswith("(y or n) "):
                gdb.send("y"); resp += clean(gdb.read_until_prompt())
            # transcript: prompt + echoed command + output (next prompt removed)
            if resp.endswith("(gdb) "):
                resp = resp[:-len("(gdb) ")]
            out += "(gdb) " + resp
    if gdb:
        gdb.close()
    for p in bg:
        try:
            p.kill(); p.wait(2)
        except Exception:
            pass
    return out

def main():
    spec, outdir, cwd = sys.argv[1], sys.argv[2], sys.argv[3]
    only = sys.argv[4:]
    blocks, cur = {}, None
    for line in open(spec, encoding="utf-8"):
        line = line.rstrip("\n")
        if line.startswith("== "):
            cur = line[3:].strip(); blocks[cur] = []
        elif cur and line.strip() and not line.startswith("#"):
            blocks[cur].append(line)
    for name, lines in blocks.items():
        if only and name not in only:
            continue
        text = run_block(lines, cwd)
        text = "\n".join(l.rstrip() for l in text.rstrip("\n").split("\n")) + "\n"
        open(os.path.join(outdir, name + ".txt"), "w", encoding="utf-8").write(text)
        print("---", name); print(text)

if __name__ == "__main__":
    main()
