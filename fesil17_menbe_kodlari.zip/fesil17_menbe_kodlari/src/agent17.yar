/* agent17.yar - rules for the agent17 family (chapter 17, 17.6). YARA 4.5. */
import "pe"

rule AzeLab_Agent17_File
{
    meta:
        description = "agent17 on disk: string-table decryption loop (key[i & 7], step 7), network API resolved at run time"
        author = "Asif Qanbayev"
        date = "2026-11-06"
    strings:
        // and r11d,7 / movzx ebx,[rcx+r10] / xor bl,r8b / xor bl,[r11+r9]
        $loop = { 41 83 E? 07 42 0F B6 ?? ?? 44 30 ?? 43 32 ?? ?? }
        // add r8b,7 (the per-byte key step)
        $step = { 41 80 C? 07 }
    condition:
        uint16(0) == 0x5a4d and $loop and $step and
        pe.imports("kernel32.dll", "LoadLibraryA") and
        pe.imports("kernel32.dll", "GetProcAddress") and
        not pe.imports("ws2_32.dll")
}

rule AzeLab_Agent17_Memory
{
    meta:
        description = "agent17 in memory: decrypted configuration (scan the process: yara64 agent17.yar PID)"
    strings:
        $cfg   = /host=[0-9.]{7,15};port=[0-9]{1,5};id=[0-9a-f]{4};mutex=/
        $mutex = "Local\\AzeLab17"
    condition:
        $cfg or $mutex
}
