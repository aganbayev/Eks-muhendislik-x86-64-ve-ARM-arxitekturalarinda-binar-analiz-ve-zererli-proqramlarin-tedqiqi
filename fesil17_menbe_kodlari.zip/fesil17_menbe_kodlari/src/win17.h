/* win17.h - minimal Win32 declarations and string helpers for agent17.c (no SDK, no CRT) */
typedef void *HANDLE;
typedef void *HMODULE;
typedef unsigned long DWORD;
typedef unsigned long long SOCKET;
#define API __declspec(dllimport) __stdcall

API HANDLE  CreateFileA(const char *name, DWORD access, DWORD share, void *sa,
                        DWORD disposition, DWORD flags, HANDLE templ);
API int     WriteFile(HANDLE h, const void *buf, DWORD len, DWORD *written, void *ovl);
API int     CloseHandle(HANDLE h);
API DWORD   GetTempPathA(DWORD len, char *buf);
API HANDLE  CreateMutexA(void *sa, int owner, const char *name);
API DWORD   GetLastError(void);
API int     GetComputerNameA(char *buf, DWORD *size);
API DWORD   GetCurrentProcessId(void);
API HMODULE LoadLibraryA(const char *name);
API void   *GetProcAddress(HMODULE m, const char *name);
API void    ExitProcess(unsigned int code);

struct sockaddr_in4 { unsigned short family, port; unsigned char addr[4]; char zero[8]; };

static int slen(const char *s) { int n = 0; while (s[n]) n++; return n; }
static void scat(char *d, const char *s) { d += slen(d); while ((*d++ = *s++)) ; }
static int sncmp(const char *a, const char *b, int n)
{
    for (int i = 0; i < n; i++) {
        if (a[i] != b[i]) return 1;
        if (!a[i]) return 0;
    }
    return 0;
}
static unsigned atou(const char *s) { unsigned v = 0; while (*s >= '0' && *s <= '9') v = v * 10 + *s++ - '0'; return v; }
static char *utoa(unsigned v, char *buf)            /* buf: at least 11 bytes */
{
    char *p = buf + 10;
    *p = 0;
    do { *--p = '0' + v % 10; v /= 10; } while (v);
    return p;
}
static int parse_ip(const char *s, unsigned char out[4])
{
    for (int i = 0; i < 4; i++) {
        unsigned v = 0; int d = 0;
        while (*s >= '0' && *s <= '9') { v = v * 10 + *s++ - '0'; d++; }
        if (!d || v > 255 || (i < 3 && *s++ != '.')) return 0;
        out[i] = (unsigned char)v;
    }
    return 1;
}
