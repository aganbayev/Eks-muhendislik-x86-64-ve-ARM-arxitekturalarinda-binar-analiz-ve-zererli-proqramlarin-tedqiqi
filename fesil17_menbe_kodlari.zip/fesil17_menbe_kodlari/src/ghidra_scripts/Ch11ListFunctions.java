// Ch11ListFunctions.java - prints every function: entry, size, name (thunks with target).
//@category Ch11
import ghidra.app.script.GhidraScript;
import ghidra.program.model.listing.*;

public class Ch11ListFunctions extends GhidraScript {
    @Override
    public void run() throws Exception {
        System.out.println("@@BEGIN");
        try { body(); } finally { System.out.println("@@END"); }
    }

    private void body() throws Exception {
        for (Function f : currentProgram.getFunctionManager().getFunctions(true)) {
            ghidra.program.model.mem.MemoryBlock b = getMemoryBlock(f.getEntryPoint());
            if (b == null || !b.isExecute()) continue;      // skip the EXTERNAL block
            String extra = "";
            if (f.isThunk()) {
                Function t = f.getThunkedFunction(true);
                extra = "  thunk -> " + (t == null ? "?" : t.getName(true));
            }
            System.out.printf("%s %5d  %s%s\n", f.getEntryPoint(), f.getBody().getNumAddresses(),
                   f.getName(), extra);
        }
    }
}
