// Ch11Decompile.java - prints the decompiler output for functions given by name or address.
//@category Ch11
import ghidra.app.decompiler.*;
import ghidra.app.script.GhidraScript;
import ghidra.program.model.address.Address;
import ghidra.program.model.listing.Function;

public class Ch11Decompile extends GhidraScript {
    @Override
    public void run() throws Exception {
        System.out.println("@@BEGIN");
        try { body(); } finally { System.out.println("@@END"); }
    }

    private void body() throws Exception {
        DecompInterface ifc = new DecompInterface();
        ifc.openProgram(currentProgram);
        for (String arg : getScriptArgs()) {
            Function f = null;
            for (Function g : currentProgram.getFunctionManager().getFunctions(true))
                if (g.getName().equals(arg)) { f = g; break; }
            if (f == null) {
                Address a = toAddr(arg);
                f = getFunctionContaining(a);
            }
            if (f == null) { System.out.println("no function: " + arg); continue; }
            DecompileResults r = ifc.decompileFunction(f, 120, monitor);
            System.out.println("==== " + f.getName() + " @ " + f.getEntryPoint());
            System.out.print(r.getDecompiledFunction().getC());
        }
    }
}
