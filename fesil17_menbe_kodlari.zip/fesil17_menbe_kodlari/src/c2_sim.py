#!/usr/bin/env python3
"""c2_sim.py - local test server for agent17.exe (chapter 17, 17.5).
Listens on 127.0.0.1:2323, waits for one client, prints its greeting, sends the
commands given on the command line one by one and prints every answer.
Usage: c2_sim.py [--pause] [COMMAND...]    (default: PING INFO TEST EXIT)
--pause waits for Enter before the first command, so that the running client
can be inspected (handles, second copy, memory scan)."""
import socket, sys

args = sys.argv[1:]
pause = "--pause" in args
cmds = [a for a in args if a != "--pause"] or ["PING", "INFO", "TEST", "EXIT"]
srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
srv.bind(("127.0.0.1", 2323))
srv.listen(1)
print("listening on 127.0.0.1:2323", flush=True)
conn, addr = srv.accept()
conn.settimeout(10)
f = conn.makefile("rb")
print(f"client {addr[0]}:{addr[1]}")
print("<-", f.readline().decode().rstrip())
if pause:
    input("client connected, press Enter to send the commands ")
for c in cmds:
    conn.sendall(c.encode() + b"\n")
    print("->", c)
    line = f.readline().decode().rstrip()
    print("<-", line if line else "(connection closed)")
    if not line:
        break
conn.close()
