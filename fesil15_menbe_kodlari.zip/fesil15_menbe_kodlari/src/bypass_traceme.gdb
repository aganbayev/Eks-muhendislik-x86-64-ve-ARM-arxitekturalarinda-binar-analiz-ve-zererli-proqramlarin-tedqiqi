# bypass_traceme.gdb - imitates the kernel: first PTRACE_TRACEME -> 0, later ones -> -1
set $n = 0
catch syscall ptrace
commands
  silent
  set $n = $n + 1
  if $n == 2
    set $rax = 0
  end
  continue
end
run
