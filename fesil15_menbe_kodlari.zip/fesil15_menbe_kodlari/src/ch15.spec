# chapter 15 listings (run in /root/lab15)
== upx_pack
$ ls -l crackme01_static
$ upx -9 -qq --no-progress crackme01_static -o crackme01.packed
== upx_elf
$ readelf -lW bot_x86_64_upx | grep -E "Entry|LOAD|There are"
$ readelf -SW bot_x86_64_upx
$ strings bot_x86_64_upx | grep -E "UPX!|packed with"
== upx_pe
$ llvm-readobj --file-headers crackme_pe_upx.exe | grep -E "AddressOfEntryPoint"
$ llvm-readobj --sections crackme_pe_upx.exe | grep -E "Name:|VirtualSize:|RawDataSize:|IMAGE_SCN_MEM"
$ llvm-readobj --coff-imports crackme_pe_upx.exe | grep -E "Name:|Symbol:"
== upx_unpack
$ upx -qq -d crackme01.packed -o crackme01.unpacked
$ cmp crackme01.unpacked crackme01_static && echo identical
== upx_tamper
$ grep -c UPX! bot_armv7_upx
$ python3 -c "d=open('bot_armv7_upx','rb').read(); open('bot_tampered','wb').write(d.replace(b'UPX!', b'AZE!'))"
$ chmod +x bot_tampered && qemu-arm ./bot_tampered
$ upx -d bot_tampered -o bot_restored 2>&1 | grep Exception
$ python3 -c "d=open('bot_tampered','rb').read(); open('bot_fixed','wb').write(d.replace(b'AZE!', b'UPX!'))"
$ upx -qq -d bot_fixed -o bot_restored
$ cmp bot_restored bot_armv7 && echo identical
== gdb_dump
$ gdb -q -batch -x find_oep.gdb ./bot_x86_64_upx
$ python3 compare_dump.py bot_x86_64 bot_dump.bin 0x200000
== pe_tail
$ llvm-objdump -D --no-show-raw-insn -M intel --start-address=0x140011440 --stop-address=0x14001145f crackme_pe_upx.exe
== strings_bot
$ strings -n 6 bot_mips | grep -v AAAA
$ qemu-mips -strace ./bot_mips
== decode_static
$ python3 decode_table.py bot_x86_64 bot_armv7 bot_mips
== antidbg_run
$ ./antidbg2
$ strace -o /dev/null ./antidbg2
$ gdb -q -batch -ex run ./antidbg2
== bypass
$ gdb -q -batch -x bypass_naive.gdb ./antidbg2 2>&1 | grep Tracer
$ gdb -q -batch -x bypass_traceme.gdb ./antidbg2 2>&1 | grep Tracer
$ gdb -q -batch -x bypass_full.gdb ./antidbg2 2>&1 | grep -E "Tracer"
== vmcheck
$ ./vmcheck; echo "exit=$?"
$ grep -m1 "model name" /proc/cpuinfo
== upx_packunpack
$ upx -9 -qq --no-progress crackme01_static -o crackme01.packed
$ upx -qq -d crackme01.packed -o crackme01.unpacked
$ cmp crackme01.unpacked crackme01_static && echo identical
