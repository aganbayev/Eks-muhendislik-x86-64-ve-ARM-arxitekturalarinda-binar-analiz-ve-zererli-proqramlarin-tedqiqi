/* blob.c - 48 KB of compressible data so crackme_upx.exe is large enough for UPX */
const char config_blob[48 * 1024] = { [0 ... 48 * 1024 - 1] = 'A' };
