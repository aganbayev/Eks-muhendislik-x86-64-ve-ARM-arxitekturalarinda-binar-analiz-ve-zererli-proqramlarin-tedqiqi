#!/bin/sh
# Chapter 15 (obfuscation and anti-analysis) samples.
# Linux: gcc 13, clang/lld 18, UPX 5, python3; Windows files: lld-link, llvm-dlltool.
set -e
O=../bin; mkdir -p $O
NOLIBC="-O2 -static -nostdlib -fno-pic -fuse-ld=lld"

# 15.2: UPX on a static glibc file (UPX needs a file of a few dozen KB at least)
gcc -O0 -static -o $O/crackme01_static crackme01.c

# 15.2-15.4: IoT-bot-like sample with an XOR string table, three architectures
python3 gen_table.py                                   # writes table.h
clang --target=x86_64-linux-gnu $NOLIBC -mstackrealign -o $O/bot_x86_64 bot_table.c
clang --target=armv7-linux-gnueabihf $NOLIBC -o $O/bot_armv7 bot_table.c
clang --target=mips-linux-gnu $NOLIBC -mno-abicalls -mno-gpopt -G0 -Wl,-e,_start -o $O/bot_mips bot_table.c
for a in x86_64 armv7 mips; do upx -q -q -f -o $O/bot_${a}_upx $O/bot_$a > /dev/null; done

# 15.5: Linux anti-debugging checks, 15.6: CPUID checks
gcc -O0 -o $O/antidbg2 antidbg2.c
gcc -O0 -o $O/vmcheck vmcheck.c

# Windows (15.2, 15.3, 15.5)
L="lld-link /nodefaultlib /entry:start /subsystem:console /Brepro"
CC="clang --target=x86_64-pc-windows-msvc"
for d in kernel32 msvcrt ntdll; do llvm-dlltool -m i386:x86-64 -d $d.def -l $O/$d.lib; done
$CC -O0 -c crackme01_win.c -o $O/crackme01_win.obj
$CC -O0 -c blob.c -o $O/blob.obj
$L $O/crackme01_win.obj $O/blob.obj $O/msvcrt.lib /out:$O/crackme_pe.exe
upx -q -q -f -o $O/crackme_pe_upx.exe $O/crackme_pe.exe > /dev/null
$CC -O1 -c antidbg_win.c -o $O/antidbg_win.obj
$L $O/antidbg_win.obj $O/kernel32.lib $O/ntdll.lib /out:$O/antidbg_win.exe
rm -f $O/*.obj $O/*.lib
