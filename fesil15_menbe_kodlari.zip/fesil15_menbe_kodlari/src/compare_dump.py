#!/usr/bin/env python3
"""compare_dump.py - compares a memory dump of an unpacked process with the
PT_LOAD segments of the original (unpacked) ELF file (chapter 15, 15.3).
Usage: compare_dump.py ORIGINAL_ELF DUMP BASE_ADDRESS"""
import sys
from elftools.elf.elffile import ELFFile

elf = ELFFile(open(sys.argv[1], "rb"))
dump = open(sys.argv[2], "rb").read()
base = int(sys.argv[3], 0)
for seg in elf.iter_segments():
    if seg["p_type"] != "PT_LOAD":
        continue
    off, data = seg["p_vaddr"] - base, seg.data()
    diff = sum(a != b for a, b in zip(data, dump[off:off + len(data)]))
    print(f"{seg['p_vaddr']:#x} size {len(data):#7x} flags {seg['p_flags']}: "
          + ("identical" if diff == 0 else f"{diff} bytes differ"))
