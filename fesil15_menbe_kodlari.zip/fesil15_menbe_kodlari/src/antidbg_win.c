/* antidbg_win.c - four common Windows anti-debugging checks (chapter 15, 15.6).
 * Prints each result to the console and appends it to C:\lab15\out\antidbg.txt
 * together with the first command-line argument (a label for the run). */
typedef void *HANDLE;
typedef unsigned long DWORD;
#define API __declspec(dllimport) __stdcall
API HANDLE GetStdHandle(DWORD n);
API int    WriteFile(HANDLE h, const void *buf, DWORD len, DWORD *written, void *ovl);
API void   ExitProcess(unsigned int code);
API HANDLE CreateFileA(const char *name, DWORD access, DWORD share, void *sa,
                       DWORD disposition, DWORD flags, HANDLE templ);
API int    CloseHandle(HANDLE h);
API int    IsDebuggerPresent(void);
API HANDLE GetCurrentProcess(void);
API char  *GetCommandLineA(void);
API long   NtQueryInformationProcess(HANDLE p, int cls, void *info, DWORD len, DWORD *ret);

static HANDLE out_file;
static char line[160];
static int pos;

static void add(const char *s) { while (*s) line[pos++] = *s++; }
static void add_hex(unsigned long long v)
{
    add("0x");
    for (int i = 60; i >= 0; i -= 4)
        if ((v >> i) || i == 0) {
            for (; i >= 0; i -= 4)
                line[pos++] = "0123456789abcdef"[(v >> i) & 0xf];
            break;
        }
}
static void flush(void)
{
    DWORD n;
    line[pos++] = '\r'; line[pos++] = '\n';
    WriteFile(GetStdHandle((DWORD)-11), line, pos, &n, 0);
    if (out_file != (HANDLE)-1)
        WriteFile(out_file, line, pos, &n, 0);
    pos = 0;
}

static unsigned char *peb(void)
{
    unsigned char *p;
    __asm__("movq %%gs:0x60, %0" : "=r"(p));   /* TEB.ProcessEnvironmentBlock */
    return p;
}

void start(void)
{
    const char *cmd = GetCommandLineA(), *label = "-";
    unsigned long long port = 0;
    /* first argument after the program name = label of this run */
    if (*cmd == '"') { cmd++; while (*cmd && *cmd != '"') cmd++; if (*cmd) cmd++; }
    else while (*cmd && *cmd != ' ') cmd++;
    while (*cmd == ' ') cmd++;
    if (*cmd) label = cmd;

    out_file = CreateFileA("C:\\lab15\\out\\antidbg.txt", 4 /* FILE_APPEND_DATA */, 1, 0,
                           4 /* OPEN_ALWAYS */, 0x80, 0);
    add("run: "); add(label); flush();
    add("  IsDebuggerPresent()         = "); add_hex(IsDebuggerPresent()); flush();
    add("  PEB.BeingDebugged (+0x2)    = "); add_hex(peb()[2]); flush();
    add("  PEB.NtGlobalFlag (+0xbc)    = "); add_hex(*(unsigned int *)(peb() + 0xbc)); flush();
    NtQueryInformationProcess(GetCurrentProcess(), 7 /* ProcessDebugPort */, &port, 8, 0);
    add("  ProcessDebugPort (class 7)  = "); add_hex(port); flush();
    if (IsDebuggerPresent() || peb()[2] || (*(unsigned int *)(peb() + 0xbc) & 0x70) || port)
        add("  verdict: debugger detected");
    else
        add("  verdict: no debugger");
    flush();
    CloseHandle(out_file);
    ExitProcess(0);
}
