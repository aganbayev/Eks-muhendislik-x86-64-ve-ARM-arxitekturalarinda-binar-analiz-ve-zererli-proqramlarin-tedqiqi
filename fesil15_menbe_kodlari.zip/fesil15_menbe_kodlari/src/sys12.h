/* sys12.h - minimal Linux system calls without libc for chapter 12 samples
 * (x86-64, AArch64, ARMv7, MIPS o32). Returns -errno on error, as the kernel does. */
#ifndef SYS12_H
#define SYS12_H

#if defined(__x86_64__)
enum { NR_write = 1, NR_close = 3, NR_socket = 41, NR_connect = 42, NR_fork = 57,
       NR_exit = 60, NR_wait4 = 61, NR_openat = 257 };
static long sc4(long n, long a, long b, long c, long d)
{
    long ret;
    register long r10 __asm__("r10") = d;
    __asm__ volatile ("syscall" : "=a"(ret)
                      : "a"(n), "D"(a), "S"(b), "d"(c), "r"(r10)
                      : "rcx", "r11", "memory");
    return ret;
}
#elif defined(__aarch64__)
enum { NR_write = 64, NR_close = 57, NR_socket = 198, NR_connect = 203, NR_clone = 220,
       NR_exit = 93, NR_wait4 = 260, NR_openat = 56 };
static long sc4(long n, long a, long b, long c, long d)
{
    register long x0 __asm__("x0") = a;
    register long x1 __asm__("x1") = b;
    register long x2 __asm__("x2") = c;
    register long x3 __asm__("x3") = d;
    register long x8 __asm__("x8") = n;
    __asm__ volatile ("svc #0" : "+r"(x0) : "r"(x1), "r"(x2), "r"(x3), "r"(x8) : "memory");
    return x0;
}
#elif defined(__arm__)
enum { NR_write = 4, NR_close = 6, NR_socket = 281, NR_connect = 283, NR_fork = 2,
       NR_exit = 1, NR_wait4 = 114, NR_openat = 322 };
static long sc4(long n, long a, long b, long c, long d)
{
    register long r0 __asm__("r0") = a;
    register long r1 __asm__("r1") = b;
    register long r2 __asm__("r2") = c;
    register long r3 __asm__("r3") = d;
    register long r7 __asm__("r7") = n;
    __asm__ volatile ("svc #0" : "+r"(r0) : "r"(r1), "r"(r2), "r"(r3), "r"(r7) : "memory");
    return r0;
}
#elif defined(__mips__)
enum { NR_write = 4004, NR_close = 4006, NR_socket = 4183, NR_connect = 4170,
       NR_fork = 4002, NR_exit = 4001, NR_wait4 = 4114, NR_openat = 4288 };
static long sc4(long n, long a, long b, long c, long d)
{
    register long a0 __asm__("$4") = a;
    register long a1 __asm__("$5") = b;
    register long a2 __asm__("$6") = c;
    register long a3 __asm__("$7") = d;      /* in: 4th argument, out: error flag */
    register long v0 __asm__("$2") = n;
    __asm__ volatile ("syscall" : "+r"(v0), "+r"(a3) : "r"(a0), "r"(a1), "r"(a2)
                      : "$1", "$3", "$8", "$9", "$10", "$11", "$12", "$13",
                        "$14", "$15", "$24", "$25", "hi", "lo", "memory");
    return a3 ? -v0 : v0;
}
#else
#error "Dəstəklənməyən arxitektura"
#endif

#define sc3(n, a, b, c) sc4(n, a, b, c, 0)

static long sys_fork(void)
{
#if defined(__aarch64__)
    return sc4(NR_clone, 17 /* SIGCHLD */, 0, 0, 0);
#else
    return sc4(NR_fork, 0, 0, 0, 0);
#endif
}

static void sys_exit(long code) __attribute__((noreturn));
static void sys_exit(long code)
{
    sc3(NR_exit, code, 0, 0);
    __builtin_unreachable();
}

static unsigned short be16(unsigned short x)
{
#if __BYTE_ORDER__ == __ORDER_BIG_ENDIAN__
    return x;
#else
    return (unsigned short)(x << 8 | x >> 8);
#endif
}

#endif
