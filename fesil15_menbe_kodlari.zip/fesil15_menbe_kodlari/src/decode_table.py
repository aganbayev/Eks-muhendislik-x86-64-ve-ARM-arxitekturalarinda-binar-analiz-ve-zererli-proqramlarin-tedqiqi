#!/usr/bin/env python3
"""decode_table.py - static recovery of the bot_table string table (chapter 15, 15.4).
Reads the symbols table_key and table from an unstripped ELF (any endianness),
combines the four key bytes and decodes every entry.
Usage: decode_table.py FILE..."""
import struct, sys
from elftools.elf.elffile import ELFFile

def read_va(elf, va, size):
    for seg in elf.iter_segments():
        if seg["p_type"] == "PT_LOAD" and seg["p_vaddr"] <= va < seg["p_vaddr"] + seg["p_filesz"]:
            off = va - seg["p_vaddr"]
            return seg.data()[off:off + size]
    raise ValueError(hex(va))

for path in sys.argv[1:]:
    elf = ELFFile(open(path, "rb"))
    end = "<" if elf.little_endian else ">"
    syms = {s.name: s for s in elf.get_section_by_name(".symtab").iter_symbols()}
    key = struct.unpack(end + "I", read_va(elf, syms["table_key"]["st_value"], 4))[0]
    k = (key & 0xff) ^ (key >> 8 & 0xff) ^ (key >> 16 & 0xff) ^ (key >> 24 & 0xff)
    tab = syms["table"]
    raw = read_va(elf, tab["st_value"], tab["st_size"])
    print(f"{path}: {elf['e_machine']}, table_key = {key:#010x}, XOR byte = {k:#04x}")
    for i in range(0, len(raw), 34):                 # struct: u16 len + char[32]
        n = struct.unpack(end + "H", raw[i:i + 2])[0]
        print(f"  [{i // 34}] {bytes(b ^ k for b in raw[i + 2:i + 1 + n]).decode()!r}")
