# find_oep.gdb - lets the UPX stub unpack bot_x86_64_upx, stops at the first
# system call of the unpacked program and dumps the unpacked image (15.3)
set pagination off
set disassembly-flavor intel
catch syscall openat
run
x/2i $pc-2
x/s $rsi
info proc mappings
dump memory bot_dump.bin 0x200000 0x20f000
