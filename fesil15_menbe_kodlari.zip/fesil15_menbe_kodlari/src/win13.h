/* win13.h - minimal Win32 declarations for the chapter 13 samples (no SDK) */
typedef void *HANDLE;
typedef void *HKEY;
typedef unsigned long DWORD;
#define API __declspec(dllimport) __stdcall

API HANDLE GetStdHandle(DWORD n);
API int    WriteFile(HANDLE h, const void *buf, DWORD len, DWORD *written, void *ovl);
API void   ExitProcess(unsigned int code);
API HANDLE CreateFileA(const char *name, DWORD access, DWORD share, void *sa,
                       DWORD disposition, DWORD flags, HANDLE templ);
API int    CloseHandle(HANDLE h);
API DWORD  GetTempPathA(DWORD len, char *buf);
API DWORD  WaitForSingleObject(HANDLE h, DWORD ms);

typedef struct {                       /* STARTUPINFOA, 104 bytes on x64 */
    DWORD cb; char *reserved, *desktop, *title;
    DWORD x, y, xsize, ysize, xchars, ychars, fill, flags;
    unsigned short show, reserved2; unsigned char *reserved3;
    HANDLE in, out, err;
} STARTUPINFOA;
typedef struct { HANDLE process, thread; DWORD pid, tid; } PROCESS_INFORMATION;
API int CreateProcessA(const char *app, char *cmdline, void *psa, void *tsa, int inherit,
                       DWORD flags, void *env, const char *dir, STARTUPINFOA *si,
                       PROCESS_INFORMATION *pi);

API long RegCreateKeyExA(HKEY key, const char *sub, DWORD res, char *cls, DWORD opt,
                         DWORD sam, void *sa, HKEY *result, DWORD *disp);
API long RegSetValueExA(HKEY key, const char *name, DWORD res, DWORD type,
                        const void *data, DWORD size);
API long RegCloseKey(HKEY key);
#define HKEY_CURRENT_USER ((HKEY)(unsigned long long)0x80000001)

typedef unsigned long long SOCKET;
struct sockaddr_in4 { unsigned short family, port; unsigned char addr[4]; char zero[8]; };
API int    WSAStartup(unsigned short ver, void *data);
API int    WSACleanup(void);
API SOCKET socket(int af, int type, int proto);
API int    connect(SOCKET s, const void *addr, int len);
API int    send(SOCKET s, const char *buf, int len, int flags);
API int    closesocket(SOCKET s);

static unsigned long slen(const char *s) { unsigned long n = 0; while (s[n]) n++; return n; }
static void put_str(const char *s)
{
    DWORD n;
    WriteFile(GetStdHandle((DWORD)-11), s, slen(s), &n, 0);
}
