/* antidbg2.c - three Linux anti-debugging checks (chapter 15, 15.5):
 *   1. TracerPid in /proc/self/status (the PID of the tracer, 0 if none)
 *   2. PTRACE_TRACEME called twice: 0 the first time, -1 the second time
 *      (a debugger that simply forces 0 is caught by the second call)
 *   3. execution time of a short loop (single-stepping makes it much slower) */
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <sys/ptrace.h>

static int tracer_pid(void)
{
    char line[256];
    int pid = -1;
    FILE *f = fopen("/proc/self/status", "r");
    if (!f)
        return -1;
    while (fgets(line, sizeof(line), f))
        if (strncmp(line, "TracerPid:", 10) == 0)
            sscanf(line + 10, "%d", &pid);
    fclose(f);
    return pid;
}

static long loop_us(void)
{
    struct timespec a, b;
    volatile unsigned x = 0;
    clock_gettime(CLOCK_MONOTONIC, &a);
    for (int i = 0; i < 1000; i++)
        x += i;
    clock_gettime(CLOCK_MONOTONIC, &b);
    return (b.tv_sec - a.tv_sec) * 1000000 + (b.tv_nsec - a.tv_nsec) / 1000;
}

int main(void)
{
    int tp = tracer_pid();
    long t1 = ptrace(PTRACE_TRACEME, 0, 0, 0);
    long t2 = ptrace(PTRACE_TRACEME, 0, 0, 0);
    long us = loop_us();
    int debugged = tp != 0 || t1 != 0 || t2 != -1 || us > 1000;

    printf("TracerPid=%d traceme=%ld,%ld loop=%ldus -> %s\n",
           tp, t1, t2, us, debugged ? "DEBUGGER" : "clean");
    return debugged;
}
