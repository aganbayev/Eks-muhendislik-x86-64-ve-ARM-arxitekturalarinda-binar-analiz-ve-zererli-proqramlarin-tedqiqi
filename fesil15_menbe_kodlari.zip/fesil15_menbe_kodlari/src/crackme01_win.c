/* crackme01_win.c - 1-ci fəslin crackme01.c proqramının Windows variantı.
   Başlıq faylları olmadan yığılır; funksiyalar msvcrt.dll-dən idxal olunur. */
int printf(const char *fmt, ...);
int puts(const char *s);
int strcmp(const char *a, const char *b);
void exit(int code);
int __getmainargs(int *argc, char ***argv, char ***envp, int glob, void *si);

#define SECRET "AzeRev2026"

static int check_password(const char *input)
{
    return strcmp(input, SECRET) == 0;
}

int main(int argc, char *argv[])
{
    if (argc != 2) {
        printf("Istifade: %s <parol>\n", argv[0]);
        return 1;
    }
    if (check_password(argv[1])) {
        puts("Giris icazesi verildi!");
        return 0;
    }
    puts("Yanlis parol.");
    return 1;
}

/* C kitabxanasının başlanğıc kodunun sadə əvəzi: arqumentləri alır və main-i çağırır */
void start(void)
{
    int argc, si = 0;
    char **argv, **envp;
    __getmainargs(&argc, &argv, &envp, 0, &si);
    exit(main(argc, argv));
}
