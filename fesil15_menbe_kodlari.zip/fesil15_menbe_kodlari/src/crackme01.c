#include <stdio.h>
#include <string.h>

#define SECRET "AzeRev2026"

static int check_password(const char *input)
{
    return strcmp(input, SECRET) == 0;
}

int main(int argc, char *argv[])
{
    if (argc != 2) {
        printf("Istifade: %s <parol>\n", argv[0]);
        return 1;
    }
    if (check_password(argv[1])) {
        puts("Giris icazesi verildi!");
        return 0;
    }
    puts("Yanlis parol.");
    return 1;
}

