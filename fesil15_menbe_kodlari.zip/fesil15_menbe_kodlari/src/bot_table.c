/* bot_table.c - IoT-bot-like sample with an obfuscated string table (chapter 15).
 * The table scheme is modelled on Mirai's table.c: strings are stored XORed with
 * the bytes of a 32-bit key and decoded only right before use, then re-encoded.
 * No libc; builds for x86-64, ARMv7 and MIPS. Nothing leaves the machine. */
#include "sys12.h"
#include "table.h"

unsigned int table_key = 0xdeadbeef;       /* global, as in Mirai */

/* 48 KB configuration block: makes the file large enough for UPX (15.2) */
__attribute__((used)) static const char config_blob[48 * 1024] = { [0 ... 48 * 1024 - 1] = 'A' };

static void table_toggle(int id)            /* the same XOR decodes and encodes */
{
    unsigned char k1 = table_key & 0xff, k2 = (table_key >> 8) & 0xff,
                  k3 = (table_key >> 16) & 0xff, k4 = (table_key >> 24) & 0xff;
    for (int i = 0; i < table[id].len; i++) {
        table[id].val[i] ^= k1;
        table[id].val[i] ^= k2;
        table[id].val[i] ^= k3;
        table[id].val[i] ^= k4;
    }
}

#define O_RDWR 2                   /* same value on x86-64, ARM and MIPS */

void _start(void)
{
    long fd;

    table_toggle(TABLE_WATCHDOG);           /* Mirai disables the hardware watchdog */
    fd = sc4(NR_openat, -100, (long)table[TABLE_WATCHDOG].val, O_RDWR, 0);
    if (fd >= 0)
        sc3(NR_close, fd, 0, 0);
    table_toggle(TABLE_WATCHDOG);

    table_toggle(TABLE_PROC_TCP);           /* ...and reads the connection list */
    fd = sc4(NR_openat, -100, (long)table[TABLE_PROC_TCP].val, 0, 0);
    if (fd >= 0)
        sc3(NR_close, fd, 0, 0);
    table_toggle(TABLE_PROC_TCP);

    table_toggle(TABLE_BANNER);
    sc3(NR_write, 1, (long)table[TABLE_BANNER].val, table[TABLE_BANNER].len - 1);
    sc3(NR_write, 1, (long)"\n", 1);
    table_toggle(TABLE_BANNER);

    table_toggle(TABLE_CNC);                /* the C2 name is decoded but not used */
    table_toggle(TABLE_CNC);
    sys_exit(0);
}
