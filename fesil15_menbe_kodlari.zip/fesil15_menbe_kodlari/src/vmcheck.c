/* vmcheck.c - the two simplest CPUID-based virtual machine checks (chapter 15, 15.6).
 * CPUID leaf 1, ECX bit 31 is set by hypervisors; leaf 0x40000000 returns the
 * hypervisor vendor string ("KVMKVMKVM", "VMwareVMware", "Microsoft Hv", ...). */
#include <stdio.h>
#include <string.h>
#include <cpuid.h>

int main(void)
{
    unsigned a, b, c, d;
    char vendor[13] = {0};

    __cpuid(1, a, b, c, d);
    int hv = (c >> 31) & 1;
    printf("CPUID.1:ECX[31] (hypervisor) = %d\n", hv);
    if (hv) {
        __cpuid(0x40000000, a, b, c, d);
        memcpy(vendor, &b, 4); memcpy(vendor + 4, &c, 4); memcpy(vendor + 8, &d, 4);
        printf("CPUID.40000000h vendor        = \"%s\"\n", vendor);
    }
    return hv;
}
