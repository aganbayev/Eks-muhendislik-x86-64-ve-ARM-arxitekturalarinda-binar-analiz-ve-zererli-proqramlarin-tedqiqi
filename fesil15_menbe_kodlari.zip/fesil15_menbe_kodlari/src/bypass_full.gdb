# bypass_full.gdb - bypass_traceme.gdb plus tracer_pid() forced to return 0
set confirm off
set $n = 0
catch syscall ptrace
commands
  silent
  set $n = $n + 1
  if $n == 2
    set $rax = 0
  end
  continue
end
break tracer_pid
commands
  silent
  return (int) 0
  continue
end
run
