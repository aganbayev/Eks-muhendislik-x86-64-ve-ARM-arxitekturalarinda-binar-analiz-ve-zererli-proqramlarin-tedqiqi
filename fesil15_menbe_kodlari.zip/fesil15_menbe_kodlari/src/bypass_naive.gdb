# bypass_naive.gdb - forces every ptrace() call to return 0
set $n = 0
catch syscall ptrace
commands
  silent
  set $n = $n + 1
  if $n % 2 == 0
    set $rax = 0
  end
  continue
end
run
