Chapter 15 - Obfuscation and anti-analysis (UPX, string encryption, anti-debug)

src/
  build.sh          builds every sample (Linux: gcc, clang/lld 18, UPX 5, python3;
                    Windows .exe via lld-link + llvm-dlltool)
  bot_table.c + gen_table.py   IoT-bot-like sample with a Mirai-style XOR string table
                    (gen_table.py writes table.h), three architectures
  antidbg2.c        three Linux anti-debug checks (TracerPid, double TRACEME, timing)
  antidbg_win.c     four Windows anti-debug checks (15.5)
  vmcheck.c         CPUID hypervisor / vendor checks (15.6)
  crackme01_win.c + blob.c   PE crackme padded to a UPX-packable size
  decode_table.py   static recovery of the XOR string table from an ELF
  compare_dump.py   compares a memory dump with the original ELF segments (15.3)
  find_oep.gdb      stops a packed ELF at its first real syscall and dumps the image
  bypass_naive/traceme/full.gdb   three levels of anti-debug bypass (15.5)
  ch15.spec + session.py   the exact commands of every Linux listing
results_book/       the outputs quoted in the chapter

Windows recordings (15.3 Scylla unpacking, 15.5 ScyllaHide) are produced on the
analysis VM following lab15_windows.zip / PROTOCOL.txt.

All samples are benign: the "bot" only opens /dev/watchdog and /proc/net/tcp and
prints a banner; nothing leaves the machine. Run in an isolated VM with a snapshot.
