#include <stdio.h>

#define GREETING "Salam, dunya!"
#define SQUARE(x) ((x) * (x))

int main(void)
{
    // Bu serh preprosessor terefinden silinecek
    printf("%s %d\n", GREETING, SQUARE(7));
    return 0;
}
