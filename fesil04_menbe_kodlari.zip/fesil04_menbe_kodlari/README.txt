Chapter 4 - The laboratory environment

hello.c          test program for checking the Linux analysis VM toolchain
hello_nolibc.c   program without the C library (direct system calls) for x86-64,
                 AArch64, ARM and MIPS; used to test cross-compilers and QEMU user-mode (4.6):
                 clang --target=aarch64-linux-gnu -O2 -static -nostdlib -fuse-ld=lld -o hello_a64 hello_nolibc.c
                 qemu-aarch64 ./hello_a64
