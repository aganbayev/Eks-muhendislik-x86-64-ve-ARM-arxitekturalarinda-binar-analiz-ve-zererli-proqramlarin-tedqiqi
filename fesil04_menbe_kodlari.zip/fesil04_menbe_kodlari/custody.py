#!/usr/bin/env python3
"""Minimal chain-of-custody log for digital evidence (chapter 4.7).

Every event is one JSON line in custody.jsonl. Each record stores the
SHA-256 of the previous line ("prev"), so editing or deleting an earlier
record breaks the chain and is detected by the "verify" command.

  custody.py acquire  FILE --id ID --by NAME [--note TEXT]
  custody.py transfer FILE --id ID --by NAME --to NAME [--note TEXT]
  custody.py verify
"""
import argparse, hashlib, json, os, sys
from datetime import datetime, timezone

LOG = "custody.jsonl"

def file_hashes(path):
    h = {n: hashlib.new(n) for n in ("md5", "sha1", "sha256")}
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            for x in h.values():
                x.update(block)
    return {n: x.hexdigest() for n, x in h.items()}

def read_log():
    if not os.path.exists(LOG):
        return []
    with open(LOG, encoding="utf-8") as f:
        return [line.rstrip("\n") for line in f if line.strip()]

def append(rec):
    lines = read_log()
    rec["seq"] = len(lines) + 1
    rec["prev"] = hashlib.sha256(lines[-1].encode()).hexdigest() if lines else "0" * 64
    with open(LOG, "a", encoding="utf-8") as f:
        f.write(json.dumps(rec, ensure_ascii=False, sort_keys=True) + "\n")
    return rec

def first_record(eid):
    for line in read_log():
        r = json.loads(line)
        if r["id"] == eid and r["action"] == "acquire":
            return r
    sys.exit(f"no acquire record for {eid}")

def main():
    p = argparse.ArgumentParser()
    p.add_argument("action", choices=["acquire", "transfer", "verify"])
    p.add_argument("file", nargs="?")
    p.add_argument("--id"); p.add_argument("--by"); p.add_argument("--to")
    p.add_argument("--note", default="")
    a = p.parse_args()
    now = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")

    if a.action == "verify":
        lines, ok = read_log(), True
        for i, line in enumerate(lines):
            want = hashlib.sha256(lines[i - 1].encode()).hexdigest() if i else "0" * 64
            if json.loads(line)["prev"] != want:
                print(f"record {i + 1}: chain broken"); ok = False
        print(f"{len(lines)} records, chain {'intact' if ok else 'BROKEN'}")
        return

    h = file_hashes(a.file)
    rec = {"action": a.action, "id": a.id, "time_utc": now, "by": a.by,
           "file": os.path.basename(a.file), "size": os.path.getsize(a.file),
           "sha256": h["sha256"], "note": a.note}
    if a.action == "acquire":
        rec.update(md5=h["md5"], sha1=h["sha1"])
    else:
        rec["to"] = a.to
        rec["integrity"] = "match" if h["sha256"] == first_record(a.id)["sha256"] else "MISMATCH"
    r = append(rec)
    print(f"#{r['seq']} {r['action']:8} {r['id']} {r['sha256'][:16]}... "
          + (r.get("integrity", "") or "recorded"))

if __name__ == "__main__":
    main()
