Chapter 14 - Emulation (QEMU, Unicorn, Qiling): samples and scripts

src/
  build.sh          builds iot_beacon_mips, init14, crackme01(_enc) and the ext2 image sys/rootfs.img
  init14.c          /init of the full-system image (no libc, MIPS o32)
  iot_beacon.c, sys12.h   chapter 12 IoT-like sample
  uc_decode.py      Unicorn: runs only the decoding loop of check_password (crackme01_enc, x86-64)
  uc_funcs.py       Unicorn: calc() from test8_mips_pic (MIPS) and sum_array() from sum_a64 (AArch64)
  ql_beacon.py      Qiling: iot_beacon_mips with a fake connect() and logged write()
  ql_strcmp.py      Qiling: strcmp hook in the gcc-built crackme01 (x8664_linux_glibc2.39 rootfs)
  ch14.spec + session.py   the exact commands of every listing; re-record with
                    python3 session.py ch14.spec OUTDIR /root/lab14
  build_qemu_system.sh     QEMU 7.2.0 mips-softmmu from GitHub sources
  install_qiling_from_github.sh   Unicorn 2.1.3, Capstone 5.0.6, Keystone, gevent ... from GitHub
results_book/       the outputs quoted in the chapter

Lab layout used in the book (/root/lab14):
  sys/vmlinux.mipseb.4   https://github.com/pr0v3rbs/FirmAE_kernel-v4.1/releases/download/v1.0/vmlinux.mipseb.4
  sys/root/, sys/rootfs.img   from build.sh
  mips_rootfs/iot_beacon_mips, mips_rootfs/tmp/
  x8664_rootfs/          qilingframework/rootfs: x8664_linux_glibc2.39, plus bin/crackme01
  crackme01_enc, test8_mips_pic (chapter 11), sum_a64 (chapter 6), *.py

Full-system run:
  qemu-system-mips -M malta -m 256 -kernel vmlinux.mipseb.4 \
    -drive if=ide,format=raw,file=rootfs.img \
    -append "root=/dev/sda rw console=ttyS0 init=/init firmadyne.syscall=21 firmadyne.reboot=0 firmadyne.execute=0" \
    -nographic -no-reboot -nic none
