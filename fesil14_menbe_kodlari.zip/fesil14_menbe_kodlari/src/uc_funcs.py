#!/usr/bin/env python3
"""uc_funcs.py - calls single functions of the MIPS and AArch64 samples of
chapters 6 and 8 in Unicorn: calc(7, 5) from test8_mips_pic and
sum_array(data, 5) from sum_a64 (chapter 14, 14.3).
Usage: uc_funcs.py test8_mips_pic sum_a64"""
import sys
from elftools.elf.elffile import ELFFile
from unicorn import (Uc, UC_ARCH_MIPS, UC_MODE_MIPS32, UC_MODE_BIG_ENDIAN,
                     UC_ARCH_ARM64, UC_MODE_ARM, UC_HOOK_CODE)
from unicorn import mips_const as M, arm64_const as A
from capstone import Cs, CS_ARCH_MIPS, CS_MODE_MIPS32, CS_MODE_BIG_ENDIAN

RET = 0x7fff0000               # fake return address: emulation stops here

def load(uc, path):
    """maps every PT_LOAD segment at its own address, returns the symbol table"""
    f = open(path, "rb")
    elf = ELFFile(f)
    for seg in elf.iter_segments():
        if seg["p_type"] == "PT_LOAD":
            start = seg["p_vaddr"] & ~0xfff
            end = (seg["p_vaddr"] + seg["p_memsz"] + 0xfff) & ~0xfff
            uc.mem_map(start, end - start)
            uc.mem_write(seg["p_vaddr"], seg.data())
    syms = {s.name: s["st_value"] for s in elf.get_section_by_name(".symtab").iter_symbols()}
    uc.mem_map(RET, 0x10000)                       # page for RET and the stack
    return syms

md = Cs(CS_ARCH_MIPS, CS_MODE_MIPS32 | CS_MODE_BIG_ENDIAN)

def trace(uc, address, size, user_data):
    i = next(md.disasm(bytes(uc.mem_read(address, size)), address))
    print(f"  {address:#x}: {i.mnemonic} {i.op_str}")

# MIPS32 big-endian: calc(a0=7, a1=5) -> v0
uc = Uc(UC_ARCH_MIPS, UC_MODE_MIPS32 | UC_MODE_BIG_ENDIAN)
syms = load(uc, sys.argv[1])
uc.reg_write(M.UC_MIPS_REG_A0, 7)
uc.reg_write(M.UC_MIPS_REG_A1, 5)
uc.reg_write(M.UC_MIPS_REG_RA, RET)
uc.reg_write(M.UC_MIPS_REG_SP, RET + 0x8000)
uc.hook_add(UC_HOOK_CODE, trace)
uc.emu_start(syms["calc"], RET)
print(f"calc(7, 5) = {uc.reg_read(M.UC_MIPS_REG_V0)}")

# AArch64: sum_array(x0=&data, x1=5) -> x0; the array is in the file's data
uc = Uc(UC_ARCH_ARM64, UC_MODE_ARM)
syms = load(uc, sys.argv[2])
data = syms["_start.data"]
uc.reg_write(A.UC_ARM64_REG_X0, data)
uc.reg_write(A.UC_ARM64_REG_X1, 5)
uc.reg_write(A.UC_ARM64_REG_LR, RET)
uc.reg_write(A.UC_ARM64_REG_SP, RET + 0x8000)
uc.emu_start(syms["sum_array"], RET)
print(f"sum_array({data:#x}, 5) = {uc.reg_read(A.UC_ARM64_REG_X0)}")
