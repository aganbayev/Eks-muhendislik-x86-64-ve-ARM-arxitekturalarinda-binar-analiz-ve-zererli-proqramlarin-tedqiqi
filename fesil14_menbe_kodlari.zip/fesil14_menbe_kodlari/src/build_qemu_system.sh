#!/bin/bash
set -x
cd /home/asif/dl14/q
[ -d qemu ] || git clone -q --depth 1 --branch v7.2.0 https://github.com/qemu/qemu qemu
cd qemu
rm -rf meson tests/fp/berkeley-softfloat-3 tests/fp/berkeley-testfloat-3 ui/keycodemapdb
git clone -q https://github.com/mesonbuild/meson meson && (cd meson && git checkout -q 3a9b285)
git clone -q --depth 1 https://github.com/qemu/keycodemapdb ui/keycodemapdb
git clone -q --depth 1 https://github.com/qemu/berkeley-softfloat-3 tests/fp/berkeley-softfloat-3
git clone -q --depth 1 https://github.com/qemu/berkeley-testfloat-3 tests/fp/berkeley-testfloat-3
grep -n "HAVE_BTRFS_H" linux-user/syscall.c | head -3
mkdir -p build && cd build
../configure --prefix=/opt/qemu-system --target-list=mips-softmmu --with-git-submodules=ignore \
  --disable-werror --disable-docs --disable-gtk --disable-sdl --disable-vnc --disable-opengl \
  --disable-xen --disable-kvm --disable-slirp 2>&1 | tail -20
nice make -j2 && make install
echo QEMUDONE $?
