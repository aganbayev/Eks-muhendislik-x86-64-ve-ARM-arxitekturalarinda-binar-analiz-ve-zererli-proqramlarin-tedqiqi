#!/usr/bin/env python3
"""ql_beacon.py - runs iot_beacon_mips under Qiling (chapter 14, 14.4).
connect() is replaced by a Python function that only logs the address and
reports success; every write() is logged. Files land inside the rootfs.
Usage: ql_beacon.py ROOTFS   (ROOTFS/iot_beacon_mips must exist, ROOTFS/tmp too)"""
import struct, sys
from qiling import Qiling
from qiling.const import QL_VERBOSE, QL_INTERCEPT

def fake_connect(ql, sockfd, addr, addrlen):
    family, port = struct.unpack(">HH", ql.mem.read(addr, 4))
    ip = ".".join(str(b) for b in ql.mem.read(addr + 4, 4))
    ql.log.info(f"connect(fd={sockfd}, family={family}, {ip}:{port}) -> 0 (fake)")
    return 0

def log_write(ql, fd, buf, count):
    ql.log.info(f"write(fd={fd}, {bytes(ql.mem.read(buf, count))!r})")

rootfs = sys.argv[1]
ql = Qiling([f"{rootfs}/iot_beacon_mips"], rootfs, verbose=QL_VERBOSE.DEFAULT)
ql.os.set_syscall("connect", fake_connect, QL_INTERCEPT.CALL)
ql.os.set_syscall("write", log_write, QL_INTERCEPT.ENTER)
ql.run()
