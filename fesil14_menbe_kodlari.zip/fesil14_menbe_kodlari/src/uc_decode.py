#!/usr/bin/env python3
"""uc_decode.py - runs only the decoding loop of check_password() from
crackme01_enc (x86-64, chapter 1 exercise) in Unicorn and reads the decoded
password, without executing the program (chapter 14, 14.3).
Usage: uc_decode.py crackme01_enc"""
import sys
from elftools.elf.elffile import ELFFile
from unicorn import Uc, UC_ARCH_X86, UC_MODE_64, UC_HOOK_CODE
from unicorn.x86_const import (UC_X86_REG_RSP, UC_X86_REG_RBP, UC_X86_REG_RDI,
                               UC_X86_REG_RSI, UC_X86_REG_CL, UC_X86_REG_FS_BASE)

BASE = 0x555555554000          # where the PIE file is placed, as gdb would place it
STACK, TLS, INPUT = 0x7ff000000000, 0x7ff100000000, 0x7ff200000000
CHECK, CALL_STRCMP, STORE = 0x11a9, 0x120f, 0x11f3   # offsets from objdump

def load(uc, path):
    with open(path, "rb") as f:
        for seg in ELFFile(f).iter_segments():
            if seg["p_type"] != "PT_LOAD":
                continue
            start = (BASE + seg["p_vaddr"]) & ~0xfff
            end = (BASE + seg["p_vaddr"] + seg["p_memsz"] + 0xfff) & ~0xfff
            uc.mem_map(start, end - start)
            uc.mem_write(BASE + seg["p_vaddr"], seg.data())

def on_code(uc, address, size, user_data):
    if address == BASE + STORE:              # mov BYTE PTR [rax], cl
        cl = uc.reg_read(UC_X86_REG_CL)
        print(f"  {address - BASE:#x}: cl = {cl:#04x} {chr(cl)!r}")

uc = Uc(UC_ARCH_X86, UC_MODE_64)
load(uc, sys.argv[1])
uc.mem_map(STACK, 0x10000)
uc.mem_map(TLS, 0x1000)                     # fs:0x28 holds the stack canary
uc.mem_map(INPUT, 0x1000)
uc.mem_write(INPUT, b"test\0")
uc.reg_write(UC_X86_REG_FS_BASE, TLS)
uc.reg_write(UC_X86_REG_RSP, STACK + 0x8000)
uc.reg_write(UC_X86_REG_RBP, STACK + 0x8000)
uc.reg_write(UC_X86_REG_RDI, INPUT)          # check_password("test")
uc.hook_add(UC_HOOK_CODE, on_code, begin=BASE + STORE, end=BASE + STORE)
print(f"emulating {CHECK:#x}..{CALL_STRCMP:#x} (call strcmp is not executed)")
uc.emu_start(BASE + CHECK, BASE + CALL_STRCMP)
rsi = uc.reg_read(UC_X86_REG_RSI)
secret = bytes(uc.mem_read(rsi, 16)).split(b"\0")[0]
print(f"strcmp arguments: rdi = {bytes(uc.mem_read(INPUT, 5))[:4]!r}, rsi = {secret!r}")
