/* init14.c - minimal /init for the full-system MIPS emulation in chapter 14 (14.2).
 * No libc: prints the kernel identity, runs /iot_beacon_mips, reports its exit
 * status, shows /tmp/.bcn_id and restarts the machine (qemu -no-reboot then exits). */
#include "sys12.h"

enum { NR_execve = 4011, NR_read = 4003, NR_uname = 4122, NR_sync = 4036,
       NR_reboot = 4088 };

struct utsname { char sysname[65], nodename[65], release[65], version[65],
                 machine[65], domainname[65]; };

static unsigned long len(const char *s) { unsigned long n = 0; while (s[n]) n++; return n; }
static void out(const char *s) { sc3(NR_write, 1, (long)s, len(s)); }

static void out_dec(long v)
{
    char b[12]; int i = 11; b[i] = 0;
    if (v == 0) b[--i] = '0';
    while (v > 0) { b[--i] = '0' + v % 10; v /= 10; }
    out(b + i);
}

void _start(void)
{
    static struct utsname u;
    static char buf[64];
    char *argv[] = { "/iot_beacon_mips", 0 };
    char *envp[] = { 0 };
    int status = 0;
    long pid, fd, n;

    out("init14: ");
    if (sc3(NR_uname, (long)&u, 0, 0) == 0) {
        out(u.sysname); out(" "); out(u.release); out(" "); out(u.machine);
    }
    out("\n");
    pid = sys_fork();
    if (pid == 0) {
        sc3(NR_execve, (long)argv[0], (long)argv, (long)envp);
        sys_exit(127);
    }
    sc4(NR_wait4, pid, (long)&status, 0, 0);
    out("init14: iot_beacon_mips exit status ");
    out_dec((status >> 8) & 0xff);
    out("\n");
    fd = sc4(NR_openat, -100, (long)"/tmp/.bcn_id", 0, 0);
    if (fd >= 0) {
        n = sc3(NR_read, fd, (long)buf, sizeof(buf) - 1);
        if (n > 0) { buf[n] = 0; out("init14: /tmp/.bcn_id: "); out(buf); }
        sc3(NR_close, fd, 0, 0);
    }
    sc3(NR_sync, 0, 0, 0);
    sc4(NR_reboot, 0xfee1dead, 672274793, 0x01234567 /* RESTART */, 0);
    for (;;) ;
}
