#!/bin/bash
# Build Qiling 1.4.11 and its dependencies from GitHub sources (pip index not reachable).
set -x
cd /home/asif/dl14
clone() { [ -d "$3" ] || git clone -q --depth 1 --branch "$2" "https://github.com/$1" "$3"; }
clone capstone-engine/capstone 5.0.6 capstone
clone unicorn-engine/unicorn 2.1.3 unicorn
clone keystone-engine/keystone 0.9.2 keystone
clone erocarrera/pefile v2024.8.26 pefile
clone eliben/pyelftools v0.32 pyelftools
clone williballenthin/python-registry 1.3.1 python-registry
clone uqfoundation/dill 0.4.0 dill
clone uqfoundation/multiprocess 0.70.18 multiprocess
clone cython/cython 3.1.4 cython
clone python-greenlet/greenlet 3.2.4 greenlet
clone zopefoundation/zope.interface 7.2 zope.interface
clone zopefoundation/zope.event 5.1 zope.event
clone gevent/gevent 25.5.1 gevent
PI="python3 -m pip install --no-build-isolation --no-deps --no-index"
for d in pefile pyelftools python-registry dill multiprocess; do $PI ./$d || echo "FAIL $d"; done
$PI ./capstone/bindings/python || echo "FAIL capstone"
$PI ./unicorn/bindings/python || echo "FAIL unicorn"
$PI ./keystone/bindings/python || echo "FAIL keystone"
NO_CYTHON_COMPILE=true $PI ./cython || echo "FAIL cython"
$PI ./greenlet || echo "FAIL greenlet"
$PI ./zope.interface ./zope.event || echo "FAIL zope"
$PI ./gevent || echo "FAIL gevent"
echo DEPSDONE
