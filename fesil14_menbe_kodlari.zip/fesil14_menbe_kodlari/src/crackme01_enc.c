/* crackme01_enc.c - chapter 1 exercise: the password is stored with every
 * character code increased by 1 and decoded just before the comparison. */
#include <stdio.h>
#include <string.h>

static const char enc[] = {'B', '{', 'f', 'S', 'f', 'w', '3', '1', '3', '7', 1};

static int check_password(const char *input)
{
    char secret[sizeof(enc)];
    for (size_t i = 0; i < sizeof(enc); i++)
        secret[i] = enc[i] - 1;
    return strcmp(input, secret) == 0;
}

int main(int argc, char *argv[])
{
    if (argc != 2) {
        printf("Istifade: %s <parol>\n", argv[0]);
        return 1;
    }
    if (check_password(argv[1])) {
        puts("Giris icazesi verildi!");
        return 0;
    }
    puts("Yanlis parol.");
    return 1;
}
