#!/usr/bin/env python3
"""ql_strcmp.py - runs the gcc-built crackme01 (x86-64, glibc, BIND_NOW and
.plt.sec, the file ltrace could not trace in 12.3) under Qiling and hooks the
strcmp call (chapter 14, 14.4).
Usage: ql_strcmp.py ROOTFS   (x8664_linux_glibc2.39 rootfs with ROOTFS/bin/crackme01)"""
import sys
from qiling import Qiling
from qiling.const import QL_VERBOSE, QL_INTERCEPT

def on_strcmp(ql):
    s1 = ql.mem.string(ql.arch.regs.rdi)        # System V: 1st argument in rdi
    s2 = ql.mem.string(ql.arch.regs.rsi)        # 2nd argument in rsi
    ql.log.info(f"hook: strcmp({s1!r}, {s2!r})")

rootfs = sys.argv[1]
ql = Qiling([f"{rootfs}/bin/crackme01", "test"], rootfs, verbose=QL_VERBOSE.DEFAULT)
ql.os.set_api("strcmp", on_strcmp, QL_INTERCEPT.ENTER)
ql.run()
