/* iot_beacon.c - harmless "IoT bot-like" program for chapter 12 (no libc).
 * The child process connects to 127.0.0.1:2323 and sends a greeting, the parent
 * writes an identifier file and waits for the child. Nothing leaves the machine. */
#include "sys12.h"

#if defined(__mips__)
#define O_FLAGS (0x1 | 0x100 | 0x200)      /* O_WRONLY | O_CREAT | O_TRUNC (MIPS) */
#define SOCK_STREAM 2                       /* MIPS: SOCK_DGRAM = 1, SOCK_STREAM = 2 */
#else
#define O_FLAGS (0x1 | 0x40 | 0x200)       /* O_WRONLY | O_CREAT | O_TRUNC */
#define SOCK_STREAM 1
#endif
#define AT_FDCWD (-100)

#if defined(__x86_64__)
#define ARCH "x86_64"
#elif defined(__aarch64__)
#define ARCH "aarch64"
#elif defined(__arm__)
#define ARCH "armv7"
#else
#define ARCH "mips"
#endif

struct sockaddr_in4 {
    unsigned short family;
    unsigned short port;
    unsigned char addr[4];
    unsigned char zero[8];
};

static void beacon(void)
{
    static const char hello[] = "HELLO " ARCH "\n";
    struct sockaddr_in4 sa = { 2 /* AF_INET */, 0, {127, 0, 0, 1}, {0} };
    long s;

    sa.port = be16(2323);
    s = sc3(NR_socket, 2 /* AF_INET */, SOCK_STREAM, 0);
    if (s < 0)
        sys_exit(1);
    if (sc3(NR_connect, s, (long)&sa, sizeof(sa)) < 0)
        sys_exit(2);
    sc3(NR_write, s, (long)hello, sizeof(hello) - 1);
    sc3(NR_close, s, 0, 0);
    sys_exit(0);
}

void _start(void)
{
    static const char path[] = "/tmp/.bcn_id";
    static const char id[] = "id=7f3a\n";
    long pid, fd;
    int status = 0;

    pid = sys_fork();
    if (pid == 0)
        beacon();
    fd = sc4(NR_openat, AT_FDCWD, (long)path, O_FLAGS, 0600);
    if (fd >= 0) {
        sc3(NR_write, fd, (long)id, sizeof(id) - 1);
        sc3(NR_close, fd, 0, 0);
    }
    sc4(NR_wait4, -1, (long)&status, 0, 0);
    sys_exit((status >> 8) & 0xff);
}
