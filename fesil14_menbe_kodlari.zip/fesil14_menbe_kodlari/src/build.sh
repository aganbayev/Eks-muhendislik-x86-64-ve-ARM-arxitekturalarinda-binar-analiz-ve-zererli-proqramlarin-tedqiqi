#!/bin/sh
# Chapter 14 (emulation) samples. Needs clang/lld 18, mke2fs (e2fsprogs) and,
# for 14.2, the FirmAE MIPS big-endian kernel:
#   https://github.com/pr0v3rbs/FirmAE_kernel-v4.1/releases/download/v1.0/vmlinux.mipseb.4
# Outputs go to ../bin and ../sys.
set -e
O=../bin; S=../sys; mkdir -p $O $S/root/dev $S/root/tmp $S/root/proc
MIPS="clang --target=mips-linux-gnu -O2 -static -nostdlib -fno-pic -fuse-ld=lld -mno-abicalls -mno-gpopt -G0 -Wl,-e,_start"
$MIPS -o $O/iot_beacon_mips iot_beacon.c          # chapter 12 sample, 14.2 and 14.4
$MIPS -o $O/init14 init14.c                       # /init of the 14.2 disk image
gcc -O0 -Wl,-z,lazy -o $O/crackme01_enc crackme01_enc.c   # 14.3 (same as chapter 12)
gcc -O0 -o $O/crackme01 crackme01.c               # 14.4, Ubuntu gcc defaults (BIND_NOW, .plt.sec)
# 14.2 disk image: /init, /iot_beacon_mips, /dev/console, /dev/ttyS0, /tmp
cp $O/init14 $S/root/init
cp $O/iot_beacon_mips $S/root/
[ -e $S/root/dev/console ] || mknod $S/root/dev/console c 5 1
[ -e $S/root/dev/ttyS0 ] || mknod $S/root/dev/ttyS0 c 4 64
rm -f $S/rootfs.img
mke2fs -q -t ext2 -d $S/root $S/rootfs.img 4M
# test8_mips_pic and sum_a64 come from chapters 11 and 6 (fesil11/fasil6 archives)
