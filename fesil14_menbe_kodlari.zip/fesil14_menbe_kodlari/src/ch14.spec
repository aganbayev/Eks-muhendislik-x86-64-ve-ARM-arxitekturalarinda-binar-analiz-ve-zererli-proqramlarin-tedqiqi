# chapter 14 listings (run in /root/lab14)
== sys_boot
$ cd sys && mke2fs -q -t ext2 -d root rootfs.img 4M && ls -R root
$ cd sys && qemu-system-mips -M malta -m 256 -kernel vmlinux.mipseb.4 -drive if=ide,format=raw,file=rootfs.img -append "root=/dev/sda rw console=ttyS0 init=/init firmadyne.syscall=21 firmadyne.reboot=0 firmadyne.execute=0" -nographic -no-reboot -nic none
== uc_decode
$ python3 uc_decode.py crackme01_enc
== uc_funcs
$ python3 uc_funcs.py test8_mips_pic sum_a64
== ql_beacon
$ rm -f /tmp/.bcn_id mips_rootfs/tmp/.bcn_id
$ python3 ql_beacon.py mips_rootfs
$ cat mips_rootfs/tmp/.bcn_id; ls /tmp/.bcn_id
== ql_strcmp
$ python3 ql_strcmp.py x8664_rootfs
