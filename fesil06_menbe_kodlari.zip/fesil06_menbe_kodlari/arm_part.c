int add3(int a, int b, int c);
int call_add3(void) { return add3(1, 2, 3) * 2; }
