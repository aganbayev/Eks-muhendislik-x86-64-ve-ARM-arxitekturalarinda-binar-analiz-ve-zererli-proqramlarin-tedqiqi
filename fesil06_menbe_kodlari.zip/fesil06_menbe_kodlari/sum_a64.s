// sum_a64.s - long sum_array(const long *a, long n)
// AAPCS64: a -> x0, n -> x1, nəticə -> x0

        .text
        .global sum_array
sum_array:
        mov     x2, x0              // x2 = a
        mov     x0, #0              // s = 0
        cmp     x1, #0
        b.le    .Ldone              // n <= 0 olarsa
.Lloop:
        ldr     x3, [x2], #8        // x3 = *a; a += 8
        add     x0, x0, x3          // s += x3
        subs    x1, x1, #1          // n--, bayraqları qur
        b.ne    .Lloop
.Ldone:
        ret
