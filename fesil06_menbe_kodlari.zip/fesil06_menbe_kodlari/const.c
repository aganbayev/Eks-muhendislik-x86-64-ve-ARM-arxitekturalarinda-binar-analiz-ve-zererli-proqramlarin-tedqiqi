unsigned int big_const(void)   { return 0x12345678; }
unsigned int rot_const(void)   { return 0xff000000; }
unsigned long long a64_const(void) { return 0x1122334455667788ULL; }
long scale9(long x)            { return x * 9; }
long index_load(const long *a, long i) { return a[i]; }
