// hello_a64.s - Linux AArch64, yalnız sistem çağırışları ilə
        .section .rodata
msg:    .ascii  "Salam, ARM!\n"
        .equ    len, . - msg

        .text
        .global _start
_start:
        mov     x0, #1              // fd = stdout
        adrp    x1, msg             // buf: 4 KB-lıq səhifənin ünvanı
        add     x1, x1, :lo12:msg   // + səhifə daxilindəki ofset
        mov     x2, #len            // count
        mov     x8, #64             // write
        svc     #0

        mov     x0, #0              // status = 0
        mov     x8, #93             // exit
        svc     #0
