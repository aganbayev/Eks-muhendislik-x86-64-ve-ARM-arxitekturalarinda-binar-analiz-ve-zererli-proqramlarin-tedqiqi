int helper(int x);

int twice(int x)
{
    return helper(x) + helper(x + 1);
}
