@ hello_arm.s - Linux AArch32 (ARM rejimi), yalnız sistem çağırışları ilə
        .equ    len, 12                 @ mətnin uzunluğu

        .text
        .arm
        .global _start
_start:
        mov     r0, #1              @ fd = stdout
        ldr     r1, =msg            @ buf: ünvan literal hovuzundan
        mov     r2, #len            @ count
        mov     r7, #4              @ write
        svc     #0

        mov     r0, #0              @ status = 0
        mov     r7, #1              @ exit
        svc     #0

        .section .rodata
msg:    .ascii  "Salam, ARM!\n"
