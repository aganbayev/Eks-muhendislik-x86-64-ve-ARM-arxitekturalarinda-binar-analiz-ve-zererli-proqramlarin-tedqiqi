Chapter 6 - ARM assembly (32-bit ARM, Thumb and AArch64)

hello_arm.s, hello_a64.s   system-call "hello" programs (6.3, lab)
const.c                    constants and data processing (6.4)
sum.c                      memory access, array sum (6.5)
cmp.c                      flags and conditional execution (6.6, lab)
arm_part.c, thumb_part.c, calc.c   ARM/Thumb interworking (6.7)
crackme01.c                chapter 1 crackme, functions and calling convention (6.8)
sum_arm.s, sum_a64.s, sum_main.c   hand-written array sum called from C (lab)
caller.c, caller32.c, div.c, twice.c, hello_nolibc.c   additional examples
                           (caller32.c is also used in 8.6, hello_nolibc.c in chapter 4)
Typical build (AArch64, run with QEMU user-mode):
  clang --target=aarch64-linux-gnu -O1 -static -nostdlib -fuse-ld=lld sum_main.c sum_a64.s -o sum_a64
  clang --target=armv7-linux-gnueabihf -O2 -S calc.c
