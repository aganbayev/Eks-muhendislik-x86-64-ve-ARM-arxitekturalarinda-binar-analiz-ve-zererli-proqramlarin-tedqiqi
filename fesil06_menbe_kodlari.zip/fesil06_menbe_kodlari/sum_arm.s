@ sum_arm.s - long sum_array(const long *a, long n)
@ AAPCS: a -> r0, n -> r1, nəticə -> r0; long burada 4 baytdır

        .text
        .arm
        .global sum_array
sum_array:
        mov     r2, r0              @ r2 = a
        mov     r0, #0              @ s = 0
        cmp     r1, #0
        ble     .Ldone              @ n <= 0 olarsa
.Lloop:
        ldr     r3, [r2], #4        @ r3 = *a; a += 4
        add     r0, r0, r3          @ s += r3
        subs    r1, r1, #1          @ n--, bayraqları qur
        bne     .Lloop
.Ldone:
        bx      lr
