/* sum_main.c - C kitabxanası olmadan; cəm çıxış kodu kimi qaytarılır */

long sum_array(const long *a, long n);

static void sys_exit(long code) __attribute__((noreturn));

#if defined(__aarch64__)
static void sys_exit(long code)
{
    register long x0 __asm__("x0") = code;
    register long x8 __asm__("x8") = 93;
    __asm__ volatile ("svc #0" : : "r"(x0), "r"(x8));
    __builtin_unreachable();
}
#elif defined(__arm__)
static void sys_exit(long code)
{
    register long r0 __asm__("r0") = code;
    register long r7 __asm__("r7") = 1;
    __asm__ volatile ("svc #0" : : "r"(r0), "r"(r7));
    __builtin_unreachable();
}
#endif

void _start(void)
{
    static const long data[] = {10, 20, 30, 40, 50};
    sys_exit(sum_array(data, 5));
}
