int cmd_handler(int cmd, int x)
{
    switch (cmd) {
    case 0: return x + 1;
    case 1: return x - 7;
    case 2: return x * 3;
    case 3: return x ^ 0x5a;
    case 4: return x << 2;
    case 5: return -x;
    case 6: return x & 0xff;
    case 7: return x | 0x100;
    default: return 0;
    }
}

int sparse(int code)
{
    switch (code) {
    case 7:    return 1;
    case 100:  return 2;
    case 2000: return 3;
    case 4096: return 4;
    default:   return 0;
    }
}
