Chapter 7 - C constructs on two architectures (x86-64 and AArch64)

test7.c, grade.c   test harness and if/else example used throughout the chapter (7.1, lab)
sw.c, sw14.c       switch statements and jump tables (7.3, lab)
loops.c            loops (7.4, lab)
st.c, list.c       structures, arrays, pointers and linked lists (7.5, 7.6, lab)
divc.c, magic.c    division by constants (7.7, lab)
Build for both targets, for example:
  clang --target=x86_64-linux-gnu  -O2 -c sw.c && objdump -d -M intel sw.o
  clang --target=aarch64-linux-gnu -O2 -c sw.c && llvm-objdump -d sw.o
