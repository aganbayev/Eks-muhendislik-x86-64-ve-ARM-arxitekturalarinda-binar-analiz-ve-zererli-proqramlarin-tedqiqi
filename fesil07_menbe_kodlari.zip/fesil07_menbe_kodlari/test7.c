/* test7.c - 7-ci fəslin funksiyalarını yoxlayır; C kitabxanası olmadan.
   Çıxış kodu 0: bütün yoxlamalar keçdi, N: N nömrəli yoxlama səhvdir. */
char grade(int score);
int cmd_handler(int cmd, int x);
int sparse(int code);
int sum_squares(int n);
int count_char(const char *p, char c);
unsigned udiv10(unsigned x);
int sdiv10(int x);
int smod10(int x);
int sdiv8(int x);
struct node { int value; struct node *next; };
int list_sum(const struct node *p);

static void sys_exit(long code) __attribute__((noreturn));
#if defined(__aarch64__)
static void sys_exit(long code)
{
    register long x0 __asm__("x0") = code;
    register long x8 __asm__("x8") = 93;
    __asm__ volatile ("svc #0" : : "r"(x0), "r"(x8));
    __builtin_unreachable();
}
#elif defined(__arm__)
static void sys_exit(long code)
{
    register long r0 __asm__("r0") = code;
    register long r7 __asm__("r7") = 1;
    __asm__ volatile ("svc #0" : : "r"(r0), "r"(r7));
    __builtin_unreachable();
}
#elif defined(__x86_64__)
static void sys_exit(long code)
{
    __asm__ volatile ("syscall" : : "a"(60), "D"(code));
    __builtin_unreachable();
}
#endif

#if defined(__x86_64__)
__attribute__((force_align_arg_pointer))  /* _start-da yığın 16 bayta düzlənməyib */
#endif
void _start(void)
{
    struct node c = {3, 0}, b = {20, &c}, a = {100, &b};

    if (grade(95) != 'A' || grade(80) != 'B' ||
        grade(50) != 'C' || grade(49) != 'F')
        sys_exit(1);
    if (cmd_handler(2, 7) != 21 || cmd_handler(5, 7) != -7 ||
        cmd_handler(9, 7) != 0)
        sys_exit(2);
    if (sparse(2000) != 3 || sparse(8) != 0)
        sys_exit(3);
    if (sum_squares(10) != 385 || sum_squares(0) != 0)
        sys_exit(4);
    if (count_char("AzeRev2026", '2') != 2)
        sys_exit(5);
    if (udiv10(4294967295u) != 429496729u ||
        sdiv10(-77) != -7 || smod10(-77) != -7)
        sys_exit(6);
    if (sdiv8(-9) != -1 || sdiv8(9) != 1)
        sys_exit(7);
    if (list_sum(&a) != 123)
        sys_exit(8);
    sys_exit(0);
}
