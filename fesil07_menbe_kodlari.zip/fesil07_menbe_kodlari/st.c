struct device {
    char  type;          /* 1 bayt */
    int   id;            /* 4 bayt */
    long  last_seen;     /* 4 və ya 8 bayt */
    char *name;          /* göstərici */
    short port;          /* 2 bayt */
};

long get_last_seen(struct device *d)       { return d->last_seen; }
short get_port(struct device *d)           { return d->port; }
int get_id_at(struct device *arr, int i)   { return arr[i].id; }
unsigned long dev_size(void)               { return sizeof(struct device); }
