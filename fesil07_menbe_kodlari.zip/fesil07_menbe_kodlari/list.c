struct node {
    int          value;
    struct node *next;
};

int list_sum(const struct node *p)
{
    int s = 0;
    while (p) {
        s += p->value;
        p = p->next;
    }
    return s;
}
