int cmd_handler14(int cmd, int x)
{
    switch (cmd) {
    case 0: return x + 1;
    case 1: return x - 7;
    case 2: return x * 3;
    case 3: return x ^ 0x5a;
    case 4: return x << 2;
    case 5: return -x;
    case 6: return x & 0xff;
    case 7: return x | 0x100;
    case 8: return x >> 3;
    case 9: return x + 100;
    case 10: return x * 5;
    case 11: return ~x;
    case 12: return x - 1000;
    case 13: return x ^ 0x1234;
    default: return 0;
    }
}
