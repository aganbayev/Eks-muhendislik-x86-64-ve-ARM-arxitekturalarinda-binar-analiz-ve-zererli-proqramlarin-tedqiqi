unsigned udiv10(unsigned x) { return x / 10; }
int      sdiv10(int x)      { return x / 10; }
int      smod10(int x)      { return x % 10; }
int      sdiv8(int x)       { return x / 8; }
