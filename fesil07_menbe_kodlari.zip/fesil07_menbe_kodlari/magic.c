unsigned udiv3(unsigned x) { return x / 3; }
int      sdiv3(int x)      { return x / 3; }
unsigned udiv7(unsigned x) { return x / 7; }
int      sdiv7(int x)      { return x / 7; }
