int sum_squares(int n)
{
    int s = 0;
    for (int i = 1; i <= n; i++)
        s += i * i;
    return s;
}

int count_char(const char *p, char c)
{
    int k = 0;
    while (*p) {
        if (*p == c)
            k++;
        p++;
    }
    return k;
}
