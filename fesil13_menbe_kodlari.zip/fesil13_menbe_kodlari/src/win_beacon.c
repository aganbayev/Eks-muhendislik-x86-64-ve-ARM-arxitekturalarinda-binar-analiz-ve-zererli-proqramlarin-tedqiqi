/* win_beacon.c - harmless Windows counterpart of iot_beacon.c (chapter 13, 13.5).
 * Writes %TEMP%\bcn_id.txt, creates HKCU\Software\AzeLab\id, starts whoami.exe
 * and sends a greeting to 127.0.0.1:2323. Nothing leaves the machine. */
#include "win13.h"

static void write_id_file(void)
{
    char path[300];
    DWORD n = GetTempPathA(260, path), w;
    const char *name = "bcn_id.txt", *id = "id=7f3a\r\n";
    for (int i = 0; name[i]; i++)
        path[n++] = name[i];
    path[n] = 0;
    HANDLE h = CreateFileA(path, 0x40000000 /* GENERIC_WRITE */, 0, 0,
                           2 /* CREATE_ALWAYS */, 0x80 /* NORMAL */, 0);
    if (h != (HANDLE)-1) {
        WriteFile(h, id, slen(id), &w, 0);
        CloseHandle(h);
    }
}

static void write_registry(void)
{
    HKEY k;
    if (RegCreateKeyExA(HKEY_CURRENT_USER, "Software\\AzeLab", 0, 0, 0,
                        0x20006 /* KEY_WRITE */, 0, &k, 0) == 0) {
        RegSetValueExA(k, "id", 0, 1 /* REG_SZ */, "7f3a", 5);
        RegCloseKey(k);
    }
}

static void run_whoami(void)
{
    STARTUPINFOA si = { sizeof(si) };
    PROCESS_INFORMATION pi;
    char cmd[] = "whoami.exe";
    if (CreateProcessA(0, cmd, 0, 0, 0, 0, 0, 0, &si, &pi)) {
        WaitForSingleObject(pi.process, 5000);
        CloseHandle(pi.thread);
        CloseHandle(pi.process);
    }
}

static void beacon(void)
{
    char wsa[512];
    struct sockaddr_in4 sa = { 2 /* AF_INET */, 0x1309 /* htons(2323) */, {127, 0, 0, 1}, {0} };
    const char *hello = "HELLO win\n";
    if (WSAStartup(0x0202, wsa) != 0)
        return;
    SOCKET s = socket(2, 1 /* SOCK_STREAM */, 6 /* IPPROTO_TCP */);
    if (connect(s, &sa, sizeof(sa)) == 0) {
        send(s, hello, (int)slen(hello), 0);
        put_str("sent\r\n");
    } else {
        put_str("connect failed\r\n");
    }
    closesocket(s);
    WSACleanup();
}

void start(void)
{
    write_id_file();
    write_registry();
    run_whoami();
    beacon();
    ExitProcess(0);
}
