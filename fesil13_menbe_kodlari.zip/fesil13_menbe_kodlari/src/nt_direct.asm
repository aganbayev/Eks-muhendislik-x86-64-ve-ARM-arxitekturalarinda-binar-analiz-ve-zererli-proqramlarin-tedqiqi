; nt_direct.asm - direct system call stub for NtWriteFile (Windows 10/11 x64).
; The service number 0x8 is version specific; ntdll's own stub is identical:
;   mov r10, rcx / mov eax, 8 / syscall / ret
        bits    64
        section .text
        global  nt_write_file_direct
nt_write_file_direct:
        mov     r10, rcx            ; the kernel takes the 1st argument in r10
        mov     eax, 0x8            ; NtWriteFile service number
        syscall
        ret
