/* win_direct.c - the same file write done twice (chapter 13, 13.6):
 * line 1 through kernel32!WriteFile, line 2 through a direct syscall that
 * bypasses kernel32, kernelbase and ntdll. */
#include "win13.h"

typedef struct { long long status; unsigned long long info; } IO_STATUS_BLOCK;
long nt_write_file_direct(HANDLE h, HANDLE ev, void *apc, void *ctx, IO_STATUS_BLOCK *iosb,
                          const void *buf, DWORD len, long long *offset, DWORD *key);

void start(void)
{
    char path[300];
    DWORD n = GetTempPathA(260, path), w;
    const char *name = "direct.txt";
    const char *l1 = "1: WriteFile\r\n", *l2 = "2: syscall\r\n";
    IO_STATUS_BLOCK iosb;
    long long off = 14;                 /* write line 2 after line 1 */
    for (int i = 0; name[i]; i++)
        path[n++] = name[i];
    path[n] = 0;
    HANDLE h = CreateFileA(path, 0x40000000, 0, 0, 2, 0x80, 0);
    WriteFile(h, l1, slen(l1), &w, 0);
    long st = nt_write_file_direct(h, 0, 0, 0, &iosb, l2, slen(l2), &off, 0);
    CloseHandle(h);
    put_str(st == 0 ? "ok\r\n" : "syscall failed\r\n");
    ExitProcess(0);
}
