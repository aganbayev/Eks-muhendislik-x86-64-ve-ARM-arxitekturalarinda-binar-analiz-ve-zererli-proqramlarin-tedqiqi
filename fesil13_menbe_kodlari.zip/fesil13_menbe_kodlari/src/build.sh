#!/bin/sh
# Chapter 13 (dynamic analysis on Windows) samples: build on Linux with Clang/LLD and
# NASM, then copy the .exe files to the Windows analysis VM (C:\lab13).
set -e
O=../bin; mkdir -p $O
L="lld-link /nodefaultlib /entry:start /subsystem:console /Brepro"
CC="clang --target=x86_64-pc-windows-msvc"
for d in kernel32 msvcrt advapi32 ws2_32; do
  llvm-dlltool -m i386:x86-64 -d $d.def -l $O/$d.lib
done
# 13.2: chapter 9 crackme01 (msvcrt), 13.3: chapter 9 TLS callback, 13.4: chapter 10 dynamic import
$CC -O0 -c crackme01_win.c -o $O/crackme01_win.obj && $L $O/crackme01_win.obj $O/msvcrt.lib /out:$O/crackme01.exe
$CC -O2 -c tls_demo.c -o $O/tls_demo.obj && $L $O/tls_demo.obj $O/kernel32.lib /out:$O/tls_demo.exe
$CC -O2 -c dyn_resolve.c -o $O/dyn_resolve.obj && $L $O/dyn_resolve.obj $O/kernel32.lib /out:$O/dyn_resolve.exe
# 13.5: Procmon sample
$CC -O1 -c win_beacon.c -o $O/win_beacon.obj
$L $O/win_beacon.obj $O/kernel32.lib $O/advapi32.lib $O/ws2_32.lib /out:$O/win_beacon.exe
# 13.6: direct system call
nasm -f win64 nt_direct.asm -o $O/nt_direct.obj
$CC -O1 -c win_direct.c -o $O/win_direct.obj
$L $O/win_direct.obj $O/nt_direct.obj $O/kernel32.lib /out:$O/win_direct.exe
rm -f $O/*.obj $O/*.lib
