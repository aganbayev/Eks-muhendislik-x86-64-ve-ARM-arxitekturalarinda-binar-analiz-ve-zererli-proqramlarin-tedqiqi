@echo off
rem procmon_capture.cmd NAME   (NAME = win_beacon or win_direct)
rem Records a Process Monitor trace of C:\lab13\bin\NAME.exe and exports it to CSV.
rem Set PROCMON to the full path of Procmon64.exe if it is not in PATH.
rem Note: inside a batch file cmd waits for GUI programs, so the capturing
rem instance must be started with "start" and the control calls with "start /wait".
setlocal
set PM=%PROCMON%
if "%PM%"=="" set PM=Procmon64.exe
del C:\lab13\out\%1.pml 2> nul
start "" "%PM%" /AcceptEula /Quiet /Minimized /BackingFile C:\lab13\out\%1.pml
start /wait "" "%PM%" /WaitForIdle
C:\lab13\bin\%1.exe > C:\lab13\out\%1_stdout.txt
timeout /t 3 /nobreak > nul
start /wait "" "%PM%" /Terminate
start /wait "" "%PM%" /AcceptEula /Quiet /OpenLog C:\lab13\out\%1.pml /SaveAs C:\lab13\out\%1_all.csv
powershell -NoProfile -ExecutionPolicy Bypass -File C:\lab13\filter_csv.ps1 %1
endlocal
