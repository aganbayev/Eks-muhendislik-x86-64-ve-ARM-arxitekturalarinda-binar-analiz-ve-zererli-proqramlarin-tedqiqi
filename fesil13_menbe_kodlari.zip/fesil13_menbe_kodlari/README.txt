Chapter 13 - Dynamic analysis on Windows (x64dbg, Procmon): samples and recordings

src/            sources, .def files and build.sh (Linux: clang/lld-link 18, llvm-dlltool, NASM)
  crackme01_win.c, tls_demo.c (chapter 9), dyn_resolve.c (chapter 10)
  win_beacon.c    writes %TEMP%\bcn_id.txt, HKCU\Software\AzeLab\id, starts whoami.exe,
                  sends "HELLO win" to 127.0.0.1:2323 (13.5)
  win_direct.c + nt_direct.asm   one WriteFile and one direct NtWriteFile syscall (13.6);
                  service number 0x8 is valid for Windows 10/11 x64, check ntdll on other builds
  x64dbg_commands.txt  every x64dbg command used in the chapter
windows_lab/    PROTOCOL.txt (step-by-step recording procedure), listener.ps1,
                procmon_capture.cmd (command-line capture), filter_csv.ps1, collect.ps1
results_book/   the x64dbg logs, Procmon CSV exports and objdump output the chapter quotes

Recorded on FLARE VM, Windows 10 10.0.19045.6456, x64dbg (May 27 2026 build, ScyllaHide on),
Process Monitor 4.11. Run the samples only in an isolated VM with a snapshot.
