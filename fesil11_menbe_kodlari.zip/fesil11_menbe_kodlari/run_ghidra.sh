#!/bin/sh
# Chapter 11: reproduces the Ghidra listings of the chapter with analyzeHeadless.
# Requires Ghidra 12.2 (support/ in PATH) and JDK 25. Run from the directory with the
# built samples (../bin) after build.sh; scripts are in ../ghidra_scripts.
set -e
P=${GHIDRA_PROJ:-$HOME/gh_proj}; S=$(cd "$(dirname "$0")/ghidra_scripts" && pwd)
mkdir -p "$P"
cp "$(dirname "$0")/src/peb_types.h" . 2>/dev/null || true

echo "=== x64_a"
analyzeHeadless "$P" ch11 -import crackme01_x64_s -overwrite -scriptPath "$S" \
    -postScript Ch11ListFunctions.java \
    -postScript Ch11Xrefs.java AzeRev2026 2>&1 | grep -v -E "^(INFO|WARN) "

echo "=== x64_b"
analyzeHeadless "$P" ch11 -process crackme01_x64_s -noanalysis -scriptPath "$S" \
    -postScript Ch11Decompile.java entry 2>&1 | grep -v -E "^(INFO|WARN) "

echo "=== x64_c"
analyzeHeadless "$P" ch11 -process crackme01_x64_s -noanalysis -scriptPath "$S" \
    -postScript Ch11Name.java 00101160:main 001011f0:check_password \
    -postScript Ch11SetSig.java '00101160|int main(int argc, char **argv)' '001011f0|int check_password(char *input)' \
    -postScript Ch11Decompile.java main 2>&1 | grep -v -E "^(INFO|WARN) "

echo "=== x64_pc"
analyzeHeadless "$P" ch11 -process crackme01_x64_s -noanalysis -scriptPath "$S" \
    -postScript Ch11PcodeDump.java 0010120c 2 2>&1 | grep -v -E "^(INFO|WARN) "

echo "=== a64_a"
analyzeHeadless "$P" ch11 -import crackme01_a64_s -overwrite -scriptPath "$S" \
    -postScript Ch11ListFunctions.java \
    -postScript Ch11Name.java 001105ac:main 00110644:check_password \
    -postScript Ch11SetSig.java '001105ac|int main(int argc, char **argv)' '00110644|int check_password(char *input)' \
    -postScript Ch11Decompile.java main check_password 2>&1 | grep -v -E "^(INFO|WARN) "

echo "=== a64_pc"
analyzeHeadless "$P" ch11 -process crackme01_a64_s -noanalysis -scriptPath "$S" \
    -postScript Ch11PcodeDump.java 00110664 2 2>&1 | grep -v -E "^(INFO|WARN) "

echo "=== st_a"
analyzeHeadless "$P" ch11 -import st_x64.o -overwrite -scriptPath "$S" \
    -postScript Ch11Decompile.java get_id_at \
    -postScript Ch11ApplyDevice.java \
    -postScript Ch11SetSig.java '00100000|long get_last_seen(device *d)' '00100010|short get_port(device *d)' '00100020|int get_id_at(device *arr, int i)' \
    -postScript Ch11Decompile.java get_last_seen get_port get_id_at 2>&1 | grep -v -E "^(INFO|WARN) "

echo "=== t7arm"
analyzeHeadless "$P" ch11 -import test7_armv7_s -overwrite -scriptPath "$S" \
    -postScript Ch11Decompile.java 00020344 2>&1 | grep -v -E "^(INFO|WARN) "

echo "=== t7x64"
analyzeHeadless "$P" ch11 -import test7_x86_64_s -overwrite -scriptPath "$S" \
    -postScript Ch11Decompile.java 00201560 2>&1 | grep -v -E "^(INFO|WARN) "

echo "=== t7a64"
analyzeHeadless "$P" ch11 -import test7_aarch64_s -overwrite -scriptPath "$S" \
    -postScript Ch11ListFunctions.java 2>&1 | grep -v -E "^(INFO|WARN) "

echo "=== mips_a"
analyzeHeadless "$P" ch11 -import test8_mips_pic_s -overwrite -scriptPath "$S" \
    -postScript Ch11ListFunctions.java \
    -postScript Ch11ShowGp.java 2>&1 | grep -v -E "^(INFO|WARN) "

echo "=== mips_b"
analyzeHeadless "$P" ch11 -process test8_mips_pic_s -noanalysis -scriptPath "$S" \
    -postScript Ch11Name.java 000201d0:__start \
    -postScript Ch11Decompile.java __start 2>&1 | grep -v -E "^(INFO|WARN) "

echo "=== mips_c"
analyzeHeadless "$P" ch11 -process test8_mips_pic_s -noanalysis -scriptPath "$S" \
    -postScript Ch11SetReg.java t9 0x201d0 000201d0 000201d0 \
    -postScript Ch11Decompile.java __start 00020420 2>&1 | grep -v -E "^(INFO|WARN) "

echo "=== pe_a"
analyzeHeadless "$P" ch11 -import crackme01.exe -overwrite -scriptPath "$S" \
    -postScript Ch11ListFunctions.java \
    -postScript Ch11Listing.java 14000102f 1 140001130 1 1400020d0 1 2>&1 | grep -v -E "^(INFO|WARN) "

echo "=== peb_a"
analyzeHeadless "$P" ch11 -import peb_demo.exe -overwrite -scriptPath "$S" \
    -postScript Ch11ParseC.java peb_types.h \
    -postScript Ch11RetypeLocal.java 140001000 - PEB uVar1 peb \
    -postScript Ch11Decompile.java entry 2>&1 | grep -v -E "^(INFO|WARN) "
