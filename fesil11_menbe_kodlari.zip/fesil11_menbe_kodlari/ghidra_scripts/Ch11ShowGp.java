// Ch11ShowGp.java - prints the gp context value at each function entry.
//@category Ch11
import ghidra.app.script.GhidraScript;
import ghidra.program.model.lang.Register;
import ghidra.program.model.listing.Function;

public class Ch11ShowGp extends GhidraScript {
    @Override
    public void run() throws Exception {
        System.out.println("@@BEGIN");
        try { body(); } finally { System.out.println("@@END"); }
    }

    private void body() throws Exception {
        Register reg = currentProgram.getProgramContext().getRegister("gp");
        for (Function f : currentProgram.getFunctionManager().getFunctions(true)) {
            java.math.BigInteger v = currentProgram.getProgramContext().getValue(reg, f.getEntryPoint(), false);
            System.out.printf("%s %-16s gp=%s\n", f.getEntryPoint(), f.getName(), v == null ? "-" : "0x" + v.toString(16));
        }
    }
}
