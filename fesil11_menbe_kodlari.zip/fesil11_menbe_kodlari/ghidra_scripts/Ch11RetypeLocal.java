// Ch11RetypeLocal.java - takes a type from a Ghidra data type archive (.gdt),
// adds it to the program and gives it (as a pointer) to a decompiler variable.
// Args: function archive.gdt|- TypeName oldVarName newVarName  (- = program's own types)
//@category Ch11
import java.io.File;
import java.util.ArrayList;
import ghidra.app.decompiler.*;
import ghidra.app.script.GhidraScript;
import ghidra.framework.Application;
import ghidra.program.model.data.*;
import ghidra.program.model.listing.Function;
import ghidra.program.model.pcode.*;
import ghidra.program.model.symbol.SourceType;

public class Ch11RetypeLocal extends GhidraScript {
    @Override
    public void run() throws Exception {
        System.out.println("@@BEGIN");
        try { body(); } finally { System.out.println("@@END"); }
    }

    private void body() throws Exception {
        String[] a = getScriptArgs();
        Function f = getFunctionAt(toAddr(a[0]));
        DataType t;
        ArrayList<DataType> found = new ArrayList<>();
        if (a[1].equals("-")) {                     // type already in the program
            currentProgram.getDataTypeManager().findDataTypes(a[2], found);
            t = found.get(0);
        } else {                                    // type from a .gdt archive
            File gdt = Application.getModuleDataFile("Base", "typeinfo/win32/" + a[1]).getFile(false);
            FileDataTypeManager arch = FileDataTypeManager.openFileArchive(gdt, false);
            arch.findDataTypes(a[2], found);
            t = currentProgram.getDataTypeManager()
                .resolve(found.get(0), DataTypeConflictHandler.DEFAULT_HANDLER);
            arch.close();
        }
        DecompInterface ifc = new DecompInterface();
        ifc.openProgram(currentProgram);
        HighFunction hf = ifc.decompileFunction(f, 120, monitor).getHighFunction();
        java.util.Iterator<HighSymbol> it = hf.getLocalSymbolMap().getSymbols();
        while (it.hasNext()) {
            HighSymbol s = it.next();
            if (s.getName().equals(a[3])) {
                HighFunctionDBUtil.updateDBVariable(s, a[4],
                    currentProgram.getDataTypeManager().getPointer(t), SourceType.USER_DEFINED);
                System.out.println(a[3] + " -> " + t.getName() + " *" + a[4]);
            }
        }
    }
}
