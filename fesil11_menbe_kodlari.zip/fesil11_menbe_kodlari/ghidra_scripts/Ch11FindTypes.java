// Ch11FindTypes.java - lists data types in a .gdt archive whose name contains a substring.
// Args: archive.gdt substring ...
//@category Ch11
import java.io.File;
import java.util.Iterator;
import ghidra.app.script.GhidraScript;
import ghidra.framework.Application;
import ghidra.program.model.data.*;

public class Ch11FindTypes extends GhidraScript {
    @Override
    public void run() throws Exception {
        System.out.println("@@BEGIN");
        try { body(); } finally { System.out.println("@@END"); }
    }

    private void body() throws Exception {
        String[] a = getScriptArgs();
        File gdt = Application.getModuleDataFile("Base", "typeinfo/win32/" + a[0]).getFile(false);
        FileDataTypeManager arch = FileDataTypeManager.openFileArchive(gdt, false);
        Iterator<DataType> it = arch.getAllDataTypes();
        while (it.hasNext()) {
            DataType t = it.next();
            for (int i = 1; i < a.length; i++)
                if (t.getName().contains(a[i]))
                    System.out.println(t.getPathName() + "  " + t.getLength());
        }
        arch.close();
    }
}
