// Ch11ApplyDevice.java - creates struct device (chapter 7, st.c) in the program's
// Data Type Manager; prototypes that use it are then applied with Ch11SetSig.
//@category Ch11
import ghidra.app.script.GhidraScript;
import ghidra.program.model.data.*;

public class Ch11ApplyDevice extends GhidraScript {
    @Override
    public void run() throws Exception {
        System.out.println("@@BEGIN");
        try { body(); } finally { System.out.println("@@END"); }
    }

    private void body() throws Exception {
        DataTypeManager dtm = currentProgram.getDataTypeManager();
        StructureDataType s = new StructureDataType("device", 0, dtm);
        s.setPackingEnabled(true);
        s.add(CharDataType.dataType, "type", null);
        s.add(IntegerDataType.dataType, "id", null);
        s.add(LongDataType.dataType, "last_seen", null);
        s.add(new PointerDataType(CharDataType.dataType, dtm), "name", null);
        s.add(ShortDataType.dataType, "port", null);
        DataType dev = dtm.addDataType(s, DataTypeConflictHandler.REPLACE_HANDLER);
        System.out.println("struct device: " + dev.getLength() + " bytes");
    }
}
