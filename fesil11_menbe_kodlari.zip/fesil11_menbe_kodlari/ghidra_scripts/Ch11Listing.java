// Ch11Listing.java - prints code units the way the CodeBrowser Listing shows
// operands (with labels instead of raw addresses). Args: address count ...
//@category Ch11
import ghidra.app.script.GhidraScript;
import ghidra.program.model.listing.*;
import ghidra.program.model.symbol.Symbol;

public class Ch11Listing extends GhidraScript {
    @Override
    public void run() throws Exception {
        System.out.println("@@BEGIN");
        try { body(); } finally { System.out.println("@@END"); }
    }

    private void body() throws Exception {
        CodeUnitFormat fmt = new CodeUnitFormat(CodeUnitFormatOptions.ShowBlockName.NEVER,
                                                CodeUnitFormatOptions.ShowNamespace.NON_LOCAL);
        String[] a = getScriptArgs();
        for (int i = 0; i + 1 < a.length; i += 2) {
            CodeUnit cu = currentProgram.getListing().getCodeUnitAt(toAddr(a[i]));
            for (int n = 0; n < Integer.parseInt(a[i + 1]) && cu != null; n++) {
                Symbol s = getSymbolAt(cu.getAddress());
                if (s != null) System.out.println("                     " + s.getName() + ":");
                System.out.printf("  %s  %s\n", cu.getAddress(), fmt.getRepresentationString(cu));
                cu = currentProgram.getListing().getCodeUnitAfter(cu.getAddress());
            }
        }
    }
}
