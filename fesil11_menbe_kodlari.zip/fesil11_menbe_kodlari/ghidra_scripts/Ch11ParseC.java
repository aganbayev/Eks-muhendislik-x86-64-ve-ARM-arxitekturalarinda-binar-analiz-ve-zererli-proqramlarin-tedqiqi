// Ch11ParseC.java - parses C type definitions from a header file into the
// program's data types (Data Type Manager > Parse C Source). Arg: header path
//@category Ch11
import java.nio.file.*;
import ghidra.app.script.GhidraScript;
import ghidra.app.util.cparser.C.CParser;
import ghidra.program.model.data.*;

public class Ch11ParseC extends GhidraScript {
    @Override
    public void run() throws Exception {
        System.out.println("@@BEGIN");
        try { body(); } finally { System.out.println("@@END"); }
    }

    private void body() throws Exception {
        DataTypeManager dtm = currentProgram.getDataTypeManager();
        CParser parser = new CParser(dtm, true, null);
        parser.parse(Files.readString(Path.of(getScriptArgs()[0])));
        for (String n : parser.getComposites().keySet()) {
            DataType t = parser.getComposites().get(n);
            System.out.println(t.getName() + ": " + t.getLength() + " bytes");
        }
    }
}
