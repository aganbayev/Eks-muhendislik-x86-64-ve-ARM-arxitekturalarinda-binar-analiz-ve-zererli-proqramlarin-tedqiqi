// Ch11SetReg.java - sets a register value in the program context (what the
// "Set Register Values" dialog does in CodeBrowser).
// Args: register value [start end]; without a range, all executable memory.
//@category Ch11
import java.math.BigInteger;
import ghidra.app.script.GhidraScript;
import ghidra.program.model.address.*;
import ghidra.program.model.lang.Register;
import ghidra.program.model.listing.ProgramContext;

public class Ch11SetReg extends GhidraScript {
    @Override
    public void run() throws Exception {
        System.out.println("@@BEGIN");
        try { body(); } finally { System.out.println("@@END"); }
    }

    private void body() throws Exception {
        String[] a = getScriptArgs();
        ProgramContext ctx = currentProgram.getProgramContext();
        Register reg = ctx.getRegister(a[0]);
        BigInteger v = new BigInteger(a[1].replace("0x", ""), 16);
        if (a.length == 4) {
            ctx.setValue(reg, toAddr(a[2]), toAddr(a[3]), v);
        } else {
            for (AddressRange r : currentProgram.getMemory().getExecuteSet())
                ctx.setValue(reg, r.getMinAddress(), r.getMaxAddress(), v);
        }
        System.out.println(reg.getName() + " = 0x" + v.toString(16));
    }
}
