// Ch11PcodeDump.java - prints instructions and their raw P-code. Args: address count
//@category Ch11
import ghidra.app.script.GhidraScript;
import ghidra.program.model.listing.Instruction;
import ghidra.program.model.pcode.PcodeOp;
import ghidra.program.model.pcode.Varnode;
import ghidra.program.model.lang.Register;

public class Ch11PcodeDump extends GhidraScript {
    // register -> its name, unique -> $U<offset>:<size>, constant -> value:size
    private String vn(Varnode v) {
        if (v.isRegister()) {
            Register r = currentProgram.getRegister(v.getAddress(), v.getSize());
            if (r != null) return r.getName();
        }
        if (v.isUnique()) return "$U" + Long.toHexString(v.getOffset()) + ":" + v.getSize();
        if (v.isConstant()) return "0x" + Long.toHexString(v.getOffset()) + ":" + v.getSize();
        return "*[" + v.getAddress().getAddressSpace().getName() + "]0x"
               + Long.toHexString(v.getOffset()) + ":" + v.getSize();
    }

    @Override
    public void run() throws Exception {
        System.out.println("@@BEGIN");
        try { body(); } finally { System.out.println("@@END"); }
    }

    private void body() throws Exception {
        String[] a = getScriptArgs();
        Instruction ins = getInstructionAt(toAddr(a[0]));
        for (int i = 0; i < Integer.parseInt(a[1]) && ins != null; i++, ins = ins.getNext()) {
            System.out.println(ins.getAddress() + "  " + ins);
            for (PcodeOp op : ins.getPcode()) {
                StringBuilder sb = new StringBuilder("    ");
                if (op.getOutput() != null) sb.append(vn(op.getOutput())).append(" = ");
                sb.append(op.getMnemonic());
                for (int k = 0; k < op.getNumInputs(); k++)
                    sb.append(k == 0 ? " " : ", ").append(vn(op.getInput(k)));
                System.out.println(sb);
            }
        }
    }
}
