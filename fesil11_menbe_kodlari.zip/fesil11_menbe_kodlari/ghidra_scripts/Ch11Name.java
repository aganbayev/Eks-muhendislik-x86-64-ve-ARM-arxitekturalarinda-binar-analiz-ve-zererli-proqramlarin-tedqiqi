// Ch11Name.java - creates a function if needed and names it. Args: address:name ...
//@category Ch11
import ghidra.app.script.GhidraScript;
import ghidra.program.model.address.Address;
import ghidra.program.model.listing.Function;
import ghidra.program.model.symbol.SourceType;

public class Ch11Name extends GhidraScript {
    @Override
    public void run() throws Exception {
        System.out.println("@@BEGIN");
        try { body(); } finally { System.out.println("@@END"); }
    }

    private void body() throws Exception {
        for (String arg : getScriptArgs()) {
            String[] p = arg.split(":");
            Address a = toAddr(p[0]);
            Function f = getFunctionAt(a);
            if (f == null) {
                disassemble(a);
                f = createFunction(a, p[1]);
                System.out.println(a + "  function created: " + p[1]);
            } else {
                System.out.println(a + "  " + f.getName() + " -> " + p[1]);
                f.setName(p[1], SourceType.USER_DEFINED);
            }
        }
    }
}
