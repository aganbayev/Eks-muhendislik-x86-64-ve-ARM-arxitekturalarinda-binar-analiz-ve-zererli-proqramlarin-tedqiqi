// Ch11Xrefs.java - finds a defined string and prints all references to it.
//@category Ch11
import ghidra.app.script.GhidraScript;
import ghidra.program.model.listing.*;
import ghidra.program.model.symbol.Reference;

public class Ch11Xrefs extends GhidraScript {
    @Override
    public void run() throws Exception {
        System.out.println("@@BEGIN");
        try { body(); } finally { System.out.println("@@END"); }
    }

    private void body() throws Exception {
        String text = getScriptArgs()[0];
        for (Data d : currentProgram.getListing().getDefinedData(true)) {
            Object v = d.getValue();
            if (v instanceof String && v.equals(text)) {
                System.out.printf("%s %s \"%s\"\n", d.getAddress(), d.getLabel(), v);
                for (Reference r : getReferencesTo(d.getAddress())) {
                    if (getInstructionAt(r.getFromAddress()) == null) continue;
                    Function f = getFunctionContaining(r.getFromAddress());
                    System.out.printf("  %s %-6s %s  %s\n", r.getFromAddress(), r.getReferenceType(),
                           f == null ? "-" : f.getName(), getInstructionAt(r.getFromAddress()));
                }
            }
        }
    }
}
