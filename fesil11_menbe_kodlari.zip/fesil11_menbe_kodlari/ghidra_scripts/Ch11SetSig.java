// Ch11SetSig.java - applies C prototypes. Args: "address|prototype" ...
//   e.g. "00101170|int check_password(char *input)"
//@category Ch11
import ghidra.app.cmd.function.ApplyFunctionSignatureCmd;
import ghidra.app.script.GhidraScript;
import ghidra.app.util.parser.FunctionSignatureParser;
import ghidra.program.model.data.FunctionDefinitionDataType;
import ghidra.program.model.listing.Function;
import ghidra.program.model.symbol.SourceType;

public class Ch11SetSig extends GhidraScript {
    @Override
    public void run() throws Exception {
        System.out.println("@@BEGIN");
        try { body(); } finally { System.out.println("@@END"); }
    }

    private void body() throws Exception {
        FunctionSignatureParser parser =
            new FunctionSignatureParser(currentProgram.getDataTypeManager(), null);
        for (String arg : getScriptArgs()) {
            String[] p = arg.split("\\|", 2);
            Function f = getFunctionAt(toAddr(p[0]));
            FunctionDefinitionDataType sig = parser.parse(f.getSignature(), p[1]);
            new ApplyFunctionSignatureCmd(f.getEntryPoint(), sig, SourceType.USER_DEFINED)
                .applyTo(currentProgram, monitor);
            f.setCallingConvention(currentProgram.getCompilerSpec()
                .getDefaultCallingConvention().getName());
            System.out.println(f.getEntryPoint() + "  " + f.getPrototypeString(false, false));
        }
    }
}
