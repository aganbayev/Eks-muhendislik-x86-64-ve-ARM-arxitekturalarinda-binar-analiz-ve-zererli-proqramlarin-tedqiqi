#!/bin/sh
# Chapter 11: radare2 listings (run in ../bin after build.sh).
# ~/.radare2rc used for the book: e scr.color=0 / e scr.utf8=false
set -x
r2 -q -c 'aaa; afl; iz; axt @ str.AzeRev2026' crackme01_x64_s 2>/dev/null
r2 -q -e asm.bytes=false -e asm.comments=false \
   -c 'aaa; afn check_password @ fcn.000011f0; pdf @ check_password' crackme01_x64_s 2>/dev/null
r2 -q -c 'aaa; afl' crackme01_a64_s 2>/dev/null
r2 -q -e asm.bytes=false -e asm.cmt.right=false \
   -c 'aaa; afl; pd 1 @ 0x140001130' crackme01.exe 2>/dev/null
r2 -q -c 'aaa; afl' test8_mips_pic_s 2>/dev/null
r2 -q -e asm.bytes=false -c 'aaa; pdf @ 0x00201560' test7_x86_64_s 2>/dev/null
r2 -q -e asm.bytes=false -c 'aaa; afl; pd 14 @ 0x20344' test7_armv7_s 2>/dev/null
