Chapter 11 - Static analysis (Ghidra, IDA Free, radare2): sample sources

Layout
  src/              C/assembly sources (from chapters 1, 7, 8, 9, 10) + build.sh
  src/peb_types.h   partial _PEB/_PEB_LDR_DATA/_LDR_DATA_TABLE_ENTRY (x64) for Ghidra
  ghidra_scripts/   Ch11*.java scripts used with analyzeHeadless
  run_ghidra.sh     reproduces every Ghidra listing of the chapter
  run_r2.sh         reproduces the radare2 listings

Build
  cd src && ./build.sh            # binaries go to ../bin (*_s = stripped copies)
  Tools: clang/lld 18, llvm-strip, llvm-dlltool, lld-link.
  crackme01_a64 needs an AArch64 musl sysroot (musl 1.2.5). Build it once:
    git clone --branch v1.2.5 https://git.musl-libc.org/git/musl  (or a GitHub mirror)
    ./configure --target=aarch64-linux-musl --prefix=/opt/musl-aarch64 \
        CC="clang --target=aarch64-linux-musl" AR=llvm-ar RANLIB=llvm-ranlib \
        LDFLAGS=-fuse-ld=lld LIBCC=<libclang_rt.builtins-aarch64.a>
    make && make install
  (or set A64_SYSROOT to an existing AArch64 musl sysroot).

Run (QEMU 7.2 user mode)
  ./bin/crackme01_x64 AzeRev2026
  qemu-aarch64 -L /opt/musl-aarch64 ./bin/crackme01_a64 AzeRev2026
  qemu-aarch64 ./bin/test7_aarch64; qemu-arm ./bin/test7_armv7; ./bin/test7_x86_64   (exit 0)
  qemu-mips ./bin/test8_mips_pic                                                     (exit 0)

Ghidra
  Ghidra 12.2 needs JDK 25. Put ghidra_12.2_PUBLIC/support in PATH, then:
    cd bin && ../run_ghidra.sh          # project in ~/gh_proj (GHIDRA_PROJ to change)
  Script output is printed between the Ghidra log lines.

radare2
  radare2 6.2.4; book outputs use ~/.radare2rc with:
    e scr.color=0
    e scr.utf8=false
    cd bin && ../run_r2.sh
