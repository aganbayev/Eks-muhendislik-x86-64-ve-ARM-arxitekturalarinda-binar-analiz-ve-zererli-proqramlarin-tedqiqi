#!/bin/sh
# Chapter 11 (static analysis) samples: build with Clang/LLD 18 on Linux.
# Every sample is built twice: with symbols and stripped (the *_s files).
# Requires: clang/lld 18, llvm-strip, llvm-dlltool; for AArch64 crackme01 a musl
# sysroot (see README.txt). Outputs go to ../bin.
set -e
O=../bin; mkdir -p $O
A64=${A64_SYSROOT:-/opt/musl-aarch64}
NOLIBC="-O2 -static -nostdlib -fno-pic -fuse-ld=lld"

# 11.2-11.4: crackme01 (dynamically linked, -O0, as in chapter 1)
clang -O0 -o $O/crackme01_x64 crackme01.c
clang --target=aarch64-linux-musl --sysroot=$A64 -O0 -fuse-ld=lld -nostdlib \
      -Wl,--dynamic-linker=/lib/ld-musl-aarch64.so.1 -o $O/crackme01_a64 \
      $A64/lib/Scrt1.o $A64/lib/crti.o crackme01.c -L$A64/lib -lc $A64/lib/crtn.o

# 11.3 (7.3 jump tables): chapter 7 test program, no libc
for t in x86_64 aarch64; do
  clang --target=$t-linux-gnu $NOLIBC -o $O/test7_$t test7.c grade.c sw.c loops.c divc.c list.c
done
clang --target=armv7-linux-gnueabihf $NOLIBC -o $O/test7_armv7 test7.c grade.c sw.c loops.c divc.c list.c

# 11.2 (structures): chapter 7 st.c, object files are enough
clang --target=x86_64-linux-gnu -O2 -c st.c -o $O/st_x64.o

# 11.3 (8.6 $gp): chapter 8 test program, position-independent (abicalls) build
# -mno-relax-pic-calls keeps the "lw $t9, N($gp); jalr $t9" calls, as in real firmware
clang --target=mips-linux-gnu -O2 -static -nostdlib -fuse-ld=lld -mno-relax-pic-calls \
      -Wl,-e,_pic_entry -o $O/test8_mips_pic start_pic_mips.s test8.c calc.c grade.c sum.c sw.c cmp.c

# 11.3 (9.6, 10.5): PE samples from chapters 9 and 10
llvm-dlltool -m i386:x86-64 -d msvcrt.def   -l $O/msvcrt.lib
llvm-dlltool -m i386:x86-64 -d kernel32.def -l $O/kernel32.lib
L="lld-link /nodefaultlib /entry:start /subsystem:console /Brepro"
clang --target=x86_64-pc-windows-msvc -O0 -c crackme01_win.c -o $O/crackme01_win.obj
$L $O/crackme01_win.obj $O/msvcrt.lib /out:$O/crackme01.exe
clang --target=x86_64-pc-windows-msvc -O2 -c peb_demo.c -o $O/peb_x64.obj
$L $O/peb_x64.obj $O/kernel32.lib /out:$O/peb_demo.exe

# Stripped copies
cd $O
for f in crackme01_x64 crackme01_a64 test7_x86_64 test7_aarch64 test7_armv7 test8_mips_pic; do
  llvm-strip -o ${f}_s $f
done
