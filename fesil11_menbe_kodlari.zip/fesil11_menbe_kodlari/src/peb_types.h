/* peb_types.h - x64 düzülüşündə _PEB, _PEB_LDR_DATA və _LDR_DATA_TABLE_ENTRY
   strukturlarının analiz üçün lazım olan başlanğıc hissəsi (10.4-10.5-ci bölmələr).
   Ofsetlər Windows 10/11 x64 strukturlarına uyğundur. */
typedef struct _LIST_ENTRY {
    struct _LIST_ENTRY *Flink;
    struct _LIST_ENTRY *Blink;
} LIST_ENTRY;

typedef struct _UNICODE_STRING {
    unsigned short Length;
    unsigned short MaximumLength;
    unsigned short *Buffer;
} UNICODE_STRING;

typedef struct _PEB_LDR_DATA {
    unsigned int  Length;                      /* 0x00 */
    unsigned char Initialized;                 /* 0x04 */
    void         *SsHandle;                    /* 0x08 */
    LIST_ENTRY    InLoadOrderModuleList;       /* 0x10 */
    LIST_ENTRY    InMemoryOrderModuleList;     /* 0x20 */
    LIST_ENTRY    InInitializationOrderModuleList; /* 0x30 */
} PEB_LDR_DATA;

typedef struct _PEB {
    unsigned char InheritedAddressSpace;       /* 0x00 */
    unsigned char ReadImageFileExecOptions;    /* 0x01 */
    unsigned char BeingDebugged;               /* 0x02 */
    unsigned char BitField;                    /* 0x03 */
    unsigned char Padding0[4];                 /* 0x04 */
    void         *Mutant;                      /* 0x08 */
    void         *ImageBaseAddress;            /* 0x10 */
    PEB_LDR_DATA *Ldr;                         /* 0x18 */
    void         *ProcessParameters;           /* 0x20 */
} PEB;

typedef struct _LDR_DATA_TABLE_ENTRY {
    LIST_ENTRY     InLoadOrderLinks;           /* 0x00 */
    LIST_ENTRY     InMemoryOrderLinks;         /* 0x10 */
    LIST_ENTRY     InInitializationOrderLinks; /* 0x20 */
    void          *DllBase;                    /* 0x30 */
    void          *EntryPoint;                 /* 0x38 */
    unsigned int   SizeOfImage;                /* 0x40 */
    UNICODE_STRING FullDllName;                /* 0x48 */
    UNICODE_STRING BaseDllName;                /* 0x58 */
} LDR_DATA_TABLE_ENTRY;
