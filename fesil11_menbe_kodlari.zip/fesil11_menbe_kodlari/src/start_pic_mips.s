# start_pic_mips.s - giriş nöqtəsi: abicalls kodu üçün $t9-a __start-ın ünvanını
# yazıb ona keçir (o32-də funksiya $gp-ni girişdəki $t9-dan hesablayır).
        .text
        .set    noreorder
        .global _pic_entry
_pic_entry:
        lui     $t9, %hi(__start)
        addiu   $t9, $t9, %lo(__start)
        jr      $t9
        nop
