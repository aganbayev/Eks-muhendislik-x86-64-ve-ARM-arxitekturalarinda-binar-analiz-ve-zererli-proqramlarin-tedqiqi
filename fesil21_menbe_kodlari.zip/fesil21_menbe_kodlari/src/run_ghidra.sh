#!/bin/sh
# Chapter 21: Ghidra decompiler output of name_hash() and check() for one
# crackme21 build.  Ghidra 12.2 headless, JDK 25.  Usage: run_ghidra.sh FILE
set -e
P=${GHIDRA_PROJ:-$HOME/gh21}; S=$(cd "$(dirname "$0")/ghidra_scripts" && pwd)
mkdir -p "$P"
analyzeHeadless "$P" ch21 -import "$1" -overwrite -scriptPath "$S" \
    -postScript Ch11Decompile.java name_hash check 2>&1 |
    grep -v -E "^(INFO|WARN|ERROR) |^    /" | sed -n '/@@BEGIN/,/@@END/p' | grep -v "^@@"
