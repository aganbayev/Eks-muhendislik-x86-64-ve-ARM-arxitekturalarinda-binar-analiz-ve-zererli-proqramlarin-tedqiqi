#!/usr/bin/env python3
"""keygen21.py - serial generator for crackme21, written from the
disassembly of name_hash() and check().  Usage: keygen21.py NAME..."""
import sys

MASK = 0xA5A5F00D

def name_hash(name: bytes) -> int:
    h = 0x2F7DE1
    for c in name:
        h = ((h ^ c) * 0x01000193) & 0xFFFFFFFF
        h = ((h << 5) | (h >> 27)) & 0xFFFFFFFF
    return h

for n in sys.argv[1:]:
    if len(n.encode()) < 4:
        print(f"{n:<12} name too short (check() wants >= 4 bytes)")
        continue
    print(f"{n:<12} {name_hash(n.encode()) ^ MASK:08X}")
