# chapter 21 listings (run in /root/lab21)
== build
$ sh build.sh cm
$ file cm/crackme21_* | cut -c1-96
== run
$ printf 'AzeLab\n12345678\n' | ./cm/crackme21_x86_64; echo "rc=$?"
$ strings -n 6 cm/crackme21_x86_64 | grep -i -e name -e serial -e correct
== dis_x86
$ objdump -d -M intel --no-show-raw-insn cm/crackme21_x86_64 | awk '/<name_hash>:/,/^$/'
$ objdump -d -M intel --no-show-raw-insn cm/crackme21_x86_64 | awk '/<check>:/,/^$/' | sed -n '17,28p'
== dis_a64
$ llvm-objdump -d --no-show-raw-insn --disassemble-symbols=name_hash cm/crackme21_aarch64 | tail -n +6
$ llvm-objdump -d --no-show-raw-insn --disassemble-symbols=check cm/crackme21_aarch64 | sed -n '20,27p'
== dis_mips
$ llvm-objdump -d --no-show-raw-insn --disassemble-symbols=name_hash cm/crackme21_mips 2>/dev/null | tail -n +6 | sed 's/ <_gp_disp[^>]*>//'
$ llvm-objdump -d --no-show-raw-insn --disassemble-symbols=check cm/crackme21_mips 2>/dev/null | sed -n '34,41p' | sed 's/ <_gp_disp[^>]*>//'
== gdb
$ gdb -q cm/crackme21_x86_64
(gdb) set disassembly-flavor intel
(gdb) break *check+78
(gdb) run < cm/in.txt
(gdb) x/2i $pc
(gdb) info registers eax edx
(gdb) printf "serial = %08X\n", $edx ^ 0xa5a5f00d
(gdb) continue
== keygen
$ python3 keygen21.py Asif AzeLab abc
$ printf 'AzeLab\nD9B7113F\n' | ./cm/crackme21_x86_64; echo " rc=$?"
$ printf 'AzeLab\nD9B7113F\n' | qemu-aarch64 cm/crackme21_aarch64; echo " rc=$?"
$ printf 'AzeLab\nD9B7113F\n' | qemu-mips cm/crackme21_mips; echo " rc=$?"
== patch
$ objdump -d -M intel cm/crackme21_x86_64 | grep -A2 'call.*<check>'
$ python3 patch21.py cm/crackme21_x86_64 cm/crackme21_patched 13bf 7519 eb19
$ printf 'Hacker\n00000000\n' | ./cm/crackme21_patched; echo " rc=$?"
$ cmp -l cm/crackme21_x86_64 cm/crackme21_patched
== fo_files
$ file ch/* ch/*/* | grep -v directory | cut -c1-92
== cap_static
$ python3 captcha_solve.py ch/flarecaptcha.html
== cap_dyn
$ node captcha_dynamic.js ch/flarecaptcha.html shots
== poly
$ file ch/flareon13.doc
$ python3 polyglot_scan.py ch/flareon13.doc
$ 7zz l ch/flareon13.doc | sed -n '/^Path/,/^Comment/p'
== toxic
$ strings -n 8 ch/ToxicMiner.exe | grep '@flare'
$ echo bTFuM195MHVyXzB3bl9idXMxbjNzcw== | base64 -d; echo
== crux
$ unzip -l ch/extension.zip | sed -n '4,13p'
== ghidra
$ sh run_ghidra.sh cm/crackme21_mips
