#!/usr/bin/env python3
"""captcha_solve.py - static solution of the key derivation in Flare-On 13
challenge 1 (flarecaptcha.html).  Nothing is executed: the script pulls the
constants out of the page and recomputes what the timer callback does.
Usage: captcha_solve.py flarecaptcha.html"""
import re, sys

page = open(sys.argv[1], encoding="utf-8").read()

# 1. the "logo bitmap" is really the encrypted flag
bitmap = [int(x) for x in re.search(
    r"recaptchaLogoBitmap = \[([0-9, ]+)\]", page).group(1).split(",")]

# 2. the Proxy XORs each element with document.characterSet.length
charset = "UTF-8"                       # <meta charset="UTF-8">
env_shift = len(charset)

# 3. Function.prototype.toString() of resetWidget is part of the key, so the
#    exact source text (indentation included) matters
m = re.search(r"const resetWidget = (\(\) => \{.*?\n        \});", page, re.S)
widget_len = len(m.group(1))            # "() => {" ... "}"

print(f"bitmap length      : {len(bitmap)}")
print(f"characterSet.length: {env_shift}")
print(f"resetWidget source : {widget_len} chars")
for secs in (1, 2, 3, 4):
    bounds = (secs * (widget_len + 1115)) & 0xFFFF
    left, right = bounds >> 8 & 0xFF, bounds & 0xFF
    out = "".join(chr(b ^ env_shift ^ (left if i % 2 == 0 else right))
                  for i, b in enumerate(bitmap))
    printable = all(32 <= ord(c) < 127 for c in out)
    print(f"hold {secs}s -> key {left:02x}{right:02x}  "
          f"{out if printable else '(not printable)'}")

# 4. the same computation with a source text one character shorter, as
#    happens when the page is reformatted or a newline is lost
bounds = (2 * (widget_len - 1 + 1115)) & 0xFFFF
left, right = bounds >> 8 & 0xFF, bounds & 0xFF
print("one char less, 2s ->", "".join(
    chr(b ^ env_shift ^ (left if i % 2 == 0 else right))
    for i, b in enumerate(bitmap)))
