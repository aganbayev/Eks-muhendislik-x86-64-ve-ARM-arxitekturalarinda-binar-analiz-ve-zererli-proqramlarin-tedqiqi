/* crackme21.c - a small training keygenme for chapter 21.
 * The program asks for a name and an 8-digit hex serial.  The serial is
 * valid when (serial ^ MASK) equals a hash of the name.  Nothing here is
 * secret in a real sense: the point is to practise finding the check,
 * reading it on three architectures, solving it statically (keygen),
 * dynamically (debugger) and by patching. */
#include <stdio.h>
#include <string.h>
#include <stdint.h>

#define MASK 0xA5A5F00Du

__attribute__((noinline)) uint32_t name_hash(const char *name)
{
    uint32_t h = 0x2F7DE1u;
    for (; *name; name++) {
        h = (h ^ (uint8_t)*name) * 0x01000193u;
        h = (h << 5) | (h >> 27);
    }
    return h;
}

__attribute__((noinline)) int parse_hex(const char *s, uint32_t *out)
{
    uint32_t v = 0;
    int n = 0;
    for (; *s && *s != '\n'; s++, n++) {
        char c = *s;
        if (c >= '0' && c <= '9')      v = (v << 4) | (uint32_t)(c - '0');
        else if (c >= 'A' && c <= 'F') v = (v << 4) | (uint32_t)(c - 'A' + 10);
        else if (c >= 'a' && c <= 'f') v = (v << 4) | (uint32_t)(c - 'a' + 10);
        else return 0;
    }
    *out = v;
    return n == 8;
}

__attribute__((noinline)) int check(const char *name, const char *serial)
{
    uint32_t v;
    if (strlen(name) < 4) return 0;
    if (!parse_hex(serial, &v)) return 0;
    return (v ^ MASK) == name_hash(name);
}

int main(void)
{
    char name[64], serial[64];
    fputs("Name: ", stdout);
    fflush(stdout);
    if (!fgets(name, sizeof name, stdin)) return 2;
    name[strcspn(name, "\n")] = 0;
    fputs("Serial: ", stdout);
    fflush(stdout);
    if (!fgets(serial, sizeof serial, stdin)) return 2;
    if (check(name, serial)) {
        puts("Correct! Welcome to AzeLab.");
        return 0;
    }
    puts("Wrong serial.");
    return 1;
}
