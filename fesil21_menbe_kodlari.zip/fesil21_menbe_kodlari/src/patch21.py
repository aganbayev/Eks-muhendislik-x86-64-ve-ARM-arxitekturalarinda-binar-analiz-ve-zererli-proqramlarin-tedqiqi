#!/usr/bin/env python3
"""patch21.py - patch bytes of an ELF file at a virtual address.
The old bytes must match, otherwise nothing is written (protects against
patching the wrong build).  Usage: patch21.py IN OUT VADDR OLDHEX NEWHEX"""
import os, sys
from elftools.elf.elffile import ELFFile

src, dst, vaddr, old, new = sys.argv[1:6]
vaddr, old, new = int(vaddr, 16), bytes.fromhex(old), bytes.fromhex(new)
data = bytearray(open(src, "rb").read())
with open(src, "rb") as f:
    for seg in ELFFile(f).iter_segments():
        if seg["p_type"] == "PT_LOAD" and \
           seg["p_vaddr"] <= vaddr < seg["p_vaddr"] + seg["p_filesz"]:
            off = vaddr - seg["p_vaddr"] + seg["p_offset"]
            break
    else:
        sys.exit("address not in a PT_LOAD segment")
if data[off:off + len(old)] != old:
    sys.exit(f"bytes at {off:#x} are {data[off:off+len(old)].hex(' ')}, not {old.hex(' ')}")
data[off:off + len(new)] = new
open(dst, "wb").write(data)
os.chmod(dst, os.stat(src).st_mode)       # keep the executable bit
print(f"vaddr {vaddr:#x} -> file offset {off:#x}: {old.hex(' ')} -> {new.hex(' ')}")
