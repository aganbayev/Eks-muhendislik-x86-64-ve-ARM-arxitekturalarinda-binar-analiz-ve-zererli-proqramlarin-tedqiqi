// captcha_dynamic.js - dynamic confirmation for flarecaptcha.html with
// Playwright/Chromium: left click (fails), then right button held 2.5 s.
// Usage: node captcha_dynamic.js flarecaptcha.html SHOTDIR
const { chromium } = require('playwright');
const path = require('path');
(async () => {
  const [file, shots] = process.argv.slice(2);
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 760, height: 420 },
                                       deviceScaleFactor: 2 });
  await page.route(/^https?:/, r => r.abort());          // no network
  await page.goto('file://' + path.resolve(file));
  console.log('title       :', await page.title());
  console.log('charset     :', await page.evaluate(() => document.characterSet));
  await page.screenshot({ path: shots + '/cap_0_initial.png' });
  const box = await page.locator('#rc-interactive-area').boundingBox();
  const x = box.x + box.width / 2, y = box.y + box.height / 2;

  await page.mouse.click(x, y);                           // left button
  await page.waitForTimeout(1100);
  console.log('left click  :', await page.locator('#error-banner').innerText());
  await page.screenshot({ path: shots + '/cap_1_left.png' });
  await page.waitForTimeout(1200);                        // widget resets

  await page.mouse.move(x, y);
  await page.mouse.down({ button: 'right' });
  const t0 = Date.now();
  await page.waitForSelector('.flag-code', { timeout: 5000 });
  console.log('right hold  :', ((Date.now() - t0) / 1000).toFixed(1), 's');
  console.log('flag        :', await page.locator('.flag-code').innerText());
  await page.screenshot({ path: shots + '/cap_2_right.png' });
  await page.mouse.up({ button: 'right' });
  await browser.close();
})();
