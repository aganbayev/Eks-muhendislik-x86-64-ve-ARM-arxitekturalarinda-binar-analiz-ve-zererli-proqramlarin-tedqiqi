#!/usr/bin/env python3
"""polyglot_scan.py - list every known format signature in a file, at any
offset, not only at offset 0 as file(1) does.  A file in which several
formats are found at "legal" places is a polyglot candidate.
Usage: polyglot_scan.py FILE"""
import sys

SIGS = [  # (signature, format, where the format expects it)
    (b"X5O!P%@AP", "EICAR test string", "start of a .COM file"),
    (b"EICAR-STANDARD", "EICAR text", "inside the EICAR string"),
    (b"%PDF-", "PDF header", "first 1024 bytes"),
    (b"%%EOF", "PDF trailer", "near the end"),
    (b"BEA01", "UDF/ECMA-167 VRS begin", "volume byte 32768+"),
    (b"NSR02", "UDF NSR02 descriptor", "volume byte 32768+"),
    (b"NSR03", "UDF NSR03 descriptor", "volume byte 32768+"),
    (b"TEA01", "UDF/ECMA-167 VRS end", "volume byte 32768+"),
    (b"CD001", "ISO 9660 descriptor", "32769"),
    (b"PK\x03\x04", "ZIP local file header", "anywhere"),
    (b"PK\x01\x02", "ZIP central directory", "before the EOCD"),
    (b"PK\x05\x06", "ZIP end of central dir", "last 64 KiB"),
    (b"conectix", "VHD footer cookie", "last 512 bytes"),
    (b"MZ", "DOS/PE MZ header", "offset 0"),
    (b"\xd0\xcf\x11\xe0", "OLE2 (real .doc)", "offset 0"),
]

data = open(sys.argv[1], "rb").read()
size = len(data)
print(f"file size {size} bytes, first bytes: {data[:8].hex(' ')}")
print(f"{'offset':>10} {'from end':>9}  {'signature':<24} expected at")
for sig, name, where in SIGS:
    start, hits = 0, []
    while (i := data.find(sig, start)) != -1 and len(hits) < 4:
        hits.append(i)
        start = i + 1
    for i in hits:
        if sig == b"MZ" and i:      # two random bytes, report only offset 0
            continue
        print(f"{i:>10} {i - size:>9}  {name:<24} {where}")
