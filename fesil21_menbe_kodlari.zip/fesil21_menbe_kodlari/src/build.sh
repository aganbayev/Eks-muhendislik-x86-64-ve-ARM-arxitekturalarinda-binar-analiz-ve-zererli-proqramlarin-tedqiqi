#!/bin/sh
# build.sh - builds crackme21 for x86-64 (glibc, dynamic), AArch64 and
# MIPS32 big-endian (musl, static).  Run: sh build.sh OUTDIR
set -e
OUT=${1:-.}
SRC=$(dirname "$0")/crackme21.c
CF="-O1 -fno-stack-protector -fno-inline-functions"

gcc $CF -o "$OUT/crackme21_x86_64" "$SRC"

for t in aarch64:/opt/musl-aarch64 mips:/opt/musl-mips; do
  arch=${t%%:*}; root=${t#*:}
  clang --target=$arch-linux-musl $CF -nostdinc -isystem "$root/include" \
        -isystem "$(clang -print-resource-dir)/include" -static -nostdlib \
        -fuse-ld=lld -o "$OUT/crackme21_$arch" \
        "$root/lib/crt1.o" "$root/lib/crti.o" "$SRC" "$root/lib/libc.a" "$root/lib/crtn.o"
done
ls -l "$OUT"/crackme21_*
