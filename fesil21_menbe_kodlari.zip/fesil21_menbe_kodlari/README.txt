Chapter 21 - Crackme and CTF tasks

src/
  crackme21.c      training keygenme: name + 8-digit hex serial, valid when
                   (serial ^ 0xA5A5F00D) == name_hash(name)
  build.sh         builds crackme21 for x86-64 (gcc, glibc), AArch64 and MIPS32 BE
                   (clang + musl 1.2.5 static); usage: sh build.sh OUTDIR
  keygen21.py      serial generator written from the disassembly
  patch21.py       patches bytes at a virtual address (old bytes must match)
  run_ghidra.sh + ghidra_scripts/Ch11Decompile.java
                   Ghidra 12.2 headless decompilation of name_hash() and check()
  captcha_solve.py static key derivation for Flare-On 13 challenge 1 (flarecaptcha.html)
  captcha_dynamic.js
                   dynamic confirmation with Playwright/Chromium, network blocked
  polyglot_scan.py lists format signatures at any offset (Flare-On 13 challenge 3)
  ch21.spec + session.py   the exact commands of the listings (run in the lab folder,
                   challenge files extracted into ch/, crackme builds in cm/)
results_book/      the outputs quoted in the chapter
screenshots/       headless Chromium screenshots used for figure 21.2

The Flare-On 13 challenge files are NOT included. Get them from the official
FLARE-On archive (7z password: flare). Requirements: gcc, clang/lld, musl sysroots for
aarch64 and mips, qemu-user, gdb, Python 3 + pyelftools, Node.js + Playwright, 7-Zip,
Ghidra 12.2 + JDK 25. Open the challenges only in an isolated VM without network access.
