@echo off
rem procmon_capture.cmd NAME   (NAME = win_beacon or win_direct)
rem Records a Process Monitor trace of C:\lab13\bin\NAME.exe and exports it to CSV.
rem Set PROCMON to the full path of Procmon64.exe if it is not in PATH.
setlocal
set PM=%PROCMON%
if "%PM%"=="" set PM=Procmon64.exe
"%PM%" /AcceptEula /Quiet /Minimized /BackingFile C:\lab13\out\%1.pml
"%PM%" /WaitForIdle
C:\lab13\bin\%1.exe > C:\lab13\out\%1_stdout.txt
timeout /t 3 /nobreak > nul
"%PM%" /Terminate
"%PM%" /AcceptEula /Quiet /OpenLog C:\lab13\out\%1.pml /SaveAs C:\lab13\out\%1_all.csv
powershell -NoProfile -ExecutionPolicy Bypass -File C:\lab13\filter_csv.ps1 %1
endlocal
