# collect.ps1 - writes tool and OS versions and packs C:\lab13\out into C:\lab13\results.zip
$o = "C:\lab13\out"
cmd /c ver | Out-File -Encoding utf8 "$o\versions.txt"
Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion' |
    Select-Object ProductName, DisplayVersion, CurrentBuild, UBR |
    Out-String | Out-File -Append -Encoding utf8 "$o\versions.txt"
foreach ($p in @($env:PROCMON, $env:X64DBG)) {
    if ($p -and (Test-Path $p)) {
        (Get-Item $p).VersionInfo | Select-Object FileName, FileVersion, ProductVersion |
            Out-String | Out-File -Append -Encoding utf8 "$o\versions.txt"
    }
}
Remove-Item "$o\*_all.csv" -ErrorAction SilentlyContinue   # full captures are large
Compress-Archive -Path (Get-ChildItem $o -Exclude *.pml).FullName -DestinationPath C:\lab13\results.zip -Force
Write-Host "C:\lab13\results.zip ready"
