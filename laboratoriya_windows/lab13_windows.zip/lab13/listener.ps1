# listener.ps1 - local "C2 server" for win_beacon.exe: accepts one connection on
# 127.0.0.1:2323 and prints what it receives. Start it before procmon_capture.cmd.
$l = [System.Net.Sockets.TcpListener]::new([System.Net.IPAddress]::Loopback, 2323)
$l.Start()
Write-Host "listening on 127.0.0.1:2323 ..."
$c = $l.AcceptTcpClient()
$buf = New-Object byte[] 256
$n = $c.GetStream().Read($buf, 0, $buf.Length)
$msg = [System.Text.Encoding]::ASCII.GetString($buf, 0, $n)
Write-Host "received: $msg"
$msg | Out-File -Encoding utf8 C:\lab13\out\listener.txt
$c.Close(); $l.Stop()
