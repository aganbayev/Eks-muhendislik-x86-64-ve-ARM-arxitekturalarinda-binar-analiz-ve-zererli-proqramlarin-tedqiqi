# filter_csv.ps1 NAME - keeps only the events of the sample and its child processes
param([string]$name)
$names = @("$name.exe", "whoami.exe", "conhost.exe")
$rows = Import-Csv "C:\lab13\out\$($name)_all.csv"
$rows | Where-Object { $names -contains $_.'Process Name' } |
    Export-Csv -NoTypeInformation -Encoding UTF8 "C:\lab13\out\$name.csv"
Write-Host "$name.csv:" ($rows | Where-Object { $names -contains $_.'Process Name' }).Count "events"
