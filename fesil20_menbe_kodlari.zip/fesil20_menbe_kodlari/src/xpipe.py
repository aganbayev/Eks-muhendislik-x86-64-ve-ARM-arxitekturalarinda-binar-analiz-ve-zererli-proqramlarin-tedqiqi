#!/usr/bin/env python3
"""xpipe.py - static triage pipeline for a folder of password-protected samples
(chapter 20). Every sample is read from its zip INTO MEMORY; nothing is unpacked to
disk and nothing is executed. For each sample one JSON line is written:
  sha256, size, format, arch (from the ELF/PE header, not from the file name),
  linking / symbols / packing flags, entropy, number of printable strings,
  a single-byte XOR string-table guess, the number of system-call instructions
  (Capstone), and the YARA rules that match.
Usage: xpipe.py ZIPDIR RULES.yar[,RULES2.yar...] OUT.jsonl [-j N] [--password P]"""
import argparse, hashlib, io, json, math, os, re, struct, sys, time, zipfile
from collections import Counter
from multiprocessing import Pool

import capstone as cs
import pefile
import yara

EM = {3: "x86", 8: "mips", 20: "ppc", 40: "arm", 62: "x86_64", 183: "aarch64", 243: "riscv"}
# indicators for the XOR guess: each contains "/", which a case flip (XOR 0x20) cannot produce
XOR_IOC = [b"/proc/", b"/bin/busybox", b"/dev/watchdog", b"/etc/", b"/tmp/"]
STR_RE = re.compile(rb"[\x20-\x7e]{4,}")
RULES = None


def entropy(data):
    n = len(data)
    return round(-sum(c / n * math.log2(c / n) for c in Counter(data).values()), 3) if n else 0.0


def parse_elf(d):
    """minimal ELF reader: survives missing or damaged section tables"""
    is64, le = d[4] == 2, d[5] == 1
    e = "<" if le else ">"
    if is64:
        e_type, e_machine = struct.unpack_from(e + "HH", d, 16)
        e_phoff, e_shoff = struct.unpack_from(e + "QQ", d, 32)
        e_phentsize, e_phnum, e_shentsize, e_shnum, e_shstrndx = struct.unpack_from(e + "HHHHH", d, 54)
    else:
        e_type, e_machine = struct.unpack_from(e + "HH", d, 16)
        e_phoff, e_shoff = struct.unpack_from(e + "II", d, 28)
        e_phentsize, e_phnum, e_shentsize, e_shnum, e_shstrndx = struct.unpack_from(e + "HHHHH", d, 42)
    code, interp = [], False
    for i in range(e_phnum):
        o = e_phoff + i * e_phentsize
        if o + e_phentsize > len(d):
            break
        if is64:
            p_type, p_flags, p_off, p_vaddr, _, p_filesz = struct.unpack_from(e + "IIQQQQ", d, o)
        else:
            p_type, p_off, p_vaddr, _, p_filesz, _, p_flags = struct.unpack_from(e + "IIIIIII", d, o)
        interp |= p_type == 3                                   # PT_INTERP: dynamic
        if p_type == 1 and p_flags & 1:                         # PT_LOAD, executable
            code.append((p_off, p_vaddr, p_filesz))
    names = []
    if e_shoff and e_shnum and e_shoff + e_shnum * e_shentsize <= len(d):
        sh = [struct.unpack_from(e + ("IIQQQQ" if is64 else "IIIIII"), d, e_shoff + i * e_shentsize)
              for i in range(e_shnum)]
        if e_shstrndx < len(sh):
            strtab = sh[e_shstrndx][4]
            for s in sh:
                end = d.find(b"\0", strtab + s[0])
                names.append(d[strtab + s[0]:end].decode("latin-1"))
    if e_type == 1:                                             # relocatable object (.o)
        code = []
    return {"format": "ELF", "arch": EM.get(e_machine, f"em{e_machine}") + ("" if le else "_be"),
            "bits": 64 if is64 else 32, "type": {1: "rel", 2: "exec", 3: "dyn"}.get(e_type, e_type),
            "static": None if e_type == 1 else not interp, "sections": len(names),
            "stripped": ".symtab" not in names}, code, (e_machine, is64, le)


def parse_pe(d):
    pe = pefile.PE(data=d, fast_load=False)
    arch = {0x14c: "x86", 0x8664: "x86_64", 0xaa64: "aarch64"}.get(pe.FILE_HEADER.Machine, "?")
    code = [(s.PointerToRawData, s.VirtualAddress, s.SizeOfRawData) for s in pe.sections
            if s.Characteristics & 0x20000000]                  # IMAGE_SCN_MEM_EXECUTE
    dlls = [e.dll.decode().lower() for e in getattr(pe, "DIRECTORY_ENTRY_IMPORT", [])]
    return {"format": "PE", "arch": arch, "bits": 64 if arch.endswith("64") else 32,
            "sections": len(pe.sections), "imphash": pe.get_imphash(), "dlls": dlls}, code, arch


def syscall_count(fmt, key, d, code):
    """number of system-call instructions in the executable segments (linear sweep)"""
    if fmt == "ELF":
        e_machine, is64, le = key
        endian = cs.CS_MODE_LITTLE_ENDIAN if le else cs.CS_MODE_BIG_ENDIAN
        md = {3: (cs.CS_ARCH_X86, cs.CS_MODE_32), 62: (cs.CS_ARCH_X86, cs.CS_MODE_64),
              40: (cs.CS_ARCH_ARM, cs.CS_MODE_ARM), 183: (cs.CS_ARCH_ARM64, cs.CS_MODE_ARM),
              8: (cs.CS_ARCH_MIPS, cs.CS_MODE_MIPS32 + endian)}.get(e_machine)
    else:
        md = {"x86": (cs.CS_ARCH_X86, cs.CS_MODE_32), "x86_64": (cs.CS_ARCH_X86, cs.CS_MODE_64)}.get(key)
    if md is None:
        return None
    m = cs.Cs(*md)
    m.skipdata = True
    n, total = 0, 0
    for off, va, size in code:
        for ins in m.disasm_lite(d[off:off + size], va):
            total += 1
            mn = ins[2]
            if mn in ("syscall", "svc", "sysenter") or (mn == "int" and ins[3] == "0x80"):
                n += 1
            if total >= 200000:
                return n
    return n


def xor_guess(d):
    """single-byte key whose decoding shows the most "/"-containing indicators"""
    plain = sum(d.count(w) for w in XOR_IOC)
    best = (0, None)
    for k in range(1, 256):
        t = bytes(b ^ k for b in range(256))
        hits = sum(d.count(w.translate(t)) for w in XOR_IOC)   # search the encoded words
        if hits > best[0]:
            best = (hits, k)
    return {"xor_key": f"{best[1]:#04x}" if best[0] >= 2 else None, "xor_hits": best[0], "plain_hits": plain}


def init(rule_files):
    global RULES
    RULES = yara.compile(filepaths={os.path.basename(p): p for p in rule_files},
                         externals={"source_mode": False})


def analyse(args):
    """one sample; an error is recorded in its own line and does not stop the run"""
    try:
        return analyse_one(*args)
    except Exception as e:
        t = type(e)
        name = t.__qualname__ if t.__module__ == "builtins" else f"{t.__module__}.{t.__qualname__}"
        return {"zip": os.path.basename(args[0]), "error": f"{name}: {e}"}


def analyse_one(path, password):
    t0 = time.time()
    with zipfile.ZipFile(path) as z:
        member = z.namelist()[0]
        d = z.read(member, pwd=password.encode())               # in memory only
    r = {"sha256": hashlib.sha256(d).hexdigest(), "member": member, "size": len(d),
         "entropy": entropy(d), "strings": len(STR_RE.findall(d))}
    code, key = [], None
    if d[:4] == b"\x7fELF":
        info, code, key = parse_elf(d)
    elif d[:2] == b"MZ":
        info, code, key = parse_pe(d)
    else:
        info = {"format": "data", "arch": None}
    r.update(info)
    r["upx"] = b"UPX!" in d or (info["format"] == "ELF" and info["sections"] == 0 and r["entropy"] > 6.5)
    r["syscalls"] = syscall_count(info["format"], key, d, code) if code else None
    r.update(xor_guess(d))
    r["yara"] = sorted(m.rule for m in RULES.match(data=d))
    r["ms"] = int((time.time() - t0) * 1000)
    return r


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("zipdir"); ap.add_argument("rules"); ap.add_argument("out")
    ap.add_argument("-j", type=int, default=os.cpu_count())
    ap.add_argument("--password", default="infected")
    a = ap.parse_args()
    rule_files = a.rules.split(",")
    zips = sorted(os.path.join(a.zipdir, f) for f in os.listdir(a.zipdir) if f.endswith(".zip"))
    t0 = time.time()
    with Pool(a.j, initializer=init, initargs=(rule_files,)) as pool, open(a.out, "w") as out:
        for r in pool.imap(analyse, [(z, a.password) for z in zips]):
            out.write(json.dumps(r) + "\n")
    print(f"{len(zips)} samples, {a.j} workers, {time.time() - t0:.1f} s -> {a.out}")


if __name__ == "__main__":
    main()
