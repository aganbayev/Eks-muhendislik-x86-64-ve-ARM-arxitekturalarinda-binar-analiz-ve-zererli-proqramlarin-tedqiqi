// Ch20XorLoops.java - architecture-independent search for decoding loops (chapter 20).
// Works on P-code, Ghidra's intermediate language, so the same rule serves x86, ARM and MIPS:
// for every function it counts INT_XOR operations whose two inputs differ (this drops the
// "xor eax, eax" zeroing idiom), checks for a loop (a jump back inside the function) and for
// a one-byte STORE (the decoded byte is written back). Prints small functions (at most MAXSIZE
// bytes) with at least MIN such XORs, a loop and a byte store. Args: [MIN [MAXSIZE]]
//@category Ch20
import ghidra.app.script.GhidraScript;
import ghidra.program.model.listing.*;
import ghidra.program.model.pcode.PcodeOp;
import ghidra.program.model.symbol.Reference;

public class Ch20XorLoops extends GhidraScript {
    @Override
    public void run() throws Exception {
        String[] a = getScriptArgs();
        int min = a.length > 0 ? Integer.parseInt(a[0]) : 3;
        long maxsize = a.length > 1 ? Long.parseLong(a[1]) : 512;
        int nf = 0;
        StringBuilder out = new StringBuilder();
        for (Function f : currentProgram.getFunctionManager().getFunctions(true)) {
            if (f.isThunk() || f.isExternal()) continue;
            nf++;
            int xors = 0;
            boolean loop = false, bytestore = false;
            for (Instruction ins : currentProgram.getListing().getInstructions(f.getBody(), true)) {
                for (PcodeOp op : ins.getPcode())
                {
                    if (op.getOpcode() == PcodeOp.INT_XOR && !op.getInput(0).equals(op.getInput(1)))
                        xors++;
                    if (op.getOpcode() == PcodeOp.STORE && op.getInput(2).getSize() == 1)
                        bytestore = true;
                }
                for (Reference r : ins.getReferencesFrom())
                    if (r.getReferenceType().isJump() && r.getToAddress().compareTo(ins.getAddress()) < 0
                            && f.getBody().contains(r.getToAddress()))
                        loop = true;
            }
            long size = f.getBody().getNumAddresses();
            if (xors >= min && loop && bytestore && size <= maxsize)
                out.append(String.format("  %s %-22s %4d bytes  xor=%d\n", f.getEntryPoint(), f.getName(),
                        size, xors));
        }
        System.out.println("@@ " + currentProgram.getName() + " (" + currentProgram.getLanguageID()
                + "), " + nf + " functions");
        System.out.print(out);
    }
}
