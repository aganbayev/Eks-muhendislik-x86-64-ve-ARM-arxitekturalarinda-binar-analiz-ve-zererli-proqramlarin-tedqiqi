#!/bin/sh
# Chapter 20: stores the book's samples the way real samples are stored: one
# password-protected zip per file ("infected", the usual convention), named by SHA-256.
# Usage: pack_corpus.sh OUTDIR FILE...
set -e
out=$1; shift
mkdir -p "$out"
for f in "$@"; do
  h=$(sha256sum "$f" | cut -c1-64)
  ( cd "$(dirname "$f")" && zip -q -j -P infected "$out/$h.zip" "$(basename "$f")" )
done
ls "$out" | wc -l
