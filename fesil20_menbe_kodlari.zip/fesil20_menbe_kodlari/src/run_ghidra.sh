#!/bin/sh
# Chapter 20: batch import of a folder into one Ghidra project and the P-code XOR-loop search.
# Ghidra 12.2 headless, JDK 25. Usage: run_ghidra.sh FOLDER [MIN [MAXSIZE]]
set -e
P=${GHIDRA_PROJ:-$HOME/gh20}; S=$(cd "$(dirname "$0")/ghidra_scripts" && pwd)
mkdir -p "$P"
analyzeHeadless "$P" ch20 -import "$1" -overwrite -scriptPath "$S" \
    -postScript Ch20XorLoops.java ${2:-4} ${3:-512} 2>&1 | grep -E "^@@|^  [0-9a-f]{8} "
