# chapter 20 listings (run in /root/lab20)
== pack
$ sh pack_corpus.sh /root/lab20/zips /root/lab16/corpus/* /root/lab18/table_demo_x86_64_s /root/lab18/table_armv7.o /root/lab18/table_mips.o /root/lab17/agent17.exe /root/lab16/goodware/iot/arm_linux_picohttpd /root/lab16/goodware/iot/mips32el_linux_mips32el_tcp_test /root/lab16/goodware/linux/gzip /root/lab16/goodware/pe/cli-64.exe
$ zipinfo zips/0547ca68647af69c87fa5f6187e2cb617854b7c00e9ea16ccab3b7eca794757e.zip | tail -2
== run
$ python3 xpipe.py zips azelab.yar,mirai_table.yar,gafgyt_tsunami.yar,agent17.yar triage.jsonl -j 4
$ python3 report.py triage.jsonl
== one
$ head -1 triage.jsonl | python3 -m json.tool | head -22
== ghidra
$ time sh run_ghidra.sh ghidra_in 4 512
== err
$ python3 xpipe.py zips_test azelab.yar err.jsonl -j 2
$ python3 report.py err.jsonl
