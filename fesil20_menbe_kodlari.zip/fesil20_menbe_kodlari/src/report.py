#!/usr/bin/env python3
"""report.py - summary of an xpipe.py run (chapter 20): one line per sample and
counts per detection rule. Flags: S static (o: object file), s stripped, U UPX-like.
Usage: report.py TRIAGE.jsonl"""
import json, sys
from collections import Counter

rows = [json.loads(l) for l in open(sys.argv[1])]
errors = [r for r in rows if "error" in r]
rows = [r for r in rows if "error" not in r]
rows.sort(key=lambda r: (r["format"], r["arch"] or "", r["member"]))
print(f"{'sample':<22}{'fmt':<4}{'arch':<9}{'flg':<4}{'H':>5}{'sys':>5} {'xor':<5} rules")
for r in rows:
    flg = ("o" if r.get("type") == "rel" else "S" if r.get("static") else "-")
    flg += ("s" if r.get("stripped") else "-") + ("U" if r["upx"] else "-")
    if r["format"] == "PE":
        flg = "--" + ("U" if r["upx"] else "-")
    sysc = "-" if r["syscalls"] is None else str(r["syscalls"])
    rules = ",".join(x.replace("AzeLab_", "") for x in r["yara"]) or "-"
    print(f"{r['member'][:21]:<22}{r['format']:<4}{(r['arch'] or '-'):<9}{flg:<4}"
          f"{r['entropy']:>5.2f}{sysc:>5} {(r['xor_key'] or '-'):<5} {rules}")
c = Counter(x for r in rows for x in r["yara"])
for r in errors:
    print(f"{r['zip'][:21]:<22}{r['error']}")
print(f"\n{len(rows)} samples, {len(errors)} errors, {sum(1 for r in rows if r['yara'])} with at least one rule:")
for rule, n in c.most_common():
    print(f"  {n:>3}  {rule}")
