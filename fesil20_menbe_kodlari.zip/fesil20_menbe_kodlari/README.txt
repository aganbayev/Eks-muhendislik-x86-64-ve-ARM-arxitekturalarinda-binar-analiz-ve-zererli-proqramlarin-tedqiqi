Chapter 20 - Automating the analysis

src/
  pack_corpus.sh   stores samples as password-protected zips named by SHA-256
                   (usage: pack_corpus.sh /ABSOLUTE/OUTDIR FILE...)
  xpipe.py         static triage pipeline: reads each sample from its zip into memory
                   (never unpacked, never executed), ELF/PE header, flags, entropy, strings,
                   single-byte XOR guess, Capstone system-call count, YARA in memory;
                   one JSON line per sample; errors are recorded per sample
  report.py        summary table and rule counts from the JSON lines
  run_ghidra.sh + ghidra_scripts/Ch20XorLoops.java
                   batch import into Ghidra 12.2 (headless) and an architecture-independent
                   P-code search for byte-decoding loops
  ch20.spec + session.py   the exact commands of the listings
results_book/      the outputs quoted in the chapter
Requirements: Python 3, pefile, capstone, yara-python (YARA 4.5), zip/zipinfo; Ghidra 12.2 + JDK 25.
Rules used in the chapter: azelab.yar (ch. 16), agent17.yar (ch. 17), mirai_table.yar (ch. 18),
gafgyt_tsunami.yar (ch. 19). Run only in an isolated analysis VM without network access.
