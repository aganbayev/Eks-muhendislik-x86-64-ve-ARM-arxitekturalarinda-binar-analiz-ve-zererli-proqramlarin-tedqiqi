Chapter 1 - Introduction to reverse engineering

crackme01.c   the password crackme used in chapters 1, 5, 6, 11 and 12
              build:  gcc -O0 -o crackme01 crackme01.c
                      cp crackme01 crackme01_stripped && strip crackme01_stripped
              run:    ./crackme01 <password>
