#!/usr/bin/env python3
"""syscall_table.py - Linux system call numbers for five ABIs, read from the
musl libc source tree (arch/*/bits/syscall.h.in).  Usage:
syscall_table.py MUSL_SRC_DIR NAME..."""
import re, sys, os

ARCHES = [("x86_64", "x86-64"), ("i386", "x86 (32)"), ("arm", "ARM EABI"),
          ("aarch64", "AArch64"), ("mips", "MIPS o32")]
root, names = sys.argv[1], sys.argv[2:]
tab = {}
for a, _ in ARCHES:
    txt = open(os.path.join(root, "arch", a, "bits", "syscall.h.in")).read()
    tab[a] = {m.group(1): m.group(2) for m in
              re.finditer(r"#define __NR_(\w+)\s+(\d+)", txt)}
print(f"{'name':<12}" + "".join(f"{lbl:>10}" for _, lbl in ARCHES))
for n in names:
    print(f"{n:<12}" + "".join(f"{tab[a].get(n, '-'):>10}" for a, _ in ARCHES))
