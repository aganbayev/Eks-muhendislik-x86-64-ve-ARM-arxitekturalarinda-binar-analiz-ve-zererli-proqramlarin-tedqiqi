Appendix A - Linux system call numbers

syscall_table.py   system call numbers for x86-64, x86, ARM EABI, AArch64 and MIPS o32,
                   read from the musl libc source tree (arch/*/bits/syscall.h.in):
                   python3 syscall_table.py /path/to/musl read write openat ...
app.spec           the exact command of the listing; results_book/sys.txt holds its output
