# appendix A (run in the lab folder)
== sys
$ python3 syscall_table.py /home/asif/dl/musl read write open openat close execve exit exit_group fork clone kill getpid socket connect bind listen accept sendto recvfrom mmap mmap2 mprotect ptrace nanosleep unlink unlinkat chdir ioctl prctl setsid dup2 dup3 socketcall
