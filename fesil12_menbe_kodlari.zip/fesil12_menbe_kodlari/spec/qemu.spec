== q_strace
$ qemu-mips -strace ./iot_beacon_mips
== q_host
$ strace -f -e trace=%process,%network qemu-mips ./iot_beacon_mips
== q_hostc
$ strace -f -c -o host.txt qemu-mips ./iot_beacon_mips; head -12 host.txt
== q_arm
$ qemu-arm -strace ./iot_beacon_armv7
$ qemu-aarch64 -strace ./iot_beacon_aarch64
