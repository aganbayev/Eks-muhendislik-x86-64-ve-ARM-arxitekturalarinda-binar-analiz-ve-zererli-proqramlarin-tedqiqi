# chapter 12 listings, x86-64 part (run in /root/lab12)
== st_plain
$ strace ./iot_beacon_x86_64
== st_f
$ strace -f -e trace=%process,%file,%network ./iot_beacon_x86_64
== st_log
$ nc -l 127.0.0.1 2323 > /dev/null &
$ strace -f -tt -s 32 -o beacon.log ./iot_beacon_x86_64
$ grep -E 'socket|connect|write' beacon.log
== st_count
$ strace -f -c ./iot_beacon_x86_64
== lt_lazy
$ ltrace ./crackme01_lazy test > /dev/null
== lt_gcc
$ ltrace ./crackme01 test
$ readelf -d crackme01 | grep FLAGS
$ readelf -SW crackme01 | grep plt
== lt_static
$ ltrace ./crackme01_static test
== lt_enc
$ strings crackme01_enc | grep -c Aze
$ ltrace ./crackme01_enc test
== lt_S
$ ltrace -S -e strcmp+puts ./crackme01_lazy test
