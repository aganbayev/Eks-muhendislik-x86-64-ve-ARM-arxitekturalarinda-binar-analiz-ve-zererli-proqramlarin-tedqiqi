== m_a64
$ qemu-aarch64 -L /opt/musl-aarch64 -g 1234 ./crackme01_a64 test &
$ gdb-multiarch -q ./crackme01_a64
(gdb) set sysroot /opt/musl-aarch64
(gdb) target remote :1234
(gdb) break check_password
(gdb) continue
(gdb) info registers x0 x30 sp pc
(gdb) x/s $x0
(gdb) x/8i $pc
(gdb) finish
(gdb) p $x0
== m_sum0
$ qemu-aarch64 -g 1234 ./sum_a64 &
$ gdb-multiarch -q ./sum_a64
(gdb) target remote :1234
(gdb) break sum_array
(gdb) continue
(gdb) info registers pc x30 sp x0 x1
(gdb) finish
(gdb) p $x0
== m_mips
$ qemu-mips -g 1234 ./test8_mips_pic &
$ gdb-multiarch -q ./test8_mips_pic
(gdb) target remote :1234
(gdb) x/4i $pc
(gdb) break *0x2020c
(gdb) continue
(gdb) info registers gp s0 t9
(gdb) x/4i $pc
(gdb) stepi
(gdb) stepi
(gdb) p/x $t9
(gdb) p $a1
(gdb) stepi
(gdb) p $a1
(gdb) p/x $ra
== m_sum2
$ qemu-aarch64 -g 1234 ./sum_a64 &
$ gdb-multiarch -q ./sum_a64
(gdb) target remote :1234
(gdb) break *sum_array
(gdb) continue
(gdb) info registers pc x30 sp x0 x1
(gdb) x/5gd $x0
(gdb) finish
(gdb) p $x0
== m_qhost
$ strace -f -qq -e trace=%network qemu-mips ./iot_beacon_mips
$ strace -f -c qemu-mips ./iot_beacon_mips 2>&1 | head -8
