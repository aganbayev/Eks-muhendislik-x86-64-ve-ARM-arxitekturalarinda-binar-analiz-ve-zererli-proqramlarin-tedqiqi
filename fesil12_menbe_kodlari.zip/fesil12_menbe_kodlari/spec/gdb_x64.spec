== g_basic
$ gdb -q ./crackme01
(gdb) set disassembly-flavor intel
(gdb) break check_password
(gdb) run test
(gdb) x/s $rdi
(gdb) disassemble
(gdb) finish
(gdb) info registers eax
(gdb) continue
== g_step
$ gdb -q ./crackme01
(gdb) set disassembly-flavor intel
(gdb) break check_password
(gdb) run test
(gdb) display/i $pc
(gdb) nexti 6
(gdb) x/s $rsi
(gdb) nexti
(gdb) p $eax
== g_cond
$ gdb -q ./crackme01
(gdb) break check_password if *(char *)$rdi == 'A'
(gdb) run test
(gdb) run AzeRev2026
(gdb) x/s $rdi
== g_watch
$ readelf -r crackme01_lazy | grep strcmp
$ gdb -q ./crackme01_lazy
(gdb) break main
(gdb) run test
(gdb) x/gx 0x555555558010
(gdb) watch *(void **)0x555555558010
(gdb) continue
(gdb) bt 3
(gdb) info symbol *(void **)0x555555558010
== g_strip
$ gdb -q ./crackme01_x64_s
(gdb) set disassembly-flavor intel
(gdb) info file
(gdb) starti test
(gdb) info proc mappings
(gdb) x/12i 0x555555555070
(gdb) tbreak *0x5555555551f0
(gdb) continue
(gdb) x/s $rdi
(gdb) bt
