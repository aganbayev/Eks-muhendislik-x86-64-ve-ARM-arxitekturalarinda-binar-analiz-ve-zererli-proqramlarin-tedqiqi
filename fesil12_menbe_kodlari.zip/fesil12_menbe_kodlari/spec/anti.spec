== ad_run
$ ./antidbg
$ strace -e trace=ptrace,write ./antidbg
== ad_lt
$ ltrace -e ptrace ./antidbg
== ad_gdb
$ gdb -q ./antidbg
(gdb) catch syscall ptrace
(gdb) run
(gdb) info registers rdi
(gdb) continue
(gdb) info registers rax
(gdb) continue
