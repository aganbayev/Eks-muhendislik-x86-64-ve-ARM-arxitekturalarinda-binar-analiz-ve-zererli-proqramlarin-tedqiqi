#!/bin/sh
# Chapter 12 (dynamic analysis on Linux): build every sample of the chapter.
# Tools: gcc 13 (Ubuntu 24.04 defaults: PIE, BIND_NOW, -fcf-protection), clang/lld 18,
# llvm-strip; crackme01_a64 needs an AArch64 musl 1.2.5 sysroot (see README.txt).
# Outputs go to ../bin (*_s = stripped copies).
set -e
O=../bin; mkdir -p $O
A64=${A64_SYSROOT:-/opt/musl-aarch64}
NOLIBC="-O2 -static -nostdlib -fno-pic -fuse-ld=lld"

# 12.3 ltrace and 12.4 GDB: crackme01 as in chapter 1 (gcc defaults) and its variants
gcc -O0 -o $O/crackme01 crackme01.c
gcc -O0 -Wl,-z,lazy -o $O/crackme01_lazy crackme01.c
gcc -O0 -static -o $O/crackme01_static crackme01.c
gcc -O0 -Wl,-z,lazy -o $O/crackme01_enc crackme01_enc.c

# 12.4 stripped x86-64 file and 12.6 AArch64 file from chapter 11 (clang)
clang -O0 -o $O/crackme01_x64 crackme01.c
clang --target=aarch64-linux-musl --sysroot=$A64 -O0 -fuse-ld=lld -nostdlib \
      -Wl,--dynamic-linker=/lib/ld-musl-aarch64.so.1 -o $O/crackme01_a64 \
      $A64/lib/Scrt1.o $A64/lib/crti.o crackme01.c -L$A64/lib -lc $A64/lib/crtn.o

# 12.6: chapter 6 sum_a64, chapter 7 test7 (ARMv7), chapter 8/11 test8_mips_pic
clang --target=aarch64-linux-gnu -O1 -static -nostdlib -fno-pic -fuse-ld=lld \
      sum_main.c sum_a64.s -o $O/sum_a64
clang --target=armv7-linux-gnueabihf $NOLIBC -o $O/test7_armv7 \
      test7.c grade.c sw.c loops.c divc.c list.c
clang --target=mips-linux-gnu -O2 -static -nostdlib -fuse-ld=lld -mno-relax-pic-calls \
      -Wl,-e,_pic_entry -o $O/test8_mips_pic start_pic_mips.s test8.c calc.c grade.c sum.c sw.c cmp.c

# 12.2, 12.7: IoT-like beacon, no libc, four architectures
# (-mstackrealign: _start is entered with a 16-byte aligned rsp, not "call"-aligned)
clang --target=x86_64-linux-gnu $NOLIBC -mstackrealign -o $O/iot_beacon_x86_64 iot_beacon.c
clang --target=aarch64-linux-gnu $NOLIBC -o $O/iot_beacon_aarch64 iot_beacon.c
clang --target=armv7-linux-gnueabihf $NOLIBC -o $O/iot_beacon_armv7 iot_beacon.c
clang --target=mips-linux-gnu $NOLIBC -mno-abicalls -Wl,-e,_start -o $O/iot_beacon_mips iot_beacon.c

# 12.8: ptrace(PTRACE_TRACEME) anti-debugging check
gcc -O0 -o $O/antidbg antidbg.c

# Stripped copies
cd $O
for f in crackme01_x64 crackme01_a64 test8_mips_pic iot_beacon_mips; do
  llvm-strip -o ${f}_s $f
done
