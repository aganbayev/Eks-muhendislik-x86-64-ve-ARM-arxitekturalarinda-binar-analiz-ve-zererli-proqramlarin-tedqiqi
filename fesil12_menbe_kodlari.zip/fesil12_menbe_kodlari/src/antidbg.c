/* antidbg.c - the simplest Linux anti-debugging check (chapter 12, 12.8).
 * A process can be traced by only one tracer. PTRACE_TRACEME fails with EPERM
 * when a debugger (gdb, strace, ltrace) is already attached. */
#include <stdio.h>
#include <sys/ptrace.h>

int main(void)
{
    if (ptrace(PTRACE_TRACEME, 0, 0, 0) == -1) {
        puts("Salam!");                 /* decoy behaviour under a debugger */
        return 0;
    }
    puts("Esas yuk isledi.");           /* "real" behaviour */
    return 0;
}
