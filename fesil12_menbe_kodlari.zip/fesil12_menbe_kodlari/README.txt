Chapter 12 - Dynamic analysis on Linux (GDB, gdb-multiarch, strace, ltrace): samples

Layout
  src/            sources + build.sh (binaries go to ../bin)
    crackme01.c        chapter 1 crackme (gcc default build, -z lazy, -static, clang)
    crackme01_enc.c    chapter 1 exercise: password stored +1, decoded before strcmp
    iot_beacon.c       harmless IoT-bot-like program, no libc, x86-64/AArch64/ARMv7/MIPS:
                       child connects to 127.0.0.1:2323, parent writes /tmp/.bcn_id
    sys12.h            raw Linux system calls for the four architectures
    antidbg.c          ptrace(PTRACE_TRACEME) anti-debugging check (12.7)
    sum_main.c, sum_a64.s            chapter 6 (6.8 debugger session)
    test7.c ... list.c               chapter 7 test program (ARMv7)
    test8.c, start_pic_mips.s ...    chapter 8/11 MIPS abicalls program
  spec/*.spec     the exact commands of every listing in the chapter
  tools/session.py  runs the commands on a pseudo-terminal and records what the
                    terminal shows (gdb sessions are real interactive transcripts)
  run_all.sh      builds everything and re-records all listings into out/

Tools used in the book
  Ubuntu 24.04: gcc 13.3, clang/lld 18, GDB 15.1 (Ubuntu package), strace 6.8,
  OpenBSD netcat, libc6-dbg installed.
  gdb-multiarch: GDB 15.1 built from source with --enable-targets=all
    (git tag gdb-15.1-release; GMP and MPFR needed; flex needed for a git checkout).
  ltrace 0.7.91 built from git (github.com/dkogan/ltrace). Distribution packages
    (0.7.3 with patches, 0.8.1) may behave differently on BIND_NOW + .plt.sec files.
  QEMU 7.2.0 user mode (qemu-user-static v7.2.0-1).
  AArch64 musl 1.2.5 sysroot in /opt/musl-aarch64 (same as chapter 11):
    ./configure --target=aarch64-linux-musl --prefix=/opt/musl-aarch64 \
        CC="clang --target=aarch64-linux-musl" AR=llvm-ar RANLIB=llvm-ranlib \
        LDFLAGS=-fuse-ld=lld LIBCC=<libclang_rt.builtins-aarch64.a>
    make && make install
    ln -s libc.so /opt/musl-aarch64/lib/ld-musl-aarch64.so.1   # for qemu -L

Run
  cd src && ./build.sh && cd ../bin
  strace -f ./iot_beacon_x86_64            (start "nc -l 127.0.0.1 2323" first to see the data)
  ltrace ./crackme01_lazy test
  qemu-aarch64 -L /opt/musl-aarch64 -g 1234 ./crackme01_a64 test &  gdb-multiarch ./crackme01_a64
  qemu-mips -g 1234 ./test8_mips_pic &  gdb-multiarch ./test8_mips_pic
  qemu-mips -strace ./iot_beacon_mips

Safety: everything connects only to 127.0.0.1; still run the samples in the
isolated lab VM from chapter 4, as the chapter requires.
