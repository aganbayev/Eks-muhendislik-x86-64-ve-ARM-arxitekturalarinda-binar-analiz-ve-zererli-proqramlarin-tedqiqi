#!/bin/sh
# Re-records every listing of chapter 12 as a real terminal transcript.
# Usage: ./run_all.sh [LABDIR]   (default /root/lab12; binaries are copied there)
# Needs: gdb, gdb-multiarch, strace, ltrace, nc, qemu-aarch64, qemu-arm, qemu-mips,
#        AArch64 musl sysroot in /opt/musl-aarch64 (see README.txt).
set -e
HERE=$(cd "$(dirname "$0")" && pwd)
LAB=${1:-/root/lab12}
(cd "$HERE/src" && sh build.sh)
mkdir -p "$LAB" "$HERE/out"
cp "$HERE"/bin/* "$LAB"/
for s in ch12 gdb_x64 multi qemu anti; do
  python3 "$HERE/tools/session.py" "$HERE/spec/$s.spec" "$HERE/out" "$LAB"
done
echo "Transcripts are in $HERE/out"
