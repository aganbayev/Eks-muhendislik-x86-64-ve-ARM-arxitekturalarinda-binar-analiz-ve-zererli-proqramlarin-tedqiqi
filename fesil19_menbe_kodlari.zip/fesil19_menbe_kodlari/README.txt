Chapter 19 - Case study: Gafgyt (BASHLITE) and Tsunami (Kaiten), source analysis

No bot source and no binaries are included. fetch.sh downloads the two public archives
at fixed commits (ifding/iot-malware 4d6fa7d: BASHLITE, lizkebab; shipcod3/IRC-Bot-Hunters
0ddd2f2: kaiten.c). Nothing is compiled or run.

src/
  fetch.sh            sparse download of the source archives
  cmd_extract.py      command interface from the C source (strcmp chain / command table)
  gafgyt_tsunami.yar  YARA rules; external variable source_mode:
                        yara -d source_mode=true  ... C source files
                        yara -d source_mode=false ... ELF files
  rules_on_strings.py the logic of the three rules applied to strings already extracted
                      from a corpus (19.6); string_prevalence.py: share of samples per string
                      (the research corpus itself is not included)
  ch19.spec + session.py   the exact commands of the listings
results_book/         the outputs quoted in the chapter
