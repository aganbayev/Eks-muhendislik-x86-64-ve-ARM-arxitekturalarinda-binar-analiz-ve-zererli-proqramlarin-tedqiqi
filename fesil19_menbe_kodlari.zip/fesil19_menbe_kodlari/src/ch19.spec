# chapter 19 listings (run in /root/lab19)
== src
$ git --no-pager -C iot-malware log -1 --format="%h %cs" && git --no-pager -C IRC-Bot-Hunters log -1 --format="%h %cs"
$ wc -l iot-malware/BASHLITE/client.c iot-malware/BASHLITE/server.c IRC-Bot-Hunters/malicious_samples/kaiten.c
== gafgyt_conf
$ cd iot-malware/BASHLITE && grep -n -A3 "commServer\[\] =" client.c
$ cd iot-malware/BASHLITE && grep -n "int port = 6667\|BUILD %s\|\"PONG\|8.8.8.8\|htons(23)\|\"DUP\"" client.c
$ cd iot-malware/BASHLITE && grep -n "REPORT %s" client.c | cut -c1-90
== gafgyt_cmds
$ python3 cmd_extract.py gafgyt iot-malware/BASHLITE/client.c
== kaiten_conf
$ cd IRC-Bot-Hunters/malicious_samples && sed -n '43,51p' kaiten.c
$ cd IRC-Bot-Hunters/malicious_samples && grep -n "htons(6667)\|htons(113)\|NICK %s\\\\nUSER\|JOIN %s\|PONG %s\|/usr/dict/words\|rc.local" kaiten.c
== kaiten_cmds
$ python3 cmd_extract.py kaiten IRC-Bot-Hunters/malicious_samples/kaiten.c
== yara
$ yara -d source_mode=true -s gafgyt_tsunami.yar iot-malware/BASHLITE/client.c
$ yara -d source_mode=true gafgyt_tsunami.yar IRC-Bot-Hunters/malicious_samples/kaiten.c
$ yara -d source_mode=true gafgyt_tsunami.yar iot-malware/BASHLITE/server.c; echo "server.c: $?"
$ yara -d source_mode=false gafgyt_tsunami.yar iot-malware/BASHLITE/client.c; echo "as a file: $?"
$ yara -d source_mode=false -r gafgyt_tsunami.yar /root/lab16/goodware | wc -l
$ yara -d source_mode=false -r gafgyt_tsunami.yar /root/lab18 | wc -l
== real_rules
$ python3 rules_on_strings.py xarch/strings.pkl xarch/features.csv
== real_prev
$ python3 string_prevalence.py xarch/strings.pkl "BUILD %s" "PONG!" "REPORT %s:%s" "GETLOCALIP" "LOLNOGTFO" "KILLATTK" "USER %s localhost localhost :%s" "JOIN %s :%s" "NOTICE %s :" "GETSPOOFS" "Kaiten wa goraku" "STDHEX" "OVHKILL" "/bin/busybox"
== yara_v2
$ yara -d source_mode=false -r gafgyt_tsunami.yar /root/lab16/goodware | wc -l
$ yara -d source_mode=true gafgyt_tsunami.yar iot-malware/lizkebab/src/client.c
