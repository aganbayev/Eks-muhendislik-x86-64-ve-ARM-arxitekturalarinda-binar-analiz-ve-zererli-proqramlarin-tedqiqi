#!/usr/bin/env python3
"""cmd_extract.py - lists the command interface of a bot from its C source
(chapter 19, 19.2-19.3). Recognises the two dispatch styles of the chapter:
  gafgyt: if(!strcmp(argv[0], "CMD")) ... / strcmp(command, "CMD") == 0
  kaiten: struct table { char *cmd; void (*func)(...); } x[] = { { "CMD", func }, ... }
          (IRC numeric replies such as "376" are listed too)
For every command prints its source line, so that the handler can be read next.
Usage: cmd_extract.py gafgyt|kaiten FILE"""
import re, sys

style, path = sys.argv[1], sys.argv[2]
lines = open(path, errors="replace").read().split("\n")
if style == "gafgyt":
    rx = re.compile(r'strcmp\((?:argv\[0\]|command),\s*"([A-Z]+)"\)')
    for n, l in enumerate(lines, 1):
        for m in rx.finditer(l):
            print(f"{n:>5}  {m.group(1)}")
else:
    table = None
    for n, l in enumerate(lines, 1):
        t = re.search(r"\}\s*(\w+)\[\]\s*=\s*\{", l)
        if t:
            table = t.group(1)
            print(f"table {table} (line {n})")
        for m in re.finditer(r'\{\s*"([A-Z0-9]+)",\s*(\w+)\s*\}', l):
            print(f"{n:>5}  {m.group(1):<10} -> {m.group(2)}()")
