#!/usr/bin/env python3
"""rules_on_strings.py - applies the logic of the two YARA rules of 19.5 to the printable
strings already extracted from a corpus (chapter 19, 19.6). Every rule string is printable
ASCII, so "the string occurs in the file" is the same as "it is a substring of one of the
file's printable runs of 4+ characters"; the result equals a YARA scan of the ELF files.
Input: a pickle with one record per sample: {"sha256", "family", "arch", "plain": [str, ...]};
optionally a features CSV with columns sha256 and s_upx (UPX-packed flag).
Usage: rules_on_strings.py STRINGS.pkl [FEATURES.csv]"""
import csv
import pickle, sys
from collections import Counter

GAFGYT_P = ["BUILD %s", "PONG!", "REPORT %s:%s"]
GAFGYT_C = ["GETLOCALIP", "LOLNOGTFO", "KILLATTK", "SCANNER"]
TSU_IRC = ["USER %s localhost localhost :%s", "JOIN %s :%s", "PONG %s"]
TSU_N = "NOTICE %s :"
TSU_H = ["TSUNAMI <target> <secs>", "GETSPOOFS", "Kaiten wa goraku"]
VARIANTS = ["STDHEX", "RANDHEX", "UDPRAW", "OVHKILL", "NFODROP", "XMAS", "STOMP", "CRUSH"]

def has(blob, s):
    return s in blob

def gafgyt(blob):
    return sum(has(blob, s) for s in GAFGYT_P) >= 2 and sum(has(blob, s) for s in GAFGYT_C) >= 2

def tsunami(blob):
    return (sum(has(blob, s) for s in TSU_IRC) >= 2 and has(blob, TSU_N)
            and any(has(blob, s) for s in TSU_H))

def variants(blob):
    return sum(has(blob, s) for s in VARIANTS) >= 3

RULES = [("Gafgyt_Bashlite", gafgyt), ("Gafgyt_Variants", variants), ("Tsunami_Kaiten", tsunami)]
samples = pickle.load(open(sys.argv[1], "rb"))
upx = {}
if len(sys.argv) > 2:
    upx = {r["sha256"]: r["s_upx"] in ("1", "1.0", "True") for r in csv.DictReader(open(sys.argv[2]))}
total, hits, missed = Counter(), Counter(), Counter()
for x in samples:
    blob = "\n".join(s if isinstance(s, str) else s.decode("latin-1") for s in x["plain"])
    fam = x["family"]
    total[fam] += 1
    found = [name for name, rule in RULES if rule(blob)]
    for name in found:
        hits[fam, name] += 1
    if not found:
        missed[fam, "upx" if upx.get(x["sha256"]) else "other"] += 1
print(f"{'label':<8} {'n':>4}" + "".join(f"  {name:>15}" for name, _ in RULES) + "  none (UPX)")
for fam in sorted(total):
    n = total[fam]
    row = "".join(f"  {hits[fam, name]:>4} ({100 * hits[fam, name] / n:4.1f}%)" for name, _ in RULES)
    none = missed[fam, "upx"] + missed[fam, "other"]
    print(f"{fam:<8} {n:>4}{row}  {none:>4} ({missed[fam, 'upx']})" if upx else f"{fam:<8} {n:>4}{row}  {none:>4}")
