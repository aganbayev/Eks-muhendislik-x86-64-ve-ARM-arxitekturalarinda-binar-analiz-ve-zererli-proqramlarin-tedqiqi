#!/bin/sh
# Chapter 19: fetches the two public source archives at fixed commits (sparse, source only).
# Nothing is compiled. Run in an empty lab folder.
set -e
git clone -q --filter=blob:none --no-checkout https://github.com/ifding/iot-malware.git
git -C iot-malware checkout -q 4d6fa7d31442996e6b1e7c94e4ef996493f0a2de -- BASHLITE lizkebab
git clone -q --filter=blob:none --sparse https://github.com/shipcod3/IRC-Bot-Hunters.git
git -C IRC-Bot-Hunters checkout -q 0ddd2f2
git -C IRC-Bot-Hunters sparse-checkout set --no-cone /malicious_samples/kaiten.c
