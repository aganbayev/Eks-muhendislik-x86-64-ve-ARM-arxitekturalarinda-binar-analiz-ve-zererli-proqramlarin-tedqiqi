#!/usr/bin/env python3
"""string_prevalence.py - share of samples per family label in which each given string
occurs as a substring of an extracted printable string (chapter 19, 19.6).
Usage: string_prevalence.py STRINGS.pkl STRING..."""
import pickle, sys
from collections import Counter

samples = pickle.load(open(sys.argv[1], "rb"))
total = Counter(x["family"] for x in samples)
fams = sorted(total)
blobs = [(x["family"], "\n".join(x["plain"])) for x in samples]
print(f"{'string':<32}" + "".join(f"{f:>9}" for f in fams))
for s in sys.argv[2:]:
    c = Counter(f for f, b in blobs if s in b)
    print(f"{s:<32}" + "".join(f"{100 * c[f] / total[f]:8.1f}%" for f in fams))
