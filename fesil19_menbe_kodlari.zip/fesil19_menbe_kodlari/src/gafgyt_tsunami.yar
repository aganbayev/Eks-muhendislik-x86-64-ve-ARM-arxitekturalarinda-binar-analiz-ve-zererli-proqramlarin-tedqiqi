/* gafgyt_tsunami.yar - Gafgyt (BASHLITE) and Tsunami (Kaiten) families (chapter 19, 19.5).
   YARA 4.5. Both families keep their protocol strings in clear text. The rules require an
   ELF file; with  yara -d source_mode=true  they are also applied to C source files,
   which is how they are tested in this chapter (no bot binaries are built).
   source_mode is an external variable: always pass it (-d source_mode=false for files). */
rule Gafgyt_Bashlite
{
    meta:
        description = "Gafgyt/BASHLITE bot: text C2 protocol and command words"
        author = "Asif Qanbayev"
    strings:
        $p1 = "BUILD %s"
        $p2 = "PONG!"
        $p3 = "REPORT %s:%s"
        $c1 = "GETLOCALIP"
        $c2 = "LOLNOGTFO"
        $c3 = "KILLATTK"
        $c4 = "SCANNER"
    condition:
        (uint32(0) == 0x464c457f or source_mode) and 2 of ($p*) and 2 of ($c*)
}

rule Tsunami_Kaiten
{
    meta:
        description = "Tsunami/Kaiten IRC bot: IRC registration and NOTICE replies of the command handlers"
        author = "Asif Qanbayev"
    strings:
        // no escape sequences: "\n" is one byte in a binary but two characters in C source
        $irc1 = "USER %s localhost localhost :%s"
        $irc2 = "JOIN %s :%s"
        $irc3 = "PONG %s"
        $n1 = "NOTICE %s :"
        $h1 = "TSUNAMI <target> <secs>"
        $h2 = "GETSPOOFS"
        $h3 = "Kaiten wa goraku"
    condition:
        (uint32(0) == 0x464c457f or source_mode) and 2 of ($irc*) and $n1 and 1 of ($h*)
}

rule Gafgyt_Variants
{
    meta:
        description = "later Gafgyt builds: attack method names that replaced the old command words (19.6)"
        author = "Asif Qanbayev"
        note = "selected on a research corpus of real samples; validate on new samples before use"
    strings:
        $a1 = "STDHEX"
        $a2 = "RANDHEX"
        $a3 = "UDPRAW"
        $a4 = "OVHKILL"
        $a5 = "NFODROP"
        $a6 = "XMAS"
        $a7 = "STOMP"
        $a8 = "CRUSH"
    condition:
        (uint32(0) == 0x464c457f or source_mode) and 3 of them
}
