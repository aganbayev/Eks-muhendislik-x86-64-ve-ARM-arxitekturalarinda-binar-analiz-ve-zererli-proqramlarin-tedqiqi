#include <stdio.h>

static int square(int x)
{
    return x * x;
}

int sum_squares(int n)
{
    int s = 0;
    for (int i = 1; i <= n; i++)
        s += square(i);
    return s;
}

int main(void)
{
    printf("%d\n", sum_squares(10));
    return 0;
}
