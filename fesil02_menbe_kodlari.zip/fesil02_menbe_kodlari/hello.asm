default rel

extern  printf
global  main

section .rodata
LC0:    db "Salam, dunya!", 0
LC1:    db "%s %d", 10, 0

section .text
main:
        endbr64
        push    rbp
        mov     rbp, rsp
        mov     edx, 49
        lea     rax, [LC0]
        mov     rsi, rax
        lea     rax, [LC1]
        mov     rdi, rax
        mov     eax, 0
        call    printf wrt ..plt
        mov     eax, 0
        pop     rbp
        ret

section .note.GNU-stack noalloc noexec nowrite progbits
