Chapter 2 - From C code to machine code

hello.c     the program followed through the whole compilation chain (2.1-2.5)
            gcc -save-temps -o hello hello.c      (keeps hello.i, hello.s, hello.o)
hello.asm   hello.c rewritten in NASM (2.3):  nasm -f elf64 hello.asm -o hello_asm.o && gcc hello_asm.o -o hello_asm
calc.c      one function compiled for x86-64 and AArch64 (2.3):
            clang --target=x86_64-linux-gnu  -O0 -S -masm=intel calc.c -o calc_x64.s
            clang --target=aarch64-linux-gnu -O0 -S calc.c -o calc_a64.s
opt.c       optimization levels (2.6):  gcc -O0 -o opt_O0 opt.c ; gcc -O2 -o opt_O2 opt.c
Tested with GCC 13.3, Clang 18 and NASM 2.16 on Ubuntu 24.04.
