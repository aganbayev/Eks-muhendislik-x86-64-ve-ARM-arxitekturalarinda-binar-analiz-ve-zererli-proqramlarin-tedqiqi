int less_signed(int a, int b)             { return a < b ? 10 : 20; }
int less_unsigned(unsigned a, unsigned b) { return a < b ? 10 : 20; }
