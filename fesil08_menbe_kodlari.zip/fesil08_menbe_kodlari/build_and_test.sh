#!/bin/sh
# Chapter 8 (MIPS) examples: build and run under QEMU user-mode.
# Requires: clang/lld 18, llvm-objdump, qemu-mips, qemu-mipsel.
set -e
B="-static -nostdlib -fno-pic -mno-abicalls -fuse-ld=lld"
for t in mips mipsel; do
  # 8.3: hello_mips.s
  clang --target=$t-linux-gnu -mno-abicalls -c hello_mips.s -o hello_$t.o
  ld.lld hello_$t.o -o hello_$t
  qemu-$t ./hello_$t
  # 4.6 / Lab A: hello_nolibc.c
  clang --target=$t-linux-gnu -O2 $B -Wl,-e,_start -o hello_nolibc_$t hello_nolibc.c
  qemu-$t ./hello_nolibc_$t
  # Lab B: test8.c (expected exit code 0)
  for o in O0 O2; do
    clang --target=$t-linux-gnu -$o $B -o test8_${t}_$o test8.c calc.c grade.c sum.c sw.c cmp.c
    qemu-$t ./test8_${t}_$o && echo "test8_${t}_$o: exit 0"
  done
done
# Lab B.3: hand-written sum_array (expected exit code 0)
clang --target=mips-linux-gnu -O2 $B -o test8_asm test8.c calc.c grade.c sum_mips.s sw.c cmp.c
qemu-mips ./test8_asm && echo "test8_asm: exit 0"
# 8.6: position-independent caller32 (object file only)
clang --target=mips-linux-gnu -O1 -c caller32.c -o caller32_pic.o
llvm-objdump -d -r --no-show-raw-insn --no-print-imm-hex caller32_pic.o
