Chapter 8 - Introduction to MIPS

hello_mips.s     first MIPS program, system calls (8.3)
cmp.c            conditions without flags (8.5)
caller32.c       o32 calling convention (8.6)
calc.c, grade.c, sum.c, sum_mips.s, sw.c, test8.c   lab (test8.c: expected exit code 0)
hello_nolibc.c   program without the C library (chapter 4)
build_and_test.sh  builds everything for mips and mipsel and runs it under QEMU
Requires: clang/lld 18, llvm-objdump, qemu-mips, qemu-mipsel.
