/* hello_nolibc.c - C kitabxanası olmadan, birbaşa sistem çağırışları ilə */

static long sys_write(long fd, const void *buf, long len);
static void sys_exit(long code) __attribute__((noreturn));

#if defined(__x86_64__)
static long sys_write(long fd, const void *buf, long len)
{
    long ret;
    __asm__ volatile ("syscall" : "=a"(ret)
                      : "a"(1), "D"(fd), "S"(buf), "d"(len)
                      : "rcx", "r11", "memory");
    return ret;
}
static void sys_exit(long code)
{
    __asm__ volatile ("syscall" : : "a"(60), "D"(code));
    __builtin_unreachable();
}
#elif defined(__aarch64__)
static long sys_write(long fd, const void *buf, long len)
{
    register long x0 __asm__("x0") = fd;
    register long x1 __asm__("x1") = (long)buf;
    register long x2 __asm__("x2") = len;
    register long x8 __asm__("x8") = 64;
    __asm__ volatile ("svc #0" : "+r"(x0) : "r"(x1), "r"(x2), "r"(x8) : "memory");
    return x0;
}
static void sys_exit(long code)
{
    register long x0 __asm__("x0") = code;
    register long x8 __asm__("x8") = 93;
    __asm__ volatile ("svc #0" : : "r"(x0), "r"(x8));
    __builtin_unreachable();
}
#elif defined(__arm__)
static long sys_write(long fd, const void *buf, long len)
{
    register long r0 __asm__("r0") = fd;
    register long r1 __asm__("r1") = (long)buf;
    register long r2 __asm__("r2") = len;
    register long r7 __asm__("r7") = 4;
    __asm__ volatile ("svc #0" : "+r"(r0) : "r"(r1), "r"(r2), "r"(r7) : "memory");
    return r0;
}
static void sys_exit(long code)
{
    register long r0 __asm__("r0") = code;
    register long r7 __asm__("r7") = 1;
    __asm__ volatile ("svc #0" : : "r"(r0), "r"(r7));
    __builtin_unreachable();
}
#elif defined(__mips__)
static long sys_write(long fd, const void *buf, long len)
{
    register long a0 __asm__("$4") = fd;
    register long a1 __asm__("$5") = (long)buf;
    register long a2 __asm__("$6") = len;
    register long v0 __asm__("$2") = 4004;
    __asm__ volatile ("syscall" : "+r"(v0) : "r"(a0), "r"(a1), "r"(a2)
                      : "$1", "$3", "$7", "$8", "$9", "$10", "$11", "$12", "$13",
                        "$14", "$15", "$24", "$25", "hi", "lo", "memory");
    return v0;
}
static void sys_exit(long code)
{
    register long a0 __asm__("$4") = code;
    register long v0 __asm__("$2") = 4001;
    __asm__ volatile ("syscall" : : "r"(a0), "r"(v0));
    __builtin_unreachable();
}
#else
#error "Dəstəklənməyən arxitektura"
#endif

void _start(void)
{
    static const char msg[] = "Salam, laboratoriya!\n";
    sys_write(1, msg, sizeof(msg) - 1);
    sys_exit(0);
}
