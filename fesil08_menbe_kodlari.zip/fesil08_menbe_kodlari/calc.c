int calc(int x, int y)
{
    return x * x + y;
}
