# sum_mips.s - long sum_array(const long *a, long n)
# o32: a -> $a0, n -> $a1, nəticə -> $v0
        .text
        .set    noreorder           # gecikmə yuvalarını özümüz doldururuq
        .global sum_array
sum_array:
        blez    $a1, .Ldone         # n <= 0 olarsa
        move    $v0, $zero          # yuva: s = 0
.Lloop:
        lw      $t0, 0($a0)         # t0 = *a
        addiu   $a1, $a1, -1        # n--
        addu    $v0, $v0, $t0       # s += t0
        bnez    $a1, .Lloop
        addiu   $a0, $a0, 4         # yuva: a++
.Ldone:
        jr      $ra
        nop                         # yuva: boş
