/* test8.c - 8-ci fəslin funksiyalarını MIPS-də yoxlayır;
   C kitabxanası olmadan. Çıxış kodu 0: bütün yoxlamalar keçdi,
   N: N nömrəli yoxlama səhvdir. */
int calc(int x, int y);
char grade(int score);
long sum_array(const long *a, long n);
int cmd_handler(int cmd, int x);
int less_signed(int a, int b);
int less_unsigned(unsigned a, unsigned b);

static void sys_exit(long code) __attribute__((noreturn));
static void sys_exit(long code)
{
    register long a0 __asm__("$4") = code;
    register long v0 __asm__("$2") = 4001;
    __asm__ volatile ("syscall" : : "r"(a0), "r"(v0));
    __builtin_unreachable();
}

void __start(void)
{
    static const long data[] = {10, 20, 30, 40, 50};

    if (calc(7, 5) != 54 || calc(-3, 1) != 10)
        sys_exit(1);
    if (grade(95) != 'A' || grade(80) != 'B' ||
        grade(50) != 'C' || grade(49) != 'F')
        sys_exit(2);
    if (sum_array(data, 5) != 150 || sum_array(data, 0) != 0)
        sys_exit(3);
    if (cmd_handler(2, 7) != 21 || cmd_handler(5, 7) != -7 ||
        cmd_handler(9, 7) != 0)
        sys_exit(4);
    if (less_signed(-1, 1) != 10 || less_unsigned(-1, 1) != 20)
        sys_exit(5);
    sys_exit(0);
}
