int many_args32(int a, int b, int c, int d, int e, int f, int g, int h);

int caller32(void)
{
    return many_args32(1, 2, 3, 4, 5, 6, 7, 8) + 1;
}
