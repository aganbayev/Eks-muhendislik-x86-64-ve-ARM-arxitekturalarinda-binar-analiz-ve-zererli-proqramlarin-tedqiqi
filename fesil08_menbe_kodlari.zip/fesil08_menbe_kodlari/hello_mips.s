# hello_mips.s - Linux MIPS (o32), yalnız sistem çağırışları ilə
        .text
        .global __start
__start:
        li      $a0, 1              # fd = stdout
        la      $a1, msg            # buf: lui + addiu cütü
        li      $a2, 13             # count: mətnin uzunluğu
        li      $v0, 4004           # write
        syscall

        li      $a0, 0              # status = 0
        li      $v0, 4001           # exit
        syscall

        .section .rodata
msg:    .ascii  "Salam, MIPS!\n"
