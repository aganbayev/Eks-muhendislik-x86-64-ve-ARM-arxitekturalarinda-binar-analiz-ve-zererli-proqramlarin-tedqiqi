Chapter 3 - The ELF format

elfinfo.py   lab 3: ELF header, segment and section parser written with the standard
             struct module only (no third-party libraries).
             usage:  python3 elfinfo.py FILE
Section 3.7 compiles a small stack-buffer program (buf.c) in two variants to show the
traces of protection mechanisms; any program with a local char buffer copied with
strcpy() can be used:
  gcc -o buf buf.c
  gcc -fno-stack-protector -no-pie -z norelro -z execstack -o buf_weak buf.c
