#!/usr/bin/env python3
"""elfinfo.py - ELF faylının başlığını, seqmentlərini və seksiyalarını göstərir."""
import struct
import sys

ET_TYPES = {1: "REL", 2: "EXEC", 3: "DYN", 4: "CORE"}
MACHINES = {3: "x86", 8: "MIPS", 40: "ARM", 62: "x86-64", 183: "AArch64"}
PT_TYPES = {0: "NULL", 1: "LOAD", 2: "DYNAMIC", 3: "INTERP", 4: "NOTE",
            6: "PHDR", 7: "TLS", 0x6474E550: "GNU_EH_FRAME",
            0x6474E551: "GNU_STACK", 0x6474E552: "GNU_RELRO",
            0x6474E553: "GNU_PROPERTY"}


class ElfError(Exception):
    pass


def parse_header(data):
    if data[:4] != b"\x7fELF":
        raise ElfError("ELF imzası tapılmadı")
    ei_class, ei_data = data[4], data[5]
    if ei_class not in (1, 2) or ei_data not in (1, 2):
        raise ElfError("naməlum sinif və ya bayt sırası")
    end = "<" if ei_data == 1 else ">"
    if ei_class == 1:
        fmt = end + "HHIIIIIHHHHHH"
    else:
        fmt = end + "HHIQQQIHHHHHH"
    fields = struct.unpack_from(fmt, data, 16)
    names = ("type", "machine", "version", "entry", "phoff", "shoff",
             "flags", "ehsize", "phentsize", "phnum", "shentsize",
             "shnum", "shstrndx")
    hdr = dict(zip(names, fields))
    hdr["bits"] = 32 if ei_class == 1 else 64
    hdr["endian"] = end
    return hdr


def program_headers(data, hdr):
    end = hdr["endian"]
    result = []
    for i in range(hdr["phnum"]):
        off = hdr["phoff"] + i * hdr["phentsize"]
        if hdr["bits"] == 64:
            p_type, p_flags, p_offset, p_vaddr, _, p_filesz, p_memsz, _ = \
                struct.unpack_from(end + "IIQQQQQQ", data, off)
        else:
            p_type, p_offset, p_vaddr, _, p_filesz, p_memsz, p_flags, _ = \
                struct.unpack_from(end + "IIIIIIII", data, off)
        perm = ("R" if p_flags & 4 else "-") + ("W" if p_flags & 2 else "-") \
            + ("X" if p_flags & 1 else "-")
        result.append((PT_TYPES.get(p_type, hex(p_type)), p_offset,
                       p_vaddr, p_filesz, p_memsz, perm))
    return result


def section_names(data, hdr):
    if hdr["shoff"] == 0 or hdr["shnum"] == 0:
        return []
    end = hdr["endian"]
    fmt = end + ("IIQQQQIIQQ" if hdr["bits"] == 64 else "IIIIIIIIII")

    def sh(i):
        return struct.unpack_from(fmt, data, hdr["shoff"] + i * hdr["shentsize"])

    strtab = sh(hdr["shstrndx"])
    str_off = strtab[4]
    names = []
    for i in range(hdr["shnum"]):
        name_off = sh(i)[0]
        start = str_off + name_off
        names.append(data[start:data.index(b"\0", start)].decode(errors="replace"))
    return names


def main(path):
    with open(path, "rb") as f:
        data = f.read()
    hdr = parse_header(data)
    print(f"Fayl:        {path}")
    print(f"Sinif:       ELF{hdr['bits']}, "
          f"{'little' if hdr['endian'] == '<' else 'big'}-endian")
    print(f"Tip:         {ET_TYPES.get(hdr['type'], hdr['type'])}")
    print(f"Arxitektura: {MACHINES.get(hdr['machine'], hdr['machine'])}")
    print(f"Giriş:       {hdr['entry']:#x}")
    print(f"Bayraqlar:   {hdr['flags']:#x}")
    phdrs = program_headers(data, hdr)
    if phdrs:
        print("\nSeqmentlər:")
        for p_type, off, vaddr, filesz, memsz, perm in phdrs:
            print(f"  {p_type:<14} off={off:#08x} vaddr={vaddr:#010x} "
                  f"filesz={filesz:#07x} memsz={memsz:#07x} {perm}")
    names = section_names(data, hdr)
    print(f"\nSeksiyalar ({len(names)}): {' '.join(n for n in names if n)}")


if __name__ == "__main__":
    if len(sys.argv) != 2:
        sys.exit("İstifadə: elfinfo.py <fayl>")
    try:
        main(sys.argv[1])
    except (ElfError, struct.error, ValueError) as e:
        sys.exit(f"Xəta: {e}")
