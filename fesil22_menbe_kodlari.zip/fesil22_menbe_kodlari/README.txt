Chapter 22 - Final project: from analysis to a verified report

Verification tools (static, nothing is executed):
  pe_info.py            PE profile: sections + entropy, imports, exports, Authenticode, VersionInfo (-v)
  section_cmp.py        compares a PE file with its memory dump section by section
                        (identical code section = nothing was unpacked at run time)
  patch_diff.py         lists byte patches between an original and a patched PE, with
                        RVA/VA and Capstone disassembly of both versions
  iat_disasm.py         disassembly of a VA range with import names on indirect calls
                        (used to recognise MSVC CRT __scrt_fastfail, not anti-debug)
  authenticode_check.py recomputes the Authenticode digest and compares it with the one
                        stored in the signature; prints signer/issuer (chain NOT validated)
  sentinel_model.py     reconstructed 6-8-1 network of the "Mini LLM Sentinel" crackme
                        (from the author's write-up, weights read from the binary)
  solve_sentinel.py     hybrid solver: Z3 for the integer constraints + the network as judge
  ch22.spec + session.py   the exact commands of the listings (run in the lab folder)
results_book/           outputs quoted in the chapter

Samples are NOT included (crackmes.one tasks, a Microsoft Defender update package,
TinyTurla-NG SHA-256 d6ac21a409f35a80ba9ccfe58ae1ae32883e44ecc724e4ae8289e7465ab2cf40,
see Cisco Talos IOCs). Requirements: Python 3, pefile, capstone, openssl, Z3 4.15 Python
bindings. Handle real malware only in an isolated VM without network access.
