#!/usr/bin/env python3
"""pe_info.py - short static profile of PE files: machine, type, entry point,
sections with entropy, imports per DLL, exports, Authenticode presence.
Usage: pe_info.py [-i] [-v] FILE...   (-i: imported names, -v: VersionInfo)"""
import sys, os, math, collections
import pefile

def entropy(b):
    if not b: return 0.0
    c = collections.Counter(b)
    return max(0.0, -sum(n / len(b) * math.log2(n / len(b)) for n in c.values()))

args = [a for a in sys.argv[1:] if a not in ("-i", "-v")]
names = "-i" in sys.argv
for f in args:
    pe = pefile.PE(f)
    oh = pe.OPTIONAL_HEADER
    kind = "DLL" if pe.FILE_HEADER.Characteristics & 0x2000 else "EXE"
    print(f"== {os.path.basename(f)}  ({os.path.getsize(f)} bytes, {kind}, "
          f"ImageBase {oh.ImageBase:#x}, EntryPoint RVA {oh.AddressOfEntryPoint:#x})")
    for s in pe.sections:
        n = s.Name.rstrip(b"\0").decode(errors="replace")
        print(f"   {n:<8} VA {s.VirtualAddress:#08x} VSize {s.Misc_VirtualSize:#08x} "
              f"Raw {s.SizeOfRawData:#08x} H={entropy(s.get_data()):.2f}")
    if hasattr(pe, "DIRECTORY_ENTRY_IMPORT"):
        for d in pe.DIRECTORY_ENTRY_IMPORT:
            fn = [i.name.decode() if i.name else f"#{i.ordinal}" for i in d.imports]
            line = f"   import {d.dll.decode():<14} {len(fn):>3} functions"
            print(line + (": " + ", ".join(fn) if names else ""))
    else:
        print("   no import directory")
    if hasattr(pe, "DIRECTORY_ENTRY_EXPORT"):
        for e in pe.DIRECTORY_ENTRY_EXPORT.symbols:
            print(f"   export #{e.ordinal} {e.name.decode() if e.name else ''} RVA {e.address:#x}")
    sec = oh.DATA_DIRECTORY[4]
    print(f"   Authenticode: {'yes, %d bytes' % sec.Size if sec.Size else 'no'}")
    if "-v" in sys.argv and hasattr(pe, "FileInfo"):
        for fi in pe.FileInfo[0]:
            for st in getattr(fi, "StringTable", []):
                for k, v in st.entries.items():
                    print(f"   {k.decode():<16} {v.decode()}")
