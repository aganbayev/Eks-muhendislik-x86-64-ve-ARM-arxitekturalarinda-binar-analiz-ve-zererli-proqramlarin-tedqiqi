#!/usr/bin/env python3
"""patch_diff.py - find and explain the byte patches between an original PE
and its patched copy: changed runs are mapped to RVA/VA and both versions are
disassembled with Capstone (x86-64).  Usage: patch_diff.py ORIGINAL PATCHED"""
import sys
import pefile
from capstone import Cs, CS_ARCH_X86, CS_MODE_64

a, b = (open(p, "rb").read() for p in sys.argv[1:3])
pe = pefile.PE(sys.argv[1], fast_load=True)
base = pe.OPTIONAL_HEADER.ImageBase
md = Cs(CS_ARCH_X86, CS_MODE_64)
if len(a) != len(b):
    print(f"sizes differ: {len(a)} vs {len(b)} (sections were rebuilt, not patched)")
    sys.exit(0)
runs, i = [], 0
while i < len(a):
    if a[i] != b[i]:
        j = i
        while j < len(a) and (a[j] != b[j] or (j + 1 < len(a) and a[j + 1] != b[j + 1])):
            j += 1
        runs.append((i, j)); i = j
    i += 1
print(f"{len(runs)} patched region(s)")
for s, e in runs:
    try:
        rva = pe.get_rva_from_offset(s)
    except Exception:
        rva = None
    where = f"RVA {rva:#x}  VA {base + rva:#x}" if rva is not None else "header/overlay"
    print(f"-- file offset {s:#x}  {where}  ({e - s} bytes)")
    print(f"   before: {a[s:e].hex(' ')}")
    print(f"   after : {b[s:e].hex(' ')}")
    if rva is None:
        continue
    for tag, data in (("orig", a), ("patch", b)):
        for ins in md.disasm(data[s:s + max(e - s, 2) + 6], base + rva):
            if ins.address >= base + rva + max(e - s, 1): break
            print(f"   {tag:<5} {ins.address:#x}: {ins.mnemonic} {ins.op_str}".rstrip())
