#!/usr/bin/env python3
"""authenticode_check.py - offline check of a PE Authenticode signature:
   1. recompute the Authenticode digest of the file (the image without the
      checksum field, the security directory entry and the certificate table);
   2. compare it with the digest stored in the signature (SpcIndirectDataContent);
   3. print the signer certificate (the chain is NOT validated here; on
      Windows use signtool verify /pa or the file's Digital Signatures tab).
Usage: authenticode_check.py FILE..."""
import hashlib, subprocess, sys, tempfile, os
import pefile

OIDS = {"2b0e03021a": "sha1", "608648016503040201": "sha256"}

def authenticode_digest(data, pe, algo):
    sec = pe.OPTIONAL_HEADER.DATA_DIRECTORY[4]
    cks = pe.OPTIONAL_HEADER.get_field_absolute_offset("CheckSum")
    dir_off = sec.get_file_offset()
    h = hashlib.new(algo)
    h.update(data[:cks]); h.update(data[cks + 4:dir_off])
    h.update(data[dir_off + 8:sec.VirtualAddress])
    h.update(data[sec.VirtualAddress + sec.Size:])
    return h.hexdigest()

def stored_digest(blob):
    # SpcIndirectDataContent: ... AlgorithmIdentifier(OID) ... OCTET STRING digest
    for oid, algo in OIDS.items():
        o = bytes.fromhex("06" + "%02x" % (len(oid) // 2) + oid)
        i = blob.find(o)
        while i != -1:
            j = blob.find(b"\x04", i + len(o), i + len(o) + 8)
            n = hashlib.new(algo).digest_size
            if j != -1 and blob[j + 1] == n:
                return algo, blob[j + 2:j + 2 + n].hex()
            i = blob.find(o, i + 1)
    return None, None

for f in sys.argv[1:]:
    data = open(f, "rb").read()
    pe = pefile.PE(data=data, fast_load=True)
    sec = pe.OPTIONAL_HEADER.DATA_DIRECTORY[4]
    print(f"== {os.path.basename(f)}")
    if not sec.Size:
        print("   no Authenticode signature"); continue
    blob = data[sec.VirtualAddress + 8:sec.VirtualAddress + sec.Size]
    algo, stored = stored_digest(blob)
    calc = authenticode_digest(data, pe, algo)
    print(f"   digest ({algo}) stored  : {stored}")
    print(f"   digest ({algo}) computed: {calc}")
    print(f"   file unchanged since signing: {stored == calc}")
    with tempfile.NamedTemporaryFile(suffix=".p7b") as t:
        t.write(blob); t.flush()
        subj = subprocess.run(["openssl", "pkcs7", "-inform", "DER", "-in", t.name,
                               "-print_certs", "-noout"], capture_output=True, text=True).stdout
        signer = [l for l in subj.splitlines() if l.startswith("subject")][0]
        issuer = [l for l in subj.splitlines() if l.startswith("issuer")][0]
        print(f"   signer: {signer.split('CN = ')[-1]}  (issuer: {issuer.split('CN = ')[-1]})")
