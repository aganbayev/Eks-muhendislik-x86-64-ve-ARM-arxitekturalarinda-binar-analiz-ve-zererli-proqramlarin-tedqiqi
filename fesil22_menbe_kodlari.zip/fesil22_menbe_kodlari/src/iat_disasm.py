#!/usr/bin/env python3
"""iat_disasm.py - disassemble a range of an x86-64 PE and name indirect
calls through the import address table.  Usage: iat_disasm.py FILE VA COUNT"""
import sys, struct
import pefile
from capstone import Cs, CS_ARCH_X86, CS_MODE_64

f, va, count = sys.argv[1], int(sys.argv[2], 16), int(sys.argv[3])
pe = pefile.PE(f)
base = pe.OPTIONAL_HEADER.ImageBase
iat = {i.address: i.name.decode() for d in pe.DIRECTORY_ENTRY_IMPORT
       for i in d.imports if i.name}
data = pe.get_memory_mapped_image()[va - base:va - base + 16 * count]
md = Cs(CS_ARCH_X86, CS_MODE_64)
for n, ins in enumerate(md.disasm(data, va)):
    if n == count: break
    line = f"{ins.address:#x}: {ins.mnemonic:<6} {ins.op_str}"
    if ins.bytes[:2] == b"\xff\x15":
        tgt = ins.address + 6 + struct.unpack("<i", ins.bytes[2:6])[0]
        line += f"   ; {iat.get(tgt, '?')}"
    print(line)
