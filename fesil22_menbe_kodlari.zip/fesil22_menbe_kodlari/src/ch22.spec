# chapter 22 listings (run in /root/lab22)
== kaban_info
$ python3 pe_info.py kaban/kaban.exe
$ strings -n 12 kaban/kaban.exe | grep -n "Reverse this"
== kaban_cmp
$ python3 section_cmp.py kaban/kaban.exe kaban/kaban_dump_scy.exe
$ python3 iat_disasm.py kaban/kaban.exe 0x140001464 4
== kaban_crt
$ python3 patch_diff.py kaban/kaban_dump_scy.exe kaban/kaban_dump_patched.exe | grep -v "patch .*: nop$"
$ python3 iat_disasm.py kaban/kaban.exe 0x140017dd7 12
== sentinel_info
$ python3 pe_info.py sentinel/crackme03.exe
== sentinel_patch
$ python3 patch_diff.py sentinel/crackme03.exe sentinel/crackme03_patched.exe | grep -v "patch .*: nop$"
== defender_info
$ python3 pe_info.py -v defender/mpam-d_bd_1.383.1786.0.exe defender/MpSigStub.exe | grep -E "^==|Authenticode|Company|FileDesc|Original|StubName"
$ python3 authenticode_check.py defender/mpam-d_bd_1.383.1786.0.exe defender/MpSigStub.exe
== defender_log
$ python3 -c "import sys; sys.stdout.write(open('defender/MpSigStub.log','rb').read()[6::2].decode('latin1'))" | tr -d '\r' | grep -E "^(Command|Parent process):" | cut -c1-118
== turla_info
$ sha256sum tinyturla/d6ac*
$ python3 pe_info.py tinyturla/d6ac21a409f35a80ba9ccfe58ae1ae32883e44ecc724e4ae8289e7465ab2cf40 | grep -v VSize
== turla_patch
$ python3 patch_diff.py tinyturla/d6ac21a409f35a80ba9ccfe58ae1ae32883e44ecc724e4ae8289e7465ab2cf40 tinyturla/sample_patched.dll | grep -v "patch .*: nop$"
$ python3 iat_disasm.py tinyturla/d6ac21a409f35a80ba9ccfe58ae1ae32883e44ecc724e4ae8289e7465ab2cf40 0x18000dce0 13
$ python3 iat_disasm.py tinyturla/d6ac21a409f35a80ba9ccfe58ae1ae32883e44ecc724e4ae8289e7465ab2cf40 0x1800116ec 12
== sentinel_solve
$ python3 solve_sentinel.py sentinel/crackme03.exe 200
$ python3 -c "from sentinel_model import SentinelModel as M; print(M(open('sentinel/crackme03.exe','rb').read()).score('AI-99|~?0=PM;g6!'))"
