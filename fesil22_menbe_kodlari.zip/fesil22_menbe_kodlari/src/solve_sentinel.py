#!/usr/bin/env python3
"""solve_sentinel.py - password search for the "Mini LLM Sentinel" crackme.
Z3 handles the exact (structural) part of the check with the classifier
table, prefix and suffix read from the binary; every Z3 model is then scored
by the reconstructed neural network and blocked if the network rejects it.
Usage: solve_sentinel.py crackme03.exe [MAX_MODELS]"""
import sys
from z3 import BitVec, Solver, And, Or, If, Sum, ZeroExt, sat, get_version_string
from sentinel_model import SentinelModel

m = SentinelModel(open(sys.argv[1], "rb").read())
limit = int(sys.argv[2]) if len(sys.argv) > 2 else 200
print(f"Z3 {get_version_string()}")
print(f"prefix {m.prefix!r}  suffix {chr(m.suffix)!r}  permutation {m.permutation}")
ok3 = [c for c in range(32, 127) if m.classifier[c] >> 3 & 1]   # bit 3 must be 1
bit0 = [c for c in range(256) if m.classifier[c] & 1]
print(f"printable bytes allowed by classifier bit 3: {len(ok3)} of 95")
print("bit 0 (digits):", "".join(chr(v) for v in bit0 if 32 <= v < 127))

N = 16
c = [BitVec(f"c{i}", 8) for i in range(N)]
s = Solver()
for i, ch in enumerate(c):
    s.add(Or([ch == v for v in ok3]))
for i, v in enumerate(m.prefix):
    s.add(c[i] == v)
s.add(c[N - 1] == m.suffix)
s.add(Sum([ZeroExt(8, ch) for ch in c]) & 0xFF == 101)          # sum8 == 101
s.add(Sum([If(Or([ch == v for v in bit0]), 1, 0) for ch in c]) > 3)

tried = accepted = 0
first = None
while tried < limit and s.check() == sat:
    mod = s.model()
    pw = "".join(chr(mod[ch].as_long()) for ch in c)
    r = m.score(pw)
    tried += 1
    accepted += r["accepted"]
    first = first or (pw if r["accepted"] else None)
    if tried <= 3:
        print(f"model {tried:>3}: {pw}  sum8={r['sum8']}  sigmoid={r['sigmoid']:.4f}"
              f"  {'ACCEPTED' if r['accepted'] else 'rejected'}")
    s.add(Or([ch != mod[ch] for ch in c]))                          # block this model
print(f"{tried} Z3 model(s) scored by the network, {accepted} accepted")

# the network is not a formality: move the byte sum away from 101
for delta in (1, 4, 16):
    pw = first[:3] + chr(ord(first[3]) + delta) + first[4:]
    r = m.score(pw)
    print(f"{pw}  sum8={r['sum8']}  sigmoid={r['sigmoid']:.4f}  "
          f"{'ACCEPTED' if r['accepted'] else 'rejected'}")
