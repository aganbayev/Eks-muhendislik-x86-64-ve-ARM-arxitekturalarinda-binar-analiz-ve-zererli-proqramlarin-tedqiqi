#!/usr/bin/env python3
"""section_cmp.py - compare a PE file with its memory dump section by section.
If the code section of the file and of the dump are identical, nothing was
decrypted or unpacked at run time.  Usage: section_cmp.py FILE DUMP"""
import sys
import pefile

a, b = pefile.PE(sys.argv[1]), pefile.PE(sys.argv[2])
print(f"ImageBase file {a.OPTIONAL_HEADER.ImageBase:#x}, dump {b.OPTIONAL_HEADER.ImageBase:#x}")
print(f"{'section':<9}{'bytes':>8}{'differ':>8}")
for sa in a.sections:
    name = sa.Name.rstrip(b"\0")
    sb = next((s for s in b.sections if s.Name.rstrip(b"\0") == name), None)
    n = min(sa.Misc_VirtualSize, sa.SizeOfRawData)
    da = sa.get_data()[:n]
    db = sb.get_data()[:n] if sb else b""
    diff = sum(x != y for x, y in zip(da, db)) + abs(len(da) - len(db))
    print(f"{name.decode():<9}{n:>8}{diff:>8}")
extra = [s.Name.rstrip(b'\0').decode() for s in b.sections
         if s.Name.rstrip(b"\0") not in {x.Name.rstrip(b'\0') for x in a.sections}]
print("sections only in the dump:", ", ".join(extra) or "none")
